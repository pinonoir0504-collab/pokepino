plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.tdwatch.stockwatchv4"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tdwatch.stockwatchv4"
        minSdk = 24
        targetSdk = 35
        versionCode = 15
        versionName = "1.15.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-messaging")
}
