package com.tdwatch.stockwatchv4;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

final class PushRegistration {
    static final String WORKER_URL = "https://pinowatch-notifier.deespnow.workers.dev/register";
    static final String KEY = "pinowatch-7f3c9a82-d651-4e77-bc28-105a94d638fe";
    private PushRegistration() {}

    static boolean savePreferences(Context context, String favoritesJson, boolean favoritesOnly, boolean enabled) {
        SharedPreferences prefs = context.getSharedPreferences("push", Context.MODE_PRIVATE);
        boolean changed = !prefs.contains("favorites") || !favoritesJson.equals(prefs.getString("favorites", "[]"))
                || favoritesOnly != prefs.getBoolean("favoritesOnly", true) || enabled != prefs.getBoolean("enabled", true);
        prefs.edit()
                .putString("favorites", favoritesJson).putBoolean("favoritesOnly", favoritesOnly)
                .putBoolean("enabled", enabled).apply();
        return changed;
    }

    static void registerAsync(Context context, String token) {
        if (token == null || token.isEmpty()) return;
        new Thread(() -> {
            try {
                SharedPreferences p = context.getSharedPreferences("push", Context.MODE_PRIVATE);
                JSONObject body = new JSONObject();
                body.put("registrationKey", KEY);
                body.put("token", token);
                body.put("favorites", new org.json.JSONArray(p.getString("favorites", "[]")));
                body.put("favoritesOnly", p.getBoolean("favoritesOnly", true));
                body.put("enabled", p.getBoolean("enabled", true));
                HttpURLConnection c = (HttpURLConnection)new URL(WORKER_URL).openConnection();
                c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(15000);
                c.setRequestProperty("Content-Type", "application/json");
                byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = c.getOutputStream()) { out.write(data); }
                int status = c.getResponseCode(); c.disconnect();
                context.getSharedPreferences("push", Context.MODE_PRIVATE).edit()
                        .putString("registrationStatus", status >= 200 && status < 300 ? "登録済み" : "登録失敗 HTTP " + status)
                        .putLong("registeredAt", System.currentTimeMillis()).apply();
            } catch (Exception error) {
                context.getSharedPreferences("push", Context.MODE_PRIVATE).edit()
                        .putString("registrationStatus", "通信エラー").apply();
            }
        }).start();
    }

    static String status(Context context) {
        return context.getSharedPreferences("push", Context.MODE_PRIVATE).getString("registrationStatus", "登録処理中");
    }
}
