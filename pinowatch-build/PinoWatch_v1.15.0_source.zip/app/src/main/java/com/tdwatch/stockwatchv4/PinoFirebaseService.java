package com.tdwatch.stockwatchv4;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public final class PinoFirebaseService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) { PushRegistration.registerAsync(this, token); }

    @Override public void onMessageReceived(RemoteMessage message) {
        String title = message.getNotification() != null ? message.getNotification().getTitle() : message.getData().get("company");
        String body = message.getNotification() != null ? message.getNotification().getBody() : message.getData().get("title");
        String url = message.getData().get("url");
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel("disclosures", "新着開示", NotificationManager.IMPORTANCE_HIGH));
        Intent i = new Intent(this, MainActivity.class).putExtra("open_url", url).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int id = (int)(System.currentTimeMillis() & 0x7fffffff);
        PendingIntent pi = PendingIntent.getActivity(this, id, i, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "disclosures") : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_notify_more).setContentTitle(title == null ? "ピノウォッチ" : title)
                .setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true)
                .setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
        nm.notify(id, b.build());
    }
}
