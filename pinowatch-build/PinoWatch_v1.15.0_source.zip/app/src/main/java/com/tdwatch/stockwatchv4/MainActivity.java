package com.tdwatch.stockwatchv4;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final String DISCLOSURE_CHANNEL = "disclosures";
    private WebView webView;
    private boolean pageReady;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        createDisclosureChannel();
        EarningsReminderReceiver.catchUpAndSchedule(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 42);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowContentAccess(false);
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest r) { return blockUnknown(r.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String u) { return blockUnknown(Uri.parse(u)); }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url != null && url.startsWith("file:///android_asset/")) {
                    pageReady = true;
                    notifyJsResume();
                }
            }
        });
        setContentView(webView);
        openIntent(getIntent(), true);
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(t -> PushRegistration.registerAsync(this, t));
    }

    @Override protected void onResume() {
        super.onResume();
        EarningsReminderReceiver.catchUpAndSchedule(this);
        notifyJsResume();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        openIntent(intent, false);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 42 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            EarningsReminderReceiver.catchUpAndSchedule(this);
    }


    private void notifyJsResume() {
        if (!pageReady || webView == null) return;
        webView.evaluateJavascript("window.PinoNative&&window.PinoNative.onAppResume&&window.PinoNative.onAppResume();", null);
    }

    private void openIntent(Intent intent, boolean initial) {
        String u = intent == null ? null : intent.getStringExtra("open_url");
        if (u == null && intent != null) u = intent.getStringExtra("url");
        if (u != null && u.startsWith("https://")) webView.loadUrl(u);
        else if (initial) webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean blockUnknown(Uri uri) {
        String scheme = uri == null ? null : uri.getScheme();
        return !("file".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
    }

    private void createDisclosureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(DISCLOSURE_CHANNEL, "新着開示", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("新しい適時開示を通知します");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private boolean showDisclosureNotification(String title, String body, String url) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return false;
        createDisclosureChannel();
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (url != null && url.startsWith("https://")) open.putExtra("open_url", url);
        int id = (int) (System.currentTimeMillis() & 0x7fffffff);
        PendingIntent pi = PendingIntent.getActivity(this, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, DISCLOSURE_CHANNEL)
                : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle(title == null || title.trim().isEmpty() ? "ピノウォッチ" : title)
                .setContentText(body == null ? "" : body)
                .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return false;
        try { nm.notify(id, b.build()); return true; }
        catch (SecurityException e) { return false; }
    }

    private final class NativeBridge {
        @JavascriptInterface public void syncPushPreferences(String favoritesJson, boolean favoritesOnly, boolean enabled) {
            if (PushRegistration.savePreferences(MainActivity.this, favoritesJson, favoritesOnly, enabled))
                FirebaseMessaging.getInstance().getToken().addOnSuccessListener(t -> PushRegistration.registerAsync(MainActivity.this, t));
        }
        @JavascriptInterface public String getPushStatus() { return PushRegistration.status(MainActivity.this); }
        @JavascriptInterface public void requestEarningsSchedule(String favoritesJson, boolean force) {
            EarningsScheduleService.request(MainActivity.this, favoritesJson, force, payload -> runOnUiThread(() -> {
                if (webView == null) return;
                String quoted = JSONObject.quote(payload);
                webView.evaluateJavascript("window.PinoNative&&window.PinoNative.onEarningsResult(" + quoted + ");", null);
            }));
        }
        @JavascriptInterface public void syncEarningsSchedule(String scheduleJson) {
            EarningsReminderReceiver.saveSchedule(MainActivity.this, scheduleJson);
        }
        @JavascriptInterface public boolean notifyDisclosure(String title, String body, String url) {
            return showDisclosureNotification(title, body, url);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
