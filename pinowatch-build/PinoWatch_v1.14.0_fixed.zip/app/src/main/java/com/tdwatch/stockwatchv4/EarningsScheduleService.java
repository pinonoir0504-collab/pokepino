package com.tdwatch.stockwatchv4;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Fetches official planned earnings dates from the public JPX listed-company information service.
 *  Network refresh is capped to once per local calendar day unless the user explicitly asks for a manual refresh.
 */
final class EarningsScheduleService {
    interface Callback { void onResult(String json); }

    private static final String PREFS = "earnings_schedule_fetch";
    private static final String KEY_LAST_DAY = "last_fetch_day";
    private static final String KEY_LAST_PAYLOAD = "last_payload";
    private static final String SEARCH_URL = "https://www2.jpx.co.jp/tseHpFront/JJK010010Action.do?Show=Show";
    private static final String DETAIL_URL = "https://www2.jpx.co.jp/tseHpFront/JJK010030Action.do";
    private static final Pattern TABLE = Pattern.compile("(?is)<table\\b[^>]*>(.*?)</table>");
    private static final Pattern ROW = Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr>");
    private static final Pattern TH = Pattern.compile("(?is)<th\\b[^>]*>(.*?)</th>");
    private static final Pattern TD = Pattern.compile("(?is)<td\\b[^>]*>(.*?)</td>");
    private static final Pattern CHARSET = Pattern.compile("(?i)charset\\s*=\\s*[\\\"']?([A-Za-z0-9._-]+)");
    private static final Pattern DATE = Pattern.compile("(20\\d{2})\\s*[./年-]\\s*(\\d{1,2})\\s*[./月-]\\s*(\\d{1,2})");

    private EarningsScheduleService() { }

    static void request(Context context, String favoritesJson, boolean force, Callback callback) {
        final Context app = context.getApplicationContext();
        final SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        final String today = ymd(Calendar.getInstance());
        final String cached = prefs.getString(KEY_LAST_PAYLOAD, "");
        if (!force && today.equals(prefs.getString(KEY_LAST_DAY, ""))) {
            callback.onResult(markCached(cached, today));
            return;
        }
        // Mark the day before network I/O: automatic refresh is one attempt per day by design.
        if (!force) prefs.edit().putString(KEY_LAST_DAY, today).apply();
        final List<String> codes = parseCodes(favoritesJson);
        new Thread(() -> {
            String payload = fetchAll(codes, today, cached);
            try {
                JSONObject obj = new JSONObject(payload);
                if (obj.optBoolean("ok", false) || obj.optJSONArray("items") != null) {
                    prefs.edit().putString(KEY_LAST_PAYLOAD, payload).putString(KEY_LAST_DAY, today).apply();
                }
            } catch (Exception ignored) { }
            callback.onResult(payload);
        }, "PinoWatch-JPX").start();
    }

    private static String markCached(String cached, String today) {
        try {
            JSONObject obj = cached == null || cached.isEmpty() ? new JSONObject() : new JSONObject(cached);
            if (!obj.has("items")) obj.put("items", new JSONArray());
            obj.put("ok", true);
            obj.put("cached", true);
            obj.put("day", today);
            return obj.toString();
        } catch (Exception e) {
            return emptyResult(true, true, "");
        }
    }

    private static List<String> parseCodes(String raw) {
        ArrayList<String> out = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        try {
            JSONArray a = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < a.length() && out.size() < 100; i++) {
                String c = normCode(a.optString(i));
                if (c != null && seen.add(c)) out.add(c);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static String fetchAll(List<String> codes, String today, String cached) {
        if (codes.isEmpty()) return emptyResult(true, false, "");
        String cookie;
        try { cookie = openSession(); }
        catch (Exception e) { return fallbackError(cached, "JPX接続失敗: " + safeMsg(e)); }

        final String sessionCookie = cookie;
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(4, Math.max(1, codes.size())));
        ArrayList<Future<CodeResult>> futures = new ArrayList<>();
        for (String code : codes) futures.add(pool.submit((Callable<CodeResult>) () -> fetchOne(code, sessionCookie, today)));
        pool.shutdown();

        ArrayList<JSONObject> items = new ArrayList<>();
        JSONArray errors = new JSONArray();
        Map<String, List<JSONObject>> cachedByCode = cachedItemsByCode(cached, today);
        for (int i = 0; i < futures.size(); i++) {
            String code = codes.get(i);
            try {
                CodeResult r = futures.get(i).get();
                if (r.error != null) {
                    errors.put(code + ": " + r.error);
                    List<JSONObject> old = cachedByCode.get(code);
                    if (old != null) items.addAll(old);
                } else items.addAll(r.items);
            } catch (Exception e) {
                errors.put(code + ": " + safeMsg(e));
                List<JSONObject> old = cachedByCode.get(code);
                if (old != null) items.addAll(old);
            }
        }
        Collections.sort(items, Comparator.comparing(EarningsScheduleService::sortKey));
        try {
            JSONObject out = new JSONObject();
            out.put("ok", true);
            out.put("cached", false);
            out.put("source", "JPX上場会社情報サービス");
            out.put("fetchedAt", isoNow());
            out.put("day", today);
            JSONArray arr = new JSONArray();
            for (JSONObject o : items) arr.put(o);
            out.put("items", arr);
            out.put("errors", errors);
            return out.toString();
        } catch (Exception e) { return fallbackError(cached, "結果生成失敗"); }
    }

    private static CodeResult fetchOne(String code, String cookie, String today) {
        try {
            String body = "BaseJh=BaseJh&mgrCd=" + URLEncoder.encode(code + "0", "UTF-8") + "&jjHisiFlg=1";
            HttpURLConnection c = (HttpURLConnection) new URL(DETAIL_URL).openConnection();
            c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setInstanceFollowRedirects(true);
            c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setRequestProperty("User-Agent", "PinoWatch/1.14 Android");
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
            int status = c.getResponseCode();
            if (status < 200 || status >= 400) return new CodeResult(code, null, "HTTP " + status);
            String html = readText(c);
            Map<String, String> values = tableLabelValues(html);
            ArrayList<JSONObject> out = new ArrayList<>();
            addSchedule(out, values, code, today, "決算発表(予定)", "本決算");
            addSchedule(out, values, code, today, "第一四半期(予定)", "1Q");
            addSchedule(out, values, code, today, "第二四半期(予定)", "2Q");
            addSchedule(out, values, code, today, "第三四半期(予定)", "3Q");
            return new CodeResult(code, out, null);
        } catch (Exception e) { return new CodeResult(code, null, safeMsg(e)); }
    }

    private static void addSchedule(List<JSONObject> out, Map<String,String> values, String code, String today, String label, String period) {
        String raw = values.get(normText(label));
        if (raw == null) {
            String prefix = normText(label.replace("(予定)", ""));
            for (Map.Entry<String,String> e : values.entrySet()) if (e.getKey().startsWith(prefix)) { raw = e.getValue(); break; }
        }
        String date = normalizeDate(raw);
        if (date == null || date.compareTo(today) < 0) return;
        try {
            JSONObject o = new JSONObject();
            o.put("code", code); o.put("date", date); o.put("period", period);
            o.put("time", ""); o.put("confirmed", true); o.put("source", "JPX");
            out.add(o);
        } catch (Exception ignored) { }
    }

    private static String openSession() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(SEARCH_URL).openConnection();
        c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "PinoWatch/1.14 Android");
        int status = c.getResponseCode();
        if (status < 200 || status >= 400) throw new Exception("HTTP " + status);
        // consume response to establish session
        try (InputStream in = c.getInputStream()) { byte[] b = new byte[4096]; while (in.read(b) >= 0) { } }
        Map<String,List<String>> headers = c.getHeaderFields();
        if (headers != null) for (Map.Entry<String,List<String>> e : headers.entrySet()) {
            if (e.getKey() == null || !"set-cookie".equalsIgnoreCase(e.getKey())) continue;
            for (String v : e.getValue()) {
                Matcher m = Pattern.compile("(?i)JSESSIONID=([^;]+)").matcher(v == null ? "" : v);
                if (m.find()) return "JSESSIONID=" + m.group(1);
            }
        }
        return "";
    }

    private static Map<String,String> tableLabelValues(String html) {
        HashMap<String,String> out = new HashMap<>();
        Matcher tm = TABLE.matcher(html == null ? "" : html);
        while (tm.find()) {
            ArrayList<String> rows = new ArrayList<>(); Matcher rm = ROW.matcher(tm.group(1));
            while (rm.find()) rows.add(rm.group(1));
            for (int i=0; i+1<rows.size(); i++) {
                ArrayList<String> hs = captures(TH, rows.get(i)); if (hs.isEmpty()) continue;
                ArrayList<String> ds = captures(TD, rows.get(i+1)); if (ds.isEmpty()) continue;
                int n = Math.min(hs.size(), ds.size());
                for (int j=0; j<n; j++) { String key=normText(stripHtml(hs.get(j))); if (!key.isEmpty()) out.put(key, stripHtml(ds.get(j))); }
            }
        }
        return out;
    }

    private static ArrayList<String> captures(Pattern p, String s) { ArrayList<String> a=new ArrayList<>(); Matcher m=p.matcher(s); while(m.find())a.add(m.group(1)); return a; }
    private static String stripHtml(String s) {
        if (s == null) return "";
        String x=s.replaceAll("(?is)<script\\b.*?</script>"," ").replaceAll("(?is)<style\\b.*?</style>"," ").replaceAll("(?i)<br\\s*/?>"," ").replaceAll("(?is)<[^>]+>"," ");
        x=x.replace("&nbsp;"," ").replace("&#160;"," ").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&#39;","'").replace("&apos;","'");
        Matcher m=Pattern.compile("&#(\\d+);").matcher(x); StringBuffer b=new StringBuffer();
        while(m.find()){int v;try{v=Integer.parseInt(m.group(1));}catch(Exception e){v=32;}m.appendReplacement(b,Matcher.quoteReplacement(String.valueOf((char)v)));}m.appendTail(b);
        return b.toString().replaceAll("\\s+"," ").trim();
    }
    private static String normText(String s) { return Normalizer.normalize(String.valueOf(s == null ? "" : s), Normalizer.Form.NFKC).replace("（","(").replace("）",")").replaceAll("\\s+","").trim(); }
    private static String normalizeDate(String s) { Matcher m=DATE.matcher(normText(s)); return m.find()?String.format(Locale.US,"%s-%02d-%02d",m.group(1),Integer.parseInt(m.group(2)),Integer.parseInt(m.group(3))):null; }
    private static String normCode(String s) { String x=Normalizer.normalize(String.valueOf(s==null?"":s),Normalizer.Form.NFKC).trim().toUpperCase(Locale.US); if(x.matches("[0-9A-Z]{5}")&&x.endsWith("0"))x=x.substring(0,4); return x.matches("[0-9]{3}[0-9A-Z]")?x:null; }
    private static String ymd(Calendar c) { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime()); }
    private static String isoNow() { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Calendar.getInstance().getTime()); }
    private static String safeMsg(Throwable e) { String s=e==null?"error":String.valueOf(e.getMessage()); return s.length()>160?s.substring(0,160):s; }
    private static String sortKey(JSONObject o) { return o.optString("date")+"T"+(o.optString("time").isEmpty()?"23:59":o.optString("time"))+"|"+o.optString("code"); }

    private static String readText(HttpURLConnection c) throws Exception {
        byte[] bytes; try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);bytes=out.toByteArray();}
        String cs="UTF-8"; String ct=c.getContentType(); if(ct!=null){Matcher m=CHARSET.matcher(ct);if(m.find())cs=m.group(1);} 
        try{return new String(bytes, Charset.forName(cs));}catch(Exception e){return new String(bytes,StandardCharsets.UTF_8);} }

    private static Map<String,List<JSONObject>> cachedItemsByCode(String cached, String today) {
        HashMap<String,List<JSONObject>> out=new HashMap<>(); try{JSONObject p=new JSONObject(cached==null?"":cached);JSONArray a=p.optJSONArray("items");if(a==null)return out;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||o.optString("date").compareTo(today)<0)continue;String c=normCode(o.optString("code"));if(c==null)continue;out.computeIfAbsent(c,k->new ArrayList<>()).add(o);}}catch(Exception ignored){} return out;
    }
    private static String fallbackError(String cached, String message) {
        try{JSONObject p=cached==null||cached.isEmpty()?new JSONObject():new JSONObject(cached);if(!p.has("items"))p.put("items",new JSONArray());p.put("ok",false);p.put("cached",true);p.put("error",message);return p.toString();}catch(Exception e){return emptyResult(false,true,message);} }
    private static String emptyResult(boolean ok, boolean cached, String error) { try{JSONObject o=new JSONObject();o.put("ok",ok);o.put("cached",cached);o.put("items",new JSONArray());if(error!=null&&!error.isEmpty())o.put("error",error);return o.toString();}catch(Exception e){return "{\"ok\":false,\"items\":[]}";} }

    private static final class CodeResult { final String code; final List<JSONObject> items; final String error; CodeResult(String c,List<JSONObject> i,String e){code=c;items=i==null?Collections.emptyList():i;error=e;} }
}
