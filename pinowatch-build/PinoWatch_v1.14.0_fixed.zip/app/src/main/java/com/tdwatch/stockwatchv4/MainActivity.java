package com.tdwatch.stockwatchv4;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private WebView webView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        createChannel();
        EarningsReminderReceiver.scheduleNext(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 42);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowUniversalAccessFromFileURLs(true); s.setAllowContentAccess(false);
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest r) { return blockUnknown(r.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String u) { return blockUnknown(Uri.parse(u)); }
        });
        setContentView(webView);
        openIntent(getIntent(), true);
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(t -> PushRegistration.registerAsync(this, t));
    }

    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); openIntent(intent, false); }

    private void openIntent(Intent intent, boolean initial) {
        String u = intent == null ? null : intent.getStringExtra("open_url");
        if (u == null && intent != null) u = intent.getStringExtra("url");
        if (u != null && u.startsWith("https://")) webView.loadUrl(u);
        else if (initial) webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean blockUnknown(Uri uri) {
        String scheme = uri == null ? null : uri.getScheme();
        return !("file".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("disclosures", "新着開示", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("新しい適時開示を通知します");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private final class NativeBridge {
        @JavascriptInterface public void syncPushPreferences(String favoritesJson, boolean favoritesOnly, boolean enabled) {
            if (PushRegistration.savePreferences(MainActivity.this, favoritesJson, favoritesOnly, enabled))
                FirebaseMessaging.getInstance().getToken().addOnSuccessListener(t -> PushRegistration.registerAsync(MainActivity.this, t));
        }
        @JavascriptInterface public String getPushStatus() { return PushRegistration.status(MainActivity.this); }
        @JavascriptInterface public void requestEarningsSchedule(String favoritesJson, boolean force) {
            EarningsScheduleService.request(MainActivity.this, favoritesJson, force, payload -> runOnUiThread(() -> {
                if (webView == null) return;
                String quoted = JSONObject.quote(payload);
                webView.evaluateJavascript("window.PinoNative&&window.PinoNative.onEarningsResult(" + quoted + ");", null);
            }));
        }
        @JavascriptInterface public void syncEarningsSchedule(String scheduleJson) { EarningsReminderReceiver.saveSchedule(MainActivity.this, scheduleJson); }
        @JavascriptInterface public void notifyDisclosure(String title, String body, String url) { /* FCM通知へ移行済み */ }
    }

    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; } super.onDestroy(); }
}
