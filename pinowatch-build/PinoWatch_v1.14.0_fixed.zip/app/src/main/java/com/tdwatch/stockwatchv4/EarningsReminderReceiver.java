package com.tdwatch.stockwatchv4;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Locale;

public final class EarningsReminderReceiver extends BroadcastReceiver {
    private static final String ACTION_REMINDER = "com.tdwatch.stockwatchv4.EARNINGS_REMINDER";
    private static final String PREFS = "earnings_reminder";
    private static final String KEY_SCHEDULE = "schedule_json";
    private static final String KEY_LAST_NOTIFY_DAY = "last_notify_day";
    private static final int REQUEST_CODE = 2000;
    private static final int NOTIFICATION_ID = 2001;
    private static final String CHANNEL_ID = "earnings_reminders";

    static void saveSchedule(Context context, String scheduleJson) {
        if (scheduleJson == null) scheduleJson = "[]";
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_SCHEDULE, scheduleJson).apply();
        maybeNotifyIfPastEight(context);
        scheduleNext(context);
    }

    static void scheduleNext(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, 20);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_MONTH, 1);

        Intent intent = new Intent(context, EarningsReminderReceiver.class).setAction(ACTION_REMINDER);
        PendingIntent pi = PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        long when = next.getTimeInMillis();
        try {
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (SecurityException ignored) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    private static String ymd(Calendar c) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    private static void maybeNotifyIfPastEight(Context context) {
        Calendar now = Calendar.getInstance();
        if (now.get(Calendar.HOUR_OF_DAY) < 20) return;
        notifyTomorrowIfNeeded(context, now);
    }

    private static void notifyTomorrowIfNeeded(Context context, Calendar now) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = ymd(now);
        if (today.equals(prefs.getString(KEY_LAST_NOTIFY_DAY, ""))) return;

        Calendar tomorrow = (Calendar) now.clone();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);
        String targetDate = ymd(tomorrow);
        String raw = prefs.getString(KEY_SCHEDULE, "[]");
        Set<String> labelSet = new LinkedHashSet<>();
        try {
            JSONArray rows = new JSONArray(raw);
            for (int i = 0; i < rows.length(); i++) {
                JSONObject o = rows.optJSONObject(i);
                if (o == null || !targetDate.equals(o.optString("date"))) continue;
                String code = o.optString("code").trim();
                String company = o.optString("company").trim();
                String time = o.optString("time").trim();
                String period = o.optString("period").trim();
                String label = (code + " " + company).trim();
                String detail = period;
                if (!time.isEmpty()) detail += (detail.isEmpty() ? "" : "・") + time;
                if (!detail.isEmpty()) label += "（" + detail + "）";
                if (!label.isEmpty()) labelSet.add(label);
            }
        } catch (Exception ignored) { }
        List<String> labels = new ArrayList<>(labelSet);
        if (labels.isEmpty()) return;

        createChannel(context);
        int shown = Math.min(labels.size(), 12);
        StringBuilder body = new StringBuilder();
        for (int i = 0; i < shown; i++) {
            if (i > 0) body.append('\n');
            body.append("・").append(labels.get(i));
        }
        if (labels.size() > shown) body.append("\nほか").append(labels.size() - shown).append("社");

        Intent open = new Intent(context, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(context, NOTIFICATION_ID, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle("明日決算：" + labels.size() + "社")
                .setContentText(labels.get(0))
                .setStyle(new Notification.BigTextStyle().bigText(body.toString()))
                .setContentIntent(content)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis());
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, b.build());
        prefs.edit().putString(KEY_LAST_NOTIFY_DAY, today).apply();
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "明日の決算予定", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("お気に入り銘柄の翌日の決算予定を前日20時にまとめて通知します");
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            scheduleNext(context);
            return;
        }
        notifyTomorrowIfNeeded(context, Calendar.getInstance());
        scheduleNext(context);
    }
}
