package com.tdwatch.stockwatchv4;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Locale;

public final class DisclosureCatchUpWorker extends Worker {
    private static final String API = "https://webapi.yanoshin.jp/webapi/tdnet/list/recent.json2?limit=1000";

    public DisclosureCatchUpWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    static void enqueueNow(Context context) {
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(DisclosureCatchUpWorker.class)
                .setConstraints(constraints)
                .build();
        WorkManager.getInstance(context.getApplicationContext()).enqueueUniqueWork(
                "pinowatch-disclosure-catchup-now-v116", ExistingWorkPolicy.REPLACE, work);
    }

    @NonNull @Override public Result doWork() {
        Context context = getApplicationContext();
        // Also use this reliable network window to repair a failed/stale FCM registration.
        try {
            if (PushRegistration.needsRefresh(context)) {
                String token = Tasks.await(FirebaseMessaging.getInstance().getToken(), 20, TimeUnit.SECONDS);
                PushRegistration.registerBlocking(context, token);
            }
        } catch (Exception ignored) {}

        if (!NotificationReliability.masterEnabled(context)) {
            NotificationReliability.recordCatchup(context, "通知OFF", 0);
            return Result.success();
        }

        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(API).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(15000);
            c.setRequestProperty("User-Agent", "PinoWatch/1.16 Android CatchUp");
            int status = c.getResponseCode();
            if (status < 200 || status >= 400) {
                NotificationReliability.recordCatchup(context, "HTTP " + status, 0);
                return Result.retry();
            }
            String raw;
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                raw = out.toString(StandardCharsets.UTF_8.name());
            }
            JSONObject root = new JSONObject(raw);
            JSONArray rows = root.optJSONArray("items");
            if (rows == null) rows = root.optJSONArray("Tdnet");
            if (rows == null) {
                NotificationReliability.recordCatchup(context, "JSON形式不明", 0);
                return Result.retry();
            }

            List<Item> items = new ArrayList<>();
            List<String> keys = new ArrayList<>();
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                JSONObject wrapped = row.optJSONObject("Tdnet");
                if (wrapped != null) row = wrapped;
                String code = normCode(row.optString("company_code", row.optString("companyCode", "")));
                String company = row.optString("company_name", row.optString("companyName", "")).trim();
                String title = row.optString("title", "").trim();
                String url = row.optString("document_url", row.optString("documentUrl", "")).trim();
                String pubdate = row.optString("pubdate", row.optString("publishedAt", "")).trim();
                if (code == null || title.isEmpty()) continue;
                String label = (code + " " + company).trim();
                Item item = new Item(label, title, url, parsePubdateMillis(pubdate));
                items.add(item);
                keys.add(NotificationReliability.stableKey(url, label, title));
            }

            if (!NotificationReliability.catchupInitialized(context)) {
                NotificationReliability.seedSeen(context, keys);
                NotificationReliability.recordCatchup(context, "初回基準作成", items.size());
                return Result.success();
            }

            // API is newest-first; notify old-to-new so multiple recovered items read naturally.
            for (int i = items.size() - 1; i >= 0; i--) {
                Item item = items.get(i);
                String key = keys.get(i);
                if (NotificationReliability.sentBeforeLastReenable(context, item.pubdateMillis)) {
                    NotificationReliability.markSeen(context, key);
                    continue;
                }
                if (NotificationReliability.matchesPreferences(context, item.companyLabel, item.title)) {
                    NotificationReliability.notifyDisclosure(
                            context, item.companyLabel, item.title, item.url, "catchup", false);
                } else {
                    NotificationReliability.markSeen(context, key);
                }
            }
            NotificationReliability.recordCatchup(context, "OK", items.size());
            return Result.success();
        } catch (Exception e) {
            NotificationReliability.recordCatchup(context, "通信/解析エラー", 0);
            return Result.retry();
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String normCode(String s) {
        String x = String.valueOf(s == null ? "" : s).trim().toUpperCase();
        if (x.matches("[0-9A-Z]{5}") && x.endsWith("0")) x = x.substring(0, 4);
        return x.matches("[0-9]{3}[0-9A-Z]") ? x : null;
    }

    private static long parsePubdateMillis(String raw) {
        if (raw == null || raw.trim().isEmpty()) return 0L;
        String[] formats = {
                "yyyy-MM-dd HH:mm:ss",
                "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss"
        };
        for (String f : formats) {
            try {
                SimpleDateFormat df = new SimpleDateFormat(f, Locale.JAPAN);
                df.setLenient(false);
                Date d = df.parse(raw.trim());
                if (d != null) return d.getTime();
            } catch (ParseException ignored) { }
        }
        return 0L;
    }

    private static final class Item {
        final String companyLabel, title, url;
        final long pubdateMillis;
        Item(String companyLabel, String title, String url, long pubdateMillis) {
            this.companyLabel = companyLabel;
            this.title = title;
            this.url = url;
            this.pubdateMillis = pubdateMillis;
        }
    }
}
