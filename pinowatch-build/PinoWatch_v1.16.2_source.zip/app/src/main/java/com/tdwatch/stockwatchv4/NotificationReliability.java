package com.tdwatch.stockwatchv4;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class NotificationReliability {
    static final String DISCLOSURE_CHANNEL = "disclosures";
    private static final String REL_PREFS = "notification_reliability";
    private static final String KEY_SEEN = "seen_disclosures";
    private static final String KEY_CATCHUP_INITIALIZED = "catchup_initialized";
    private static final int MAX_SEEN = 1200;
    private static final String PERIODIC_WORK = "pinowatch-disclosure-catchup-v116";
    private static final Pattern CODE_PREFIX = Pattern.compile("^\\s*([0-9]{3}[0-9A-Z])\\b", Pattern.CASE_INSENSITIVE);

    private NotificationReliability() {}

    static void ensureBackgroundWork(Context context) {
        Context app = context.getApplicationContext();
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        PeriodicWorkRequest work = new PeriodicWorkRequest.Builder(
                DisclosureCatchUpWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(constraints)
                .build();
        WorkManager.getInstance(app).enqueueUniquePeriodicWork(
                PERIODIC_WORK, ExistingPeriodicWorkPolicy.UPDATE, work);
    }

    static boolean notificationsAllowedByOs(Context context) {
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        return Build.VERSION.SDK_INT < 24 || nm == null || nm.areNotificationsEnabled();
    }

    private static boolean channelAllowed(Context context, String channelId) {
        if (!notificationsAllowedByOs(context)) return false;
        if (Build.VERSION.SDK_INT < 26) return true;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return true;
        NotificationChannel c = nm.getNotificationChannel(channelId);
        return c == null || c.getImportance() != NotificationManager.IMPORTANCE_NONE;
    }

    static boolean disclosureNotificationsAllowed(Context context) {
        return channelAllowed(context, DISCLOSURE_CHANNEL);
    }

    static boolean earningsNotificationsAllowed(Context context) {
        return channelAllowed(context, "earnings_reminders");
    }

    private static String channelStatus(Context context, String channelId) {
        if (!notificationsAllowedByOs(context)) return "アプリ通知OFF/未許可";
        if (Build.VERSION.SDK_INT < 26) return "利用可能";
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return "利用可能";
        NotificationChannel c = nm.getNotificationChannel(channelId);
        if (c == null) return "未作成（初回通知時に作成）";
        return c.getImportance() == NotificationManager.IMPORTANCE_NONE ? "チャンネルOFF" : "ON";
    }

    static boolean catchupStale(Context context, long maxAgeMs) {
        long at = rel(context).getLong("last_catchup_at", 0L);
        return at <= 0L || System.currentTimeMillis() - at > maxAgeMs;
    }

    static boolean masterEnabled(Context context) {
        return context.getSharedPreferences("push", Context.MODE_PRIVATE).getBoolean("enabled", true);
    }

    static boolean earningsReminderEnabled(Context context) {
        SharedPreferences p = context.getSharedPreferences("push", Context.MODE_PRIVATE);
        return p.getBoolean("enabled", true) && p.getBoolean("prev20", true);
    }

    static boolean matchesPreferences(Context context, String companyLabel, String disclosureTitle) {
        SharedPreferences p = context.getSharedPreferences("push", Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", true)) return false;

        if (p.getBoolean("favoritesOnly", true)) {
            String code = codeFromCompanyLabel(companyLabel);
            if (code != null) {
                Set<String> favorites = parseStringSet(p.getString("favorites", "[]"));
                if (!favorites.contains(code)) return false;
            }
            // If the sender omitted a code, do not drop a potentially valid server-filtered push.
        }

        String categoriesJson = p.getString("categories", "");
        if (categoriesJson == null || categoriesJson.trim().isEmpty()) return true;
        try {
            JSONObject enabled = new JSONObject(categoriesJson);
            List<String> cats = classify(disclosureTitle);
            for (String c : cats) if (enabled.optBoolean(c, defaultCategoryEnabled(c))) return true;
            return false;
        } catch (Exception ignored) {
            return true;
        }
    }

    static void onMasterSettingChanged(Context context, boolean oldEnabled, boolean newEnabled) {
        if (oldEnabled == newEnabled) return;
        SharedPreferences.Editor ed = rel(context).edit();
        if (newEnabled) ed.putLong("last_reenabled_at", System.currentTimeMillis());
        else ed.putLong("last_disabled_at", System.currentTimeMillis());
        ed.apply();
    }

    static boolean sentBeforeLastReenable(Context context, long sentAtMillis) {
        if (sentAtMillis <= 0L) return false;
        long reenabledAt = rel(context).getLong("last_reenabled_at", 0L);
        return reenabledAt > 0L && sentAtMillis < reenabledAt;
    }

    static String stableKey(String url, String companyLabel, String disclosureTitle) {
        String raw = (url != null && !url.trim().isEmpty())
                ? "url|" + url.trim()
                : "text|" + String.valueOf(companyLabel).trim() + "|" + String.valueOf(disclosureTitle).trim();
        return sha256(raw);
    }

    static boolean notifyDisclosure(Context context, String title, String body, String url, String source, boolean force) {
        Context app = context.getApplicationContext();
        createDisclosureChannel(app);
        if (!force) {
            if (!masterEnabled(app) || !disclosureNotificationsAllowed(app)) return false;
            String key = stableKey(url, title, body);
            if (!claimSeen(app, key)) {
                increment(app, "duplicates_suppressed");
                return false;
            }
        } else if (!disclosureNotificationsAllowed(app)) {
            return false;
        }
        Intent open = new Intent(app, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (url != null && url.startsWith("https://")) open.putExtra("open_url", url);

        String key = stableKey(url, title, body);
        int id = force ? (int)(System.currentTimeMillis() & 0x7fffffff) : stableNotificationId(key);
        PendingIntent pi = PendingIntent.getActivity(app, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(app, DISCLOSURE_CHANNEL)
                : new Notification.Builder(app);
        b.setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle(title == null || title.trim().isEmpty() ? "ピノウォッチ" : title)
                .setContentText(body == null ? "" : body)
                .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setCategory(Notification.CATEGORY_STATUS)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL);

        NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            if (!force) releaseSeen(app, key);
            return false;
        }
        try {
            nm.notify(id, b.build());
            SharedPreferences.Editor ed = rel(app).edit()
                    .putLong("last_notification_at", System.currentTimeMillis())
                    .putString("last_notification_source", source == null ? "" : source);
            if ("fcm".equals(source)) ed.putLong("last_fcm_notified_at", System.currentTimeMillis());
            if ("catchup".equals(source)) {
                ed.putLong("last_recovered_at", System.currentTimeMillis());
                increment(app, "recovered_count");
            }
            ed.apply();
            return true;
        } catch (RuntimeException e) {
            // Keep the item recoverable if Android rejected the notification post.
            if (!force) releaseSeen(app, key);
            rel(app).edit()
                    .putString("last_notification_error", e.getClass().getSimpleName())
                    .putLong("last_notification_error_at", System.currentTimeMillis())
                    .apply();
            return false;
        }
    }

    static void recordFcmReceived(Context context) {
        rel(context).edit().putLong("last_fcm_received_at", System.currentTimeMillis()).apply();
    }

    static void recordCatchup(Context context, String status, int scanned) {
        rel(context).edit()
                .putLong("last_catchup_at", System.currentTimeMillis())
                .putString("last_catchup_status", status == null ? "" : status)
                .putInt("last_catchup_scanned", scanned)
                .apply();
    }

    static boolean catchupInitialized(Context context) {
        return rel(context).getBoolean(KEY_CATCHUP_INITIALIZED, false);
    }

    static synchronized void seedSeen(Context context, List<String> keys) {
        LinkedSeen set = readSeen(context);
        for (String k : keys) set.add(k);
        writeSeen(context, set);
        rel(context).edit().putBoolean(KEY_CATCHUP_INITIALIZED, true).apply();
    }

    static synchronized void markSeen(Context context, String key) {
        if (key == null || key.isEmpty()) return;
        LinkedSeen set = readSeen(context);
        if (set.add(key)) writeSeen(context, set);
    }

    private static synchronized boolean claimSeen(Context context, String key) {
        if (key == null || key.isEmpty()) return true;
        LinkedSeen set = readSeen(context);
        if (set.contains(key)) return false;
        set.add(key);
        writeSeen(context, set);
        return true;
    }

    private static synchronized void releaseSeen(Context context, String key) {
        if (key == null || key.isEmpty()) return;
        LinkedSeen set = readSeen(context);
        if (set.items.remove(key)) writeSeen(context, set);
    }

    static String diagnostics(Context context) {
        try {
            JSONObject o = new JSONObject();
            SharedPreferences r = rel(context);
            o.put("notificationPermission", notificationsAllowedByOs(context) ? "許可済み" : "OFF/未許可");
            o.put("disclosureChannel", channelStatus(context, DISCLOSURE_CHANNEL));
            o.put("earningsChannel", channelStatus(context, "earnings_reminders"));
            o.put("exactAlarm", exactAlarmStatus(context));
            o.put("pushStatus", PushRegistration.status(context));
            o.put("lastFcmReceivedAt", r.getLong("last_fcm_received_at", 0L));
            o.put("lastFcmNotifiedAt", r.getLong("last_fcm_notified_at", 0L));
            o.put("lastCatchupAt", r.getLong("last_catchup_at", 0L));
            o.put("lastCatchupStatus", r.getString("last_catchup_status", ""));
            o.put("lastCatchupScanned", r.getInt("last_catchup_scanned", 0));
            o.put("recoveredCount", r.getInt("recovered_count", 0));
            o.put("duplicatesSuppressed", r.getInt("duplicates_suppressed", 0));
            o.put("lastNotificationAt", r.getLong("last_notification_at", 0L));
            o.put("lastNotificationSource", r.getString("last_notification_source", ""));
            o.put("lastNotificationError", r.getString("last_notification_error", ""));
            o.put("lastNotificationErrorAt", r.getLong("last_notification_error_at", 0L));
            SharedPreferences e = context.getSharedPreferences("earnings_reminder", Context.MODE_PRIVATE);
            o.put("nextEarningsAlarmAt", e.getLong("next_alarm_at", 0L));
            o.put("lastEarningsReminderAt", e.getLong("last_notify_at", 0L));
            return o.toString();
        } catch (Exception e) {
            return "{\"error\":\"diagnostics failed\"}";
        }
    }

    static String exactAlarmStatus(Context context) {
        if (Build.VERSION.SDK_INT < 31) return "正確な20:00通知対応";
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms() ? "正確な20:00通知 許可済み" : "20:00前後になる可能性あり";
    }

    static void createDisclosureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    DISCLOSURE_CHANNEL, "新着開示", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("新しい適時開示を通知します");
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    private static String codeFromCompanyLabel(String companyLabel) {
        Matcher m = CODE_PREFIX.matcher(companyLabel == null ? "" : Normalizer.normalize(companyLabel, Normalizer.Form.NFKC));
        return m.find() ? m.group(1).toUpperCase(Locale.US) : null;
    }

    private static Set<String> parseStringSet(String raw) {
        HashSet<String> out = new HashSet<>();
        try {
            JSONArray a = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < a.length(); i++) {
                String s = a.optString(i, "").trim().toUpperCase(Locale.US);
                if (s.matches("[0-9]{3}[0-9A-Z]")) out.add(s);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static List<String> classify(String title) {
        String t = Normalizer.normalize(title == null ? "" : title, Normalizer.Form.NFKC);
        ArrayList<String> c = new ArrayList<>();
        if (t.matches("(?s).*(決算短信|四半期決算|通期決算|決算発表).*")) c.add("earnings");
        if (t.matches("(?s).*(業績予想|業績予測|上方修正|下方修正|予想の修正).*")) c.add("revision");
        if (t.matches("(?s).*(配当|増配|減配|剰余金の配当).*")) c.add("dividend");
        if (t.matches("(?s).*(自己株式|自社株買い|自己株式の消却).*")) c.add("buyback");
        if (t.matches("(?s).*(株式分割|株式併合).*")) c.add("split");
        if (t.matches("(?s).*(株主優待|優待制度).*")) c.add("benefit");
        if (t.matches("(?s).*(公開買付|TOB|MBO).*")) c.add("tob");
        if (t.matches("(?s).*(合併|買収|M&A|業務提携|資本提携|事業譲渡).*")) c.add("ma");
        if (t.matches("(?s).*(人事|代表取締役|役員).*")) c.add("personnel");
        if (t.matches("(?s).*(決算説明|説明会資料|補足資料).*")) c.add("presentation");
        if (t.matches("(?s).*(コーポレート・ガバナンス|ガバナンス報告書).*")) c.add("governance");
        if (c.isEmpty()) c.add("other");
        return c;
    }

    private static boolean defaultCategoryEnabled(String c) {
        return !"personnel".equals(c) && !"presentation".equals(c) && !"governance".equals(c) && !"other".equals(c);
    }

    private static int stableNotificationId(String key) {
        int h = key == null ? 1 : key.hashCode();
        if (h == Integer.MIN_VALUE) h = 1;
        return Math.abs(h);
    }

    private static String sha256(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(String.valueOf(s).getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte x : d) b.append(String.format(Locale.US, "%02x", x));
            return b.toString();
        } catch (Exception e) {
            return Integer.toHexString(String.valueOf(s).hashCode());
        }
    }

    private static SharedPreferences rel(Context context) {
        return context.getApplicationContext().getSharedPreferences(REL_PREFS, Context.MODE_PRIVATE);
    }

    private static void increment(Context context, String key) {
        SharedPreferences p = rel(context);
        p.edit().putInt(key, p.getInt(key, 0) + 1).apply();
    }

    private static LinkedSeen readSeen(Context context) {
        LinkedSeen out = new LinkedSeen();
        try {
            JSONArray a = new JSONArray(rel(context).getString(KEY_SEEN, "[]"));
            for (int i = 0; i < a.length(); i++) {
                String s = a.optString(i, "");
                if (!s.isEmpty()) out.add(s);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static void writeSeen(Context context, LinkedSeen set) {
        JSONArray a = new JSONArray();
        int start = Math.max(0, set.items.size() - MAX_SEEN);
        for (int i = start; i < set.items.size(); i++) a.put(set.items.get(i));
        rel(context).edit().putString(KEY_SEEN, a.toString()).apply();
    }

    private static final class LinkedSeen {
        final ArrayList<String> items = new ArrayList<>();
        boolean contains(String s) { return items.contains(s); }
        boolean add(String s) {
            if (s == null || s.isEmpty() || items.contains(s)) return false;
            items.add(s);
            if (items.size() > MAX_SEEN * 2) items.subList(0, items.size() - MAX_SEEN).clear();
            return true;
        }
    }
}
