package com.tdwatch.stockwatchv4;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Fetches official planned earnings dates from the public JPX listed-company information service.
 * Automatic network refresh is limited to one attempt per local calendar day. A manual refresh bypasses the limit.
 * Company names and an estimated announcement time are enriched from historical TDnet metadata in batches.
 */
final class EarningsScheduleService {
    interface Callback { void onResult(String json); }

    private static final String PREFS = "earnings_schedule_fetch";
    private static final String KEY_LAST_ATTEMPT_DAY = "last_attempt_day";
    private static final String KEY_LAST_SUCCESS_PAYLOAD = "last_success_payload";
    private static final String KEY_LAST_ATTEMPT_ERROR = "last_attempt_error";
    private static final String KEY_LAST_ATTEMPT_CODES = "last_attempt_codes";
    private static final String LEGACY_KEY_LAST_DAY = "last_fetch_day";
    private static final String LEGACY_KEY_LAST_PAYLOAD = "last_payload";
    private static final String SEARCH_URL = "https://www2.jpx.co.jp/tseHpFront/JJK010010Action.do?Show=Show";
    private static final String DETAIL_URL = "https://www2.jpx.co.jp/tseHpFront/JJK010030Action.do";
    private static final String TDNET_BASE = "https://webapi.yanoshin.jp/webapi/tdnet/list/";
    private static final Pattern TABLE = Pattern.compile("(?is)<table\\b[^>]*>(.*?)</table>");
    private static final Pattern ROW = Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr>");
    private static final Pattern TH = Pattern.compile("(?is)<th\\b[^>]*>(.*?)</th>");
    private static final Pattern TD = Pattern.compile("(?is)<td\\b[^>]*>(.*?)</td>");
    private static final Pattern CHARSET = Pattern.compile("(?i)charset\\s*=\\s*[\\\"']?([A-Za-z0-9._-]+)");
    private static final Pattern DATE = Pattern.compile("(20\\d{2})\\s*[./年-]\\s*(\\d{1,2})\\s*[./月-]\\s*(\\d{1,2})");
    private static final Pattern PUBDATE_TIME = Pattern.compile("\\b(\\d{1,2}):(\\d{2})(?::\\d{2})?\\b");

    private EarningsScheduleService() { }

    static void request(Context context, String favoritesJson, boolean force, Callback callback) {
        final Context app = context.getApplicationContext();
        final SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        final String today = ymd(Calendar.getInstance());
        final List<String> codes = parseCodes(favoritesJson);

        String cachedValue = prefs.getString(KEY_LAST_SUCCESS_PAYLOAD, "");
        if (cachedValue == null || cachedValue.isEmpty()) cachedValue = prefs.getString(LEGACY_KEY_LAST_PAYLOAD, "");
        final String cached = cachedValue == null ? "" : cachedValue;
        final String previousError = prefs.getString(KEY_LAST_ATTEMPT_ERROR, "");

        String lastAttemptDay = prefs.getString(KEY_LAST_ATTEMPT_DAY, "");
        if (lastAttemptDay == null || lastAttemptDay.isEmpty()) lastAttemptDay = prefs.getString(LEGACY_KEY_LAST_DAY, "");
        List<String> lastCodes = parseCodes(prefs.getString(KEY_LAST_ATTEMPT_CODES, "[]"));
        HashSet<String> previousSet = new HashSet<>(lastCodes);
        boolean hasNewFavorite = false;
        for (String code : codes) if (!previousSet.contains(code)) { hasNewFavorite = true; break; }

        // Normal reopen: no second network request on the same day.
        // Exception: if the user added a new favorite after today's check, refresh once so that stock
        // does not have to wait until tomorrow. Deletions alone do not trigger another JPX fetch.
        if (!force && today.equals(lastAttemptDay) && !hasNewFavorite) {
            callback.onResult(markCached(cached, today, previousError));
            return;
        }

        String attemptCodes = codesJson(codes);
        prefs.edit()
                .putString(KEY_LAST_ATTEMPT_DAY, today)
                .putString(KEY_LAST_ATTEMPT_CODES, attemptCodes)
                .apply();

        new Thread(() -> {
            String payload = fetchAll(codes, today, cached);
            try {
                JSONObject obj = new JSONObject(payload);
                SharedPreferences.Editor ed = prefs.edit();
                ed.putString(KEY_LAST_ATTEMPT_DAY, today)
                        .putString(KEY_LAST_ATTEMPT_CODES, attemptCodes);
                if (obj.optBoolean("ok", false)) {
                    ed.putString(KEY_LAST_SUCCESS_PAYLOAD, payload)
                            .remove(KEY_LAST_ATTEMPT_ERROR)
                            .remove(LEGACY_KEY_LAST_PAYLOAD);
                } else {
                    ed.putString(KEY_LAST_ATTEMPT_ERROR, obj.optString("error", "取得失敗"));
                }
                ed.apply();
            } catch (Exception ignored) { }
            callback.onResult(payload);
        }, "PinoWatch-JPX").start();
    }

    private static String codesJson(List<String> codes) {
        JSONArray a = new JSONArray();
        for (String code : codes) a.put(code);
        return a.toString();
    }

    private static String markCached(String cached, String today, String previousError) {
        try {
            JSONObject obj = cached == null || cached.isEmpty() ? new JSONObject() : new JSONObject(cached);
            if (!obj.has("items")) obj.put("items", new JSONArray());
            boolean hadError = previousError != null && !previousError.isEmpty();
            obj.put("ok", !hadError && !cached.isEmpty());
            obj.put("cached", true);
            obj.put("autoSkipped", true);
            obj.put("day", today);
            obj.put("attemptedAt", isoNow());
            if (hadError) obj.put("error", previousError);
            return obj.toString();
        } catch (Exception e) {
            return emptyResult(false, true, previousError == null ? "" : previousError);
        }
    }

    private static List<String> parseCodes(String raw) {
        ArrayList<String> out = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        try {
            JSONArray a = new JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < a.length() && out.size() < 100; i++) {
                String c = normCode(a.optString(i));
                if (c != null && seen.add(c)) out.add(c);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static String fetchAll(List<String> codes, String today, String cached) {
        long started = System.currentTimeMillis();
        if (codes.isEmpty()) {
            try {
                JSONObject o = new JSONObject(emptyResult(true, false, ""));
                o.put("fetchedAt", isoNow());
                o.put("attemptedAt", isoNow());
                o.put("day", today);
                return o.toString();
            } catch (Exception e) { return emptyResult(true, false, ""); }
        }

        String cookie;
        try { cookie = openSession(); }
        catch (Exception e) { return fallbackError(cached, "JPX接続失敗: " + safeMsg(e), today); }

        final String sessionCookie = cookie;
        // Up to eight concurrent JPX detail requests. This cuts a 100-favorite refresh to roughly 13 waves
        // while avoiding one thread per stock.
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(8, Math.max(1, codes.size())));
        ArrayList<Future<CodeResult>> futures = new ArrayList<>();
        for (String code : codes) futures.add(pool.submit((Callable<CodeResult>) () -> fetchOne(code, sessionCookie, today)));
        pool.shutdown();

        ArrayList<JSONObject> items = new ArrayList<>();
        JSONArray errors = new JSONArray();
        int successfulCodes = 0;
        Map<String, List<JSONObject>> cachedByCode = cachedItemsByCode(cached, today);
        for (int i = 0; i < futures.size(); i++) {
            String code = codes.get(i);
            try {
                CodeResult r = futures.get(i).get();
                if (r.error != null) {
                    errors.put(code + ": " + r.error);
                    List<JSONObject> old = cachedByCode.get(code);
                    if (old != null) items.addAll(copyWithStaleFlag(old));
                } else {
                    successfulCodes++;
                    items.addAll(r.items);
                }
            } catch (Exception e) {
                errors.put(code + ": " + safeMsg(e));
                List<JSONObject> old = cachedByCode.get(code);
                if (old != null) items.addAll(copyWithStaleFlag(old));
            }
        }

        // If every JPX request failed, this is a failed daily attempt, not a successful empty refresh.
        // Keep the last successful cache intact so the UI can clearly show that it is stale data.
        if (successfulCodes == 0) {
            return fallbackError(cached, "JPXから決算予定を取得できませんでした（" + errors.length() + "銘柄）", today);
        }

        // One batched secondary lookup per 25 favorites (max 4 requests for 100 stocks):
        // company-name enrichment + estimated release time from past earnings disclosures on TDnet.
        Enrichment enrichment = fetchTdnetEnrichment(codes);
        applyEnrichment(items, enrichment);

        Collections.sort(items, Comparator.comparing(EarningsScheduleService::sortKey));
        try {
            JSONObject out = new JSONObject();
            out.put("ok", true);
            out.put("cached", false);
            out.put("source", "JPX上場会社情報サービス");
            out.put("timeSource", "TDnet過去決算短信（推定）");
            out.put("fetchedAt", isoNow());
            out.put("attemptedAt", isoNow());
            out.put("day", today);
            out.put("durationMs", System.currentTimeMillis() - started);
            out.put("requestedCodes", codes.size());
            JSONArray arr = new JSONArray();
            for (JSONObject o : items) arr.put(o);
            out.put("items", arr);
            out.put("errors", errors);
            if (!enrichment.error.isEmpty()) out.put("enrichmentError", enrichment.error);
            return out.toString();
        } catch (Exception e) { return fallbackError(cached, "結果生成失敗", today); }
    }

    private static List<JSONObject> copyWithStaleFlag(List<JSONObject> rows) {
        ArrayList<JSONObject> out = new ArrayList<>();
        for (JSONObject row : rows) {
            try {
                JSONObject copy = new JSONObject(row.toString());
                copy.put("stale", true);
                out.add(copy);
            } catch (Exception ignored) { }
        }
        return out;
    }

    private static CodeResult fetchOne(String code, String cookie, String today) {
        try {
            String body = "BaseJh=BaseJh&mgrCd=" + URLEncoder.encode(code + "0", "UTF-8") + "&jjHisiFlg=1";
            HttpURLConnection c = (HttpURLConnection) new URL(DETAIL_URL).openConnection();
            c.setConnectTimeout(10000); c.setReadTimeout(12000); c.setInstanceFollowRedirects(true);
            c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setRequestProperty("User-Agent", "PinoWatch/1.16 Android");
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
            int status = c.getResponseCode();
            if (status < 200 || status >= 400) return new CodeResult(code, null, "HTTP " + status);
            String html = readText(c);
            Map<String, String> values = tableLabelValues(html);
            String company = firstValue(values, "銘柄名", "会社名", "上場会社名", "企業名");
            String parsedCode = firstValue(values, "コード", "証券コード", "銘柄コード");
            String normalizedParsedCode = normCode(parsedCode);
            if (values.isEmpty() || (company.isEmpty() && normalizedParsedCode == null)) {
                return new CodeResult(code, null, "JPXページ解析失敗");
            }
            if (normalizedParsedCode != null && !code.equals(normalizedParsedCode)) {
                return new CodeResult(code, null, "JPX銘柄コード不一致");
            }
            ArrayList<JSONObject> out = new ArrayList<>();
            addSchedule(out, values, code, company, today, "決算発表(予定)", "本決算");
            addSchedule(out, values, code, company, today, "第一四半期(予定)", "1Q");
            addSchedule(out, values, code, company, today, "第二四半期(予定)", "2Q");
            addSchedule(out, values, code, company, today, "第三四半期(予定)", "3Q");
            return new CodeResult(code, out, null);
        } catch (Exception e) { return new CodeResult(code, null, safeMsg(e)); }
    }

    private static String firstValue(Map<String,String> values, String... labels) {
        for (String label : labels) {
            String v = values.get(normText(label));
            if (v != null && !v.trim().isEmpty()) return v.trim();
        }
        return "";
    }

    private static void addSchedule(List<JSONObject> out, Map<String,String> values, String code, String company,
                                    String today, String label, String period) {
        String raw = values.get(normText(label));
        if (raw == null) {
            String prefix = normText(label.replace("(予定)", ""));
            for (Map.Entry<String,String> e : values.entrySet()) {
                if (e.getKey().startsWith(prefix)) { raw = e.getValue(); break; }
            }
        }
        String date = normalizeDate(raw);
        if (date == null || date.compareTo(today) < 0) return;
        try {
            JSONObject o = new JSONObject();
            o.put("code", code);
            o.put("company", company == null ? "" : company);
            o.put("date", date);
            o.put("period", period);
            o.put("time", "");
            o.put("timeEstimated", false);
            o.put("confirmed", true);
            o.put("source", "JPX");
            out.add(o);
        } catch (Exception ignored) { }
    }

    private static Enrichment fetchTdnetEnrichment(List<String> codes) {
        Enrichment merged = new Enrichment();
        if (codes.isEmpty()) return merged;
        ArrayList<List<String>> batches = new ArrayList<>();
        for (int i = 0; i < codes.size(); i += 25) batches.add(codes.subList(i, Math.min(codes.size(), i + 25)));
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(3, batches.size()));
        ArrayList<Future<Enrichment>> futures = new ArrayList<>();
        for (List<String> batch : batches) {
            ArrayList<String> copy = new ArrayList<>(batch);
            futures.add(pool.submit(() -> fetchTdnetBatch(copy)));
        }
        pool.shutdown();
        for (Future<Enrichment> f : futures) {
            try { merged.merge(f.get()); }
            catch (Exception e) { merged.appendError(safeMsg(e)); }
        }
        return merged;
    }

    private static Enrichment fetchTdnetBatch(List<String> codes) {
        Enrichment e = new Enrichment();
        if (codes.isEmpty()) return e;
        HttpURLConnection c = null;
        try {
            String condition = String.join("-", codes);
            URL u = new URL(TDNET_BASE + condition + ".json2?limit=300&hasXBRL=1");
            c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "PinoWatch/1.16 Android");
            int status = c.getResponseCode();
            if (status < 200 || status >= 400) { e.appendError("TDnet HTTP " + status); return e; }
            JSONObject root = new JSONObject(readText(c));
            JSONArray rows = root.optJSONArray("items");
            if (rows == null) return e;
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                JSONObject wrapped = row.optJSONObject("Tdnet");
                if (wrapped != null) row = wrapped;
                String code = normCode(row.optString("company_code"));
                if (code == null) continue;
                String company = row.optString("company_name", "").trim();
                if (!company.isEmpty() && !e.companyNames.containsKey(code)) e.companyNames.put(code, company);
                String title = row.optString("title", "");
                if (!title.contains("決算短信") || title.contains("訂正")) continue;
                String pub = row.optString("pubdate", "");
                Matcher tm = PUBDATE_TIME.matcher(pub);
                if (!tm.find()) continue;
                int h = Integer.parseInt(tm.group(1)), m = Integer.parseInt(tm.group(2));
                if (h < 0 || h > 23 || m < 0 || m > 59) continue;
                int minute = h * 60 + m;
                e.times.computeIfAbsent(code, k -> new ArrayList<>()).add(minute);
                String historicalPeriod = periodFromTitle(title);
                e.periodTimes.computeIfAbsent(code + "|" + historicalPeriod, k -> new ArrayList<>()).add(minute);
            }
        } catch (Exception ex) { e.appendError(safeMsg(ex)); }
        finally { if (c != null) c.disconnect(); }
        return e;
    }

    private static void applyEnrichment(List<JSONObject> items, Enrichment enrichment) {
        for (JSONObject o : items) {
            try {
                String code = normCode(o.optString("code"));
                if (code == null) continue;
                if (o.optString("company", "").trim().isEmpty()) {
                    String name = enrichment.companyNames.get(code);
                    if (name != null) o.put("company", name);
                }
                if (o.optString("time", "").isEmpty()) {
                    String period = o.optString("period", "");
                    List<Integer> samePeriod = enrichment.periodTimes.get(code + "|" + period);
                    List<Integer> all = enrichment.times.get(code);
                    List<Integer> samples = null;
                    String confidence = "";
                    if (samePeriod != null && samePeriod.size() >= 2) {
                        samples = samePeriod;
                        confidence = samePeriod.size() >= 3 ? "高" : "中";
                    } else if (all != null && all.size() >= 3) {
                        samples = all;
                        confidence = "低";
                    }
                    // One historical disclosure is too weak to present as a time estimate.
                    if (samples != null) {
                        int minute = estimateMinute(samples);
                        o.put("time", String.format(Locale.US, "%02d:%02d", minute / 60, minute % 60));
                        o.put("timeEstimated", true);
                        o.put("timeSource", "TDnet過去決算短信から推定");
                        o.put("timeSamples", Math.min(samples.size(), 12));
                        o.put("timeConfidence", confidence);
                    }
                }
            } catch (Exception ignored) { }
        }
    }

    private static String periodFromTitle(String title) {
        String t = Normalizer.normalize(title == null ? "" : title, Normalizer.Form.NFKC);
        if (t.contains("第1四半期")) return "1Q";
        if (t.contains("第2四半期") || t.contains("中間期")) return "2Q";
        if (t.contains("第3四半期")) return "3Q";
        return "本決算";
    }

    private static int estimateMinute(List<Integer> raw) {
        ArrayList<Integer> a = new ArrayList<>(raw);
        // Limit to the latest results returned by the API; using a mode first preserves companies that release at a stable time.
        if (a.size() > 12) a = new ArrayList<>(a.subList(0, 12));
        HashMap<Integer,Integer> count = new HashMap<>();
        int best = a.get(0), bestCount = 0;
        for (int v : a) {
            int n = count.getOrDefault(v, 0) + 1;
            count.put(v, n);
            if (n > bestCount) { bestCount = n; best = v; }
        }
        if (bestCount >= 2) return best;
        Collections.sort(a);
        return a.get(a.size() / 2);
    }

    private static String openSession() throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(SEARCH_URL).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(12000); c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "PinoWatch/1.16 Android");
        int status = c.getResponseCode();
        if (status < 200 || status >= 400) throw new Exception("HTTP " + status);
        try (InputStream in = c.getInputStream()) { byte[] b = new byte[4096]; while (in.read(b) >= 0) { } }
        Map<String,List<String>> headers = c.getHeaderFields();
        if (headers != null) for (Map.Entry<String,List<String>> h : headers.entrySet()) {
            if (h.getKey() == null || !"set-cookie".equalsIgnoreCase(h.getKey())) continue;
            for (String v : h.getValue()) {
                Matcher m = Pattern.compile("(?i)JSESSIONID=([^;]+)").matcher(v == null ? "" : v);
                if (m.find()) return "JSESSIONID=" + m.group(1);
            }
        }
        return "";
    }

    private static Map<String,String> tableLabelValues(String html) {
        HashMap<String,String> out = new HashMap<>();
        Matcher tm = TABLE.matcher(html == null ? "" : html);
        while (tm.find()) {
            ArrayList<String> rows = new ArrayList<>();
            Matcher rm = ROW.matcher(tm.group(1));
            while (rm.find()) rows.add(rm.group(1));

            // JPX has used both layouts over time:
            // (a) <tr><th>label</th><td>value</td></tr>
            // (b) a header-only row followed by a td-only value row.
            // Support both so a harmless markup change does not silently blank the calendar.
            for (String row : rows) {
                ArrayList<String> hs = captures(TH, row);
                ArrayList<String> ds = captures(TD, row);
                if (hs.isEmpty() || ds.isEmpty()) continue;
                int n = Math.min(hs.size(), ds.size());
                for (int j = 0; j < n; j++) putLabelValue(out, hs.get(j), ds.get(j));
            }
            for (int i = 0; i + 1 < rows.size(); i++) {
                ArrayList<String> hs = captures(TH, rows.get(i));
                ArrayList<String> sameRowDs = captures(TD, rows.get(i));
                if (hs.isEmpty() || !sameRowDs.isEmpty()) continue;
                ArrayList<String> ds = captures(TD, rows.get(i + 1));
                if (ds.isEmpty()) continue;
                int n = Math.min(hs.size(), ds.size());
                for (int j = 0; j < n; j++) putLabelValue(out, hs.get(j), ds.get(j));
            }
        }
        return out;
    }

    private static void putLabelValue(Map<String,String> out, String rawKey, String rawValue) {
        String key = normText(stripHtml(rawKey));
        String value = stripHtml(rawValue);
        if (!key.isEmpty() && !value.isEmpty()) out.put(key, value);
    }

    private static ArrayList<String> captures(Pattern p, String s) {
        ArrayList<String> a=new ArrayList<>(); Matcher m=p.matcher(s); while(m.find())a.add(m.group(1)); return a;
    }
    private static String stripHtml(String s) {
        if (s == null) return "";
        String x=s.replaceAll("(?is)<script\\b.*?</script>"," ").replaceAll("(?is)<style\\b.*?</style>"," ").replaceAll("(?i)<br\\s*/?>"," ").replaceAll("(?is)<[^>]+>"," ");
        x=x.replace("&nbsp;"," ").replace("&#160;"," ").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&#39;","'").replace("&apos;","'");
        Matcher m=Pattern.compile("&#(\\d+);").matcher(x); StringBuffer b=new StringBuffer();
        while(m.find()){int v;try{v=Integer.parseInt(m.group(1));}catch(Exception e){v=32;}m.appendReplacement(b,Matcher.quoteReplacement(String.valueOf((char)v)));}m.appendTail(b);
        return b.toString().replaceAll("\\s+"," ").trim();
    }
    private static String normText(String s) { return Normalizer.normalize(String.valueOf(s == null ? "" : s), Normalizer.Form.NFKC).replace("（","(").replace("）",")").replaceAll("\\s+","").trim(); }
    private static String normalizeDate(String s) { Matcher m=DATE.matcher(normText(s)); return m.find()?String.format(Locale.US,"%s-%02d-%02d",m.group(1),Integer.parseInt(m.group(2)),Integer.parseInt(m.group(3))):null; }
    private static String normCode(String s) { String x=Normalizer.normalize(String.valueOf(s==null?"":s),Normalizer.Form.NFKC).trim().toUpperCase(Locale.US); if(x.matches("[0-9A-Z]{5}")&&x.endsWith("0"))x=x.substring(0,4); return x.matches("[0-9]{3}[0-9A-Z]")?x:null; }
    private static String ymd(Calendar c) { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime()); }
    private static String isoNow() { return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Calendar.getInstance().getTime()); }
    private static String safeMsg(Throwable e) { String s=e==null?"error":String.valueOf(e.getMessage()); return s.length()>160?s.substring(0,160):s; }
    private static String sortKey(JSONObject o) { return o.optString("date")+"T"+(o.optString("time").isEmpty()?"23:59":o.optString("time"))+"|"+o.optString("code"); }

    private static String readText(HttpURLConnection c) throws Exception {
        byte[] bytes; try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);bytes=out.toByteArray();}
        String cs="UTF-8"; String ct=c.getContentType(); if(ct!=null){Matcher m=CHARSET.matcher(ct);if(m.find())cs=m.group(1);}
        try{return new String(bytes, Charset.forName(cs));}catch(Exception e){return new String(bytes,StandardCharsets.UTF_8);} }

    private static Map<String,List<JSONObject>> cachedItemsByCode(String cached, String today) {
        HashMap<String,List<JSONObject>> out=new HashMap<>();
        try{
            JSONObject p=new JSONObject(cached==null?"":cached); JSONArray a=p.optJSONArray("items"); if(a==null)return out;
            for(int i=0;i<a.length();i++){
                JSONObject o=a.optJSONObject(i); if(o==null||o.optString("date").compareTo(today)<0)continue;
                String c=normCode(o.optString("code")); if(c==null)continue;
                out.computeIfAbsent(c,k->new ArrayList<>()).add(o);
            }
        }catch(Exception ignored){}
        return out;
    }

    private static String fallbackError(String cached, String message, String today) {
        try{
            JSONObject p=cached==null||cached.isEmpty()?new JSONObject():new JSONObject(cached);
            if(!p.has("items"))p.put("items",new JSONArray());
            p.put("ok",false); p.put("cached",true); p.put("day",today); p.put("attemptedAt",isoNow()); p.put("error",message);
            return p.toString();
        }catch(Exception e){return emptyResult(false,true,message);}
    }

    private static String emptyResult(boolean ok, boolean cached, String error) {
        try{
            JSONObject o=new JSONObject(); o.put("ok",ok); o.put("cached",cached); o.put("items",new JSONArray()); o.put("attemptedAt",isoNow());
            if(error!=null&&!error.isEmpty())o.put("error",error); return o.toString();
        }catch(Exception e){return "{\"ok\":false,\"items\":[]}";}
    }

    private static final class CodeResult {
        final String code; final List<JSONObject> items; final String error;
        CodeResult(String c,List<JSONObject> i,String e){code=c;items=i==null?Collections.emptyList():i;error=e;}
    }

    private static final class Enrichment {
        final Map<String,String> companyNames = new HashMap<>();
        final Map<String,List<Integer>> times = new HashMap<>();
        final Map<String,List<Integer>> periodTimes = new HashMap<>();
        String error = "";
        void appendError(String s) { if (s == null || s.isEmpty()) return; error += (error.isEmpty()?"":" / ") + s; }
        void merge(Enrichment other) {
            if (other == null) return;
            for (Map.Entry<String,String> x : other.companyNames.entrySet()) companyNames.putIfAbsent(x.getKey(), x.getValue());
            for (Map.Entry<String,List<Integer>> x : other.times.entrySet()) times.computeIfAbsent(x.getKey(),k->new ArrayList<>()).addAll(x.getValue());
            for (Map.Entry<String,List<Integer>> x : other.periodTimes.entrySet()) periodTimes.computeIfAbsent(x.getKey(),k->new ArrayList<>()).addAll(x.getValue());
            appendError(other.error);
        }
    }
}
