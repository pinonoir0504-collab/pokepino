package com.tdwatch.stockwatchv4;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

final class PushRegistration {
    static final String WORKER_URL = "https://pinowatch-notifier.deespnow.workers.dev/register";
    static final String KEY = "pinowatch-7f3c9a82-d651-4e77-bc28-105a94d638fe";
    private static final long REFRESH_MS = 24L * 60L * 60L * 1000L;
    private PushRegistration() {}

    static boolean savePreferences(Context context, String favoritesJson, boolean favoritesOnly, boolean enabled,
                                   String categoriesJson, boolean prev20) {
        SharedPreferences prefs = context.getSharedPreferences("push", Context.MODE_PRIVATE);
        boolean oldEnabled = prefs.getBoolean("enabled", true);
        String oldCats = prefs.getString("categories", "");
        boolean changed = !prefs.contains("favorites") || !favoritesJson.equals(prefs.getString("favorites", "[]"))
                || favoritesOnly != prefs.getBoolean("favoritesOnly", true)
                || enabled != oldEnabled
                || !String.valueOf(categoriesJson).equals(String.valueOf(oldCats))
                || prev20 != prefs.getBoolean("prev20", true);
        prefs.edit()
                .putString("favorites", favoritesJson)
                .putBoolean("favoritesOnly", favoritesOnly)
                .putBoolean("enabled", enabled)
                .putString("categories", categoriesJson == null ? "" : categoriesJson)
                .putBoolean("prev20", prev20)
                .apply();
        NotificationReliability.onMasterSettingChanged(context, oldEnabled, enabled);
        return changed;
    }

    static void registerAsync(Context context, String token) {
        if (token == null || token.isEmpty()) return;
        Context app = context.getApplicationContext();
        new Thread(() -> registerBlocking(app, token), "PinoWatch-PushRegister").start();
    }

    static boolean registerBlocking(Context context, String token) {
        if (token == null || token.isEmpty()) return false;
        HttpURLConnection c = null;
        try {
            SharedPreferences p = context.getSharedPreferences("push", Context.MODE_PRIVATE);
            JSONObject body = new JSONObject();
            body.put("registrationKey", KEY);
            body.put("token", token);
            body.put("favorites", new org.json.JSONArray(p.getString("favorites", "[]")));
            body.put("favoritesOnly", p.getBoolean("favoritesOnly", true));
            body.put("enabled", p.getBoolean("enabled", true));
            // Worker v1.13 ignores these extra fields safely; Android itself enforces them as a second filter.
            body.put("categories", new JSONObject(p.getString("categories", "{}")));
            body.put("prev20", p.getBoolean("prev20", true));

            c = (HttpURLConnection)new URL(WORKER_URL).openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(15000);
            c.setReadTimeout(15000);
            c.setRequestProperty("Content-Type", "application/json");
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = c.getOutputStream()) { out.write(data); }
            int status = c.getResponseCode();
            boolean ok = status >= 200 && status < 300;
            p.edit()
                    .putString("registrationStatus", ok ? "登録済み" : "登録失敗 HTTP " + status)
                    .putLong("registeredAt", System.currentTimeMillis())
                    .putString("lastToken", token)
                    .apply();
            return ok;
        } catch (Exception error) {
            context.getSharedPreferences("push", Context.MODE_PRIVATE).edit()
                    .putString("registrationStatus", "通信エラー")
                    .putLong("lastRegistrationErrorAt", System.currentTimeMillis())
                    .apply();
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static boolean needsRefresh(Context context) {
        SharedPreferences p = context.getSharedPreferences("push", Context.MODE_PRIVATE);
        String status = p.getString("registrationStatus", "");
        long at = p.getLong("registeredAt", 0L);
        return !"登録済み".equals(status) || at <= 0L || System.currentTimeMillis() - at > REFRESH_MS;
    }

    static String status(Context context) {
        SharedPreferences p = context.getSharedPreferences("push", Context.MODE_PRIVATE);
        String s = p.getString("registrationStatus", "登録処理中");
        long at = p.getLong("registeredAt", 0L);
        if (at > 0L && "登録済み".equals(s)) {
            long hours = Math.max(0L, (System.currentTimeMillis() - at) / 3600000L);
            return s + "（" + hours + "時間前更新）";
        }
        return s;
    }
}
