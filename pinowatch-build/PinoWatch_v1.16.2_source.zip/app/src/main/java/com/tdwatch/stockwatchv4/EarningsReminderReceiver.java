package com.tdwatch.stockwatchv4;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public final class EarningsReminderReceiver extends BroadcastReceiver {
    private static final String ACTION_REMINDER = "com.tdwatch.stockwatchv4.EARNINGS_REMINDER";
    private static final String PREFS = "earnings_reminder";
    private static final String KEY_SCHEDULE = "schedule_json";
    private static final String KEY_LAST_NOTIFY_DAY = "last_notify_day";
    private static final String KEY_LAST_NOTIFY_HASH = "last_notify_hash";
    private static final String KEY_NEXT_ALARM_AT = "next_alarm_at";
    private static final String FALLBACK_WORK = "pinowatch-earnings-reminder-fallback-v116";
    private static final int REQUEST_CODE = 2000;
    private static final int NOTIFICATION_ID = 2001;
    private static final String CHANNEL_ID = "earnings_reminders";

    static void saveSchedule(Context context, String scheduleJson) {
        if (scheduleJson == null) scheduleJson = "[]";
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_SCHEDULE, scheduleJson).apply();
        catchUpAndSchedule(context);
    }

    static void catchUpAndSchedule(Context context) {
        Context app = context.getApplicationContext();
        if (!NotificationReliability.earningsReminderEnabled(app)) {
            cancelSchedules(app);
            return;
        }
        maybeNotifyIfPastEight(app);
        scheduleNext(app);
        scheduleFallback(app);
    }

    static void runFallback(Context context) {
        Context app = context.getApplicationContext();
        if (!NotificationReliability.earningsReminderEnabled(app)) {
            cancelSchedules(app);
            return;
        }
        Calendar now = Calendar.getInstance();
        if (now.get(Calendar.HOUR_OF_DAY) >= 20) notifyTomorrowIfNeeded(app, now);
        scheduleNext(app);
        scheduleFallback(app);
    }

    private static void cancelSchedules(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            Intent intent = new Intent(context, EarningsReminderReceiver.class).setAction(ACTION_REMINDER);
            PendingIntent pi = PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                    PendingIntent.FLAG_NO_CREATE | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            if (pi != null) am.cancel(pi);
        }
        WorkManager.getInstance(context).cancelUniqueWork(FALLBACK_WORK);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_NEXT_ALARM_AT).apply();
    }

    static void scheduleNext(Context context) {
        if (!NotificationReliability.earningsReminderEnabled(context)) {
            cancelSchedules(context);
            return;
        }
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Calendar next = nextTime(20, 0);

        Intent intent = new Intent(context, EarningsReminderReceiver.class).setAction(ACTION_REMINDER);
        PendingIntent pi = PendingIntent.getBroadcast(context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        long when = next.getTimeInMillis();
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                }
            } else if (Build.VERSION.SDK_INT >= 23) {
                // Android 6-11 do not need special-access permission for exact alarms.
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (SecurityException ignored) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putLong(KEY_NEXT_ALARM_AT, when).apply();
    }

    private static void scheduleFallback(Context context) {
        if (!NotificationReliability.earningsReminderEnabled(context)) return;
        Calendar fallback = nextTime(20, 10);
        long delay = Math.max(0L, fallback.getTimeInMillis() - System.currentTimeMillis());
        OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(EarningsReminderWorker.class)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .build();
        WorkManager.getInstance(context).enqueueUniqueWork(
                FALLBACK_WORK, ExistingWorkPolicy.REPLACE, work);
    }

    private static Calendar nextTime(int hour, int minute) {
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, hour);
        next.set(Calendar.MINUTE, minute);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_MONTH, 1);
        return next;
    }

    private static String ymd(Calendar c) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    private static void maybeNotifyIfPastEight(Context context) {
        Calendar now = Calendar.getInstance();
        if (now.get(Calendar.HOUR_OF_DAY) < 20) return;
        notifyTomorrowIfNeeded(context, now);
    }

    private static void notifyTomorrowIfNeeded(Context context, Calendar now) {
        createChannel(context);
        if (!NotificationReliability.earningsReminderEnabled(context)
                || !NotificationReliability.earningsNotificationsAllowed(context)) return;

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = ymd(now);
        Calendar tomorrow = (Calendar) now.clone();
        tomorrow.add(Calendar.DAY_OF_MONTH, 1);
        String targetDate = ymd(tomorrow);

        String raw = prefs.getString(KEY_SCHEDULE, "[]");
        Set<String> labelSet = new LinkedHashSet<>();
        try {
            JSONArray rows = new JSONArray(raw);
            for (int i = 0; i < rows.length(); i++) {
                JSONObject o = rows.optJSONObject(i);
                if (o == null || !targetDate.equals(o.optString("date"))) continue;
                String code = o.optString("code").trim();
                String company = o.optString("company").trim();
                String time = o.optString("time").trim();
                boolean timeEstimated = o.optBoolean("timeEstimated", false);
                String confidence = o.optString("timeConfidence", "");
                String period = o.optString("period").trim();
                String label = (code + " " + company).trim();
                String detail = period;
                if (!time.isEmpty()) {
                    detail += (detail.isEmpty() ? "" : "・") + time
                            + (timeEstimated ? "頃(推定" + (confidence.isEmpty() ? "" : "・" + confidence) + ")" : "");
                }
                if (!detail.isEmpty()) label += "（" + detail + "）";
                if (!label.isEmpty()) labelSet.add(label);
            }
        } catch (Exception ignored) { }

        List<String> labels = new ArrayList<>(labelSet);
        String contentHash = Integer.toHexString((targetDate + "|" + String.join("|", labels)).hashCode());
        String lastDay = prefs.getString(KEY_LAST_NOTIFY_DAY, "");
        String lastHash = prefs.getString(KEY_LAST_NOTIFY_HASH, "");

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (labels.isEmpty()) {
            // If favorites/schedule changed after 20:00, remove an already-posted reminder that is no longer valid.
            if (today.equals(lastDay) && nm != null) nm.cancel(NOTIFICATION_ID);
            if (today.equals(lastDay)) prefs.edit().remove(KEY_LAST_NOTIFY_DAY).remove(KEY_LAST_NOTIFY_HASH).apply();
            return;
        }
        if (today.equals(lastDay) && contentHash.equals(lastHash)) return;

        createChannel(context);
        int shown = Math.min(labels.size(), 12);
        StringBuilder body = new StringBuilder();
        for (int i = 0; i < shown; i++) {
            if (i > 0) body.append('\n');
            body.append("・").append(labels.get(i));
        }
        if (labels.size() > shown) body.append("\nほか").append(labels.size() - shown).append("社");

        Intent open = new Intent(context, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(context, NOTIFICATION_ID, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle("明日決算：" + labels.size() + "社")
                .setContentText(labels.get(0))
                .setStyle(new Notification.BigTextStyle().bigText(body.toString()))
                .setContentIntent(content)
                .setAutoCancel(true)
                .setOnlyAlertOnce(today.equals(lastDay))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setPriority(Notification.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis());

        if (nm == null) return;
        try {
            nm.notify(NOTIFICATION_ID, b.build());
            prefs.edit()
                    .putString(KEY_LAST_NOTIFY_DAY, today)
                    .putString(KEY_LAST_NOTIFY_HASH, contentHash)
                    .putLong("last_notify_at", System.currentTimeMillis())
                    .apply();
        } catch (SecurityException ignored) {
            // Do not mark as sent. Permission can be granted later and catch-up will retry.
        }
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID, "明日の決算予定", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("お気に入り銘柄の翌日の決算予定を前日20時にまとめて通知します");
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        NotificationReliability.ensureBackgroundWork(context);
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) DisclosureCatchUpWorker.enqueueNow(context);
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            catchUpAndSchedule(context);
            return;
        }
        notifyTomorrowIfNeeded(context, Calendar.getInstance());
        scheduleNext(context);
        scheduleFallback(context);
    }
}
