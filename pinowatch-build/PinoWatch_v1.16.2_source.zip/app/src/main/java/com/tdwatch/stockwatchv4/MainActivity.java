package com.tdwatch.stockwatchv4;

import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private WebView webView;
    private boolean pageReady;
    private String pendingInitialOpenUrl;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        NotificationReliability.createDisclosureChannel(this);
        NotificationReliability.ensureBackgroundWork(this);
        DisclosureCatchUpWorker.enqueueNow(this);
        EarningsReminderReceiver.catchUpAndSchedule(this);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 42);
        }

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setAllowContentAccess(false);
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest r) {
                return blockUnknown(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String u) {
                return blockUnknown(Uri.parse(u));
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageReady = url != null && url.startsWith("file:///android_asset/");
                if (pageReady) {
                    notifyJsResume();
                    if (pendingInitialOpenUrl != null) {
                        String target = pendingInitialOpenUrl;
                        pendingInitialOpenUrl = null;
                        view.loadUrl(target);
                    }
                }
            }
        });
        setContentView(webView);
        openIntent(getIntent(), true);

        FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(t -> PushRegistration.registerAsync(this, t));
    }

    @Override protected void onResume() {
        super.onResume();
        NotificationReliability.ensureBackgroundWork(this);
        if (NotificationReliability.catchupStale(this, 5L * 60L * 1000L)) {
            DisclosureCatchUpWorker.enqueueNow(this);
        }
        EarningsReminderReceiver.catchUpAndSchedule(this);
        notifyJsResume();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        openIntent(intent, false);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 42 && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            EarningsReminderReceiver.catchUpAndSchedule(this);
            DisclosureCatchUpWorker.enqueueNow(this);
        }
    }

    private void notifyJsResume() {
        if (!pageReady || webView == null) return;
        webView.evaluateJavascript(
                "window.PinoNative&&window.PinoNative.onAppResume&&window.PinoNative.onAppResume();", null);
    }

    private void openIntent(Intent intent, boolean initial) {
        String u = intent == null ? null : intent.getStringExtra("open_url");
        if (u == null && intent != null) u = intent.getStringExtra("url");
        if (initial) {
            // Keep the app shell in WebView history so Back returns to PinoWatch after a cold-start notification tap.
            pendingInitialOpenUrl = u != null && u.startsWith("https://") ? u : null;
            webView.loadUrl("file:///android_asset/index.html");
        } else if (u != null && u.startsWith("https://")) {
            webView.loadUrl(u);
        }
    }

    private boolean blockUnknown(Uri uri) {
        String scheme = uri == null ? null : uri.getScheme();
        // Keep external disclosure pages inside the in-app browser as requested.
        return !("file".equalsIgnoreCase(scheme)
                || "https".equalsIgnoreCase(scheme)
                || "http".equalsIgnoreCase(scheme));
    }

    private final class NativeBridge {
        @JavascriptInterface public void syncPushPreferences(
                String favoritesJson, boolean favoritesOnly, boolean enabled,
                String categoriesJson, boolean prev20) {
            boolean changed = PushRegistration.savePreferences(
                    MainActivity.this, favoritesJson, favoritesOnly, enabled, categoriesJson, prev20);
            EarningsReminderReceiver.catchUpAndSchedule(MainActivity.this);
            NotificationReliability.ensureBackgroundWork(MainActivity.this);
            if (changed) {
                FirebaseMessaging.getInstance().getToken()
                        .addOnSuccessListener(t -> PushRegistration.registerAsync(MainActivity.this, t));
                DisclosureCatchUpWorker.enqueueNow(MainActivity.this);
            }
        }

        @JavascriptInterface public String getPushStatus() {
            return PushRegistration.status(MainActivity.this);
        }

        @JavascriptInterface public String getNotificationDiagnostics() {
            return NotificationReliability.diagnostics(MainActivity.this);
        }

        @JavascriptInterface public void requestExactAlarmAccess() {
            if (Build.VERSION.SDK_INT < 31) return;
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null && am.canScheduleExactAlarms()) return;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) {
                    try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored2) {}
                }
            });
        }

        @JavascriptInterface public void requestEarningsSchedule(String favoritesJson, boolean force) {
            EarningsScheduleService.request(MainActivity.this, favoritesJson, force,
                    payload -> runOnUiThread(() -> {
                        if (webView == null) return;
                        String quoted = JSONObject.quote(payload);
                        webView.evaluateJavascript(
                                "window.PinoNative&&window.PinoNative.onEarningsResult(" + quoted + ");", null);
                    }));
        }

        @JavascriptInterface public void syncEarningsSchedule(String scheduleJson) {
            EarningsReminderReceiver.saveSchedule(MainActivity.this, scheduleJson);
        }

        @JavascriptInterface public boolean notifyDisclosure(String title, String body, String url) {
            boolean test = title != null && title.contains("テスト通知");
            return NotificationReliability.notifyDisclosure(
                    MainActivity.this, title, body, url, test ? "test" : "foreground", test);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
