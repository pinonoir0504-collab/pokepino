package com.tdwatch.stockwatchv4;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public final class PinoFirebaseService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) {
        PushRegistration.registerAsync(this, token);
    }

    @Override public void onDeletedMessages() {
        // FCM tells us that some pending messages were dropped. The periodic catch-up worker
        // will recover matching TDnet disclosures; ask WorkManager to run as soon as constraints allow.
        NotificationReliability.recordCatchup(this, "FCM取りこぼし通知を検知・回収待ち", 0);
        NotificationReliability.ensureBackgroundWork(this);
        DisclosureCatchUpWorker.enqueueNow(this);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        NotificationReliability.recordFcmReceived(this);

        String company = message.getData().get("company");
        String disclosureTitle = message.getData().get("title");
        String url = message.getData().get("url");

        // Fallback for non-data messages, while preferring the data payload used by PinoWatch Worker.
        if ((company == null || company.isEmpty()) && message.getNotification() != null)
            company = message.getNotification().getTitle();
        if ((disclosureTitle == null || disclosureTitle.isEmpty()) && message.getNotification() != null)
            disclosureTitle = message.getNotification().getBody();

        String stableKey = NotificationReliability.stableKey(url, company, disclosureTitle);
        if (NotificationReliability.sentBeforeLastReenable(this, message.getSentTime())) {
            NotificationReliability.markSeen(this, stableKey);
            return;
        }

        if (!NotificationReliability.matchesPreferences(this, company, disclosureTitle)) {
            NotificationReliability.markSeen(this, stableKey);
            return;
        }
        NotificationReliability.notifyDisclosure(
                this,
                company == null || company.trim().isEmpty() ? "ピノウォッチ" : company,
                disclosureTitle == null ? "" : disclosureTitle,
                url,
                "fcm",
                false);
    }
}
