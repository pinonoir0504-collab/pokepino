package com.tdwatch.stockwatchv4;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public final class EarningsReminderWorker extends Worker {
    public EarningsReminderWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull @Override public Result doWork() {
        EarningsReminderReceiver.runFallback(getApplicationContext());
        return Result.success();
    }
}
