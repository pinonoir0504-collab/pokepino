(()=>{
'use strict';
const API_BASE='https://webapi.yanoshin.jp/webapi/tdnet/list';
const API=`${API_BASE}/recent.json2?limit=300`;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const STORE='tdwatch_v13_preview';
const defaults={favorites:[],prefs:{enabled:true,favoritesOnly:true,groupSameCompany:true,prev20:true,same8:false,before30:false,categories:{earnings:true,revision:true,dividend:true,buyback:true,split:true,benefit:true,tob:true,ma:true,personnel:false,presentation:false,governance:false,other:false}},history:[],lastSeen:[],lastFetch:null,cachedFeed:[],cachedFavoriteFeed:[],companyNames:{},earningsSchedule:[],earningsLastSync:null,earningsLastAutoFetchDay:null,earningsLastAttempt:null,earningsLastError:null};
let state, feed=[], favoriteFeed=[], filter='all', monthOffset=0, selectedDate=localYmd(new Date()), liveSource=false, earningsRefreshing=false;
const categoryDefs=[['earnings','決算短信'],['revision','業績予想修正'],['dividend','配当・増配・減配'],['buyback','自己株式取得・消却'],['split','株式分割・併合'],['benefit','株主優待'],['tob','TOB・MBO'],['ma','M&A・業務提携'],['personnel','人事'],['presentation','決算説明資料'],['governance','ガバナンス報告書'],['other','その他']];
let storageOK=true;
state=load();
function validRow(o){return !!(o&&typeof o==='object'&&!Array.isArray(o)&&typeof o.title==='string'&&rowCode(o))}
function load(){const base=JSON.parse(JSON.stringify(defaults));try{const parsed=JSON.parse(localStorage.getItem(STORE)||'{}');const raw=parsed&&typeof parsed==='object'&&!Array.isArray(parsed)?parsed:{};const prefs=raw.prefs&&typeof raw.prefs==='object'?raw.prefs:{};const out={...base};for(const k of Object.keys(base.prefs)){if(k!=='categories'&&typeof prefs[k]==='boolean')out.prefs[k]=prefs[k]}const cats=prefs.categories&&typeof prefs.categories==='object'?prefs.categories:{};for(const k of Object.keys(base.prefs.categories)){if(typeof cats[k]==='boolean')out.prefs.categories[k]=cats[k]}out.favorites=Array.isArray(raw.favorites)?[...new Set(raw.favorites.map(normCode).filter(Boolean))].slice(0,100):[];out.history=Array.isArray(raw.history)?raw.history.filter(x=>x&&typeof x==='object'&&!Array.isArray(x)&&typeof x.title==='string'&&typeof x.body==='string'&&typeof x.at==='string'&&Number.isFinite(Date.parse(x.at))).slice(0,200).map(x=>({...x,read:x.read===true})):[];out.lastSeen=Array.isArray(raw.lastSeen)?[...new Set(raw.lastSeen.filter(x=>typeof x==='string'))].slice(0,1000):[];out.initialized=raw.initialized===true||out.lastSeen.length>0;out.lastFetch=typeof raw.lastFetch==='string'&&Number.isFinite(Date.parse(raw.lastFetch))?raw.lastFetch:null;out.cachedFeed=Array.isArray(raw.cachedFeed)?raw.cachedFeed.filter(validRow).slice(0,300):[];out.cachedFavoriteFeed=Array.isArray(raw.cachedFavoriteFeed)?raw.cachedFavoriteFeed.filter(validRow).slice(0,300):[];out.earningsSchedule=Array.isArray(raw.earningsSchedule)?raw.earningsSchedule.filter(x=>x&&/^\d{4}-\d{2}-\d{2}$/.test(x.date)&&normCode(x.code)&&x.period).map(x=>({...x,code:normCode(x.code)})):[];out.earningsLastSync=typeof raw.earningsLastSync==='string'?raw.earningsLastSync:null;out.earningsLastAutoFetchDay=typeof raw.earningsLastAutoFetchDay==='string'?raw.earningsLastAutoFetchDay:null;out.earningsLastAttempt=typeof raw.earningsLastAttempt==='string'?raw.earningsLastAttempt:null;out.earningsLastError=typeof raw.earningsLastError==='string'?raw.earningsLastError:null;const names=raw.companyNames&&typeof raw.companyNames==='object'&&!Array.isArray(raw.companyNames)?raw.companyNames:{};out.companyNames=Object.fromEntries(Object.entries(names).map(([k,v])=>[normCode(k),String(v||'').trim()]).filter(([k,v])=>k&&v).slice(0,1000));return out}catch(e){storageOK=false;return base}}
function save(){try{localStorage.setItem(STORE,JSON.stringify(state));storageOK=true;syncPush()}catch(e){storageOK=false;toast('保存できません。空き容量を確認してください')}}
function syncPush(){if(window.AndroidBridge&&typeof window.AndroidBridge.syncPushPreferences==='function'){try{window.AndroidBridge.syncPushPreferences(JSON.stringify(state.favorites),!!state.prefs.favoritesOnly,!!state.prefs.enabled,JSON.stringify(state.prefs.categories||{}),!!state.prefs.prev20)}catch(e){}}}
function localYmd(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function toast(t){const el=$('#toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2200)}
function normCode(v){let s=String(v??'').normalize('NFKC').trim().toUpperCase(); if(/^[0-9A-Z]{5}$/.test(s)&&s.endsWith('0'))s=s.slice(0,-1);return /^[0-9]{3}[0-9A-Z]$/.test(s)?s:null}
function cat(t){t=String(t||'');const c=[];if(/決算短信/.test(t))c.push('earnings');if(/業績予想.*修正|通期.*予想.*修正/.test(t))c.push('revision');if(/配当|増配|減配/.test(t))c.push('dividend');if(/自己株式.*(取得|消却)|自己株買/.test(t))c.push('buyback');if(/株式分割|株式併合/.test(t))c.push('split');if(/株主優待/.test(t))c.push('benefit');if(/TOB|公開買付|MBO/.test(t))c.push('tob');if(!/自己株式/.test(t)&&/株式取得|子会社化|業務提携|資本提携|合併|会社分割/.test(t))c.push('ma');if(/人事|役員.*異動|代表取締役/.test(t))c.push('personnel');if(/決算説明資料/.test(t))c.push('presentation');if(/コーポレート.?ガバナンス|ガバナンス報告書/.test(t))c.push('governance');return c.length?[...new Set(c)]:['other']}
function rowCode(o){return normCode(o.company_code||o.companyCode||'')||''}
function rowTime(o){return String(o.pubdate||o.publishedAt||'').replace('T',' ')}
function rowUrl(o){return o.document_url||o.documentUrl||''}
function isFav(o){return state.favorites.includes(rowCode(o))}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function itemHtml(o){const code=rowCode(o), cs=cat(o.title), fav=isFav(o);const time=(rowTime(o).split(' ')[1]||rowTime(o)).slice(0,5);return `<div class="item" data-url="${esc(rowUrl(o))}"><div class="itemHead"><button class="starBtn ${fav?'favStar':''}" data-fav-code="${esc(code)}" aria-label="お気に入り切替">${fav?'★':'☆'}</button><span class="code">${esc(code)}</span><span class="company">${esc(o.company_name||o.companyName||'')}</span><span class="time">${esc(time)}</span></div><div class="title">${esc(o.title)}</div><div class="tags">${cs.map(x=>`<span class="tag ${x}">${esc(labelCat(x))}</span>`).join('')}</div></div>`}
function labelCat(c){return ({earnings:'決算',revision:'業績修正',dividend:'配当',buyback:'自己株買い',split:'分割/併合',benefit:'優待',tob:'TOB/MBO',ma:'M&A/提携',personnel:'人事',presentation:'説明資料',governance:'ガバナンス',other:'その他'})[c]||c}
function reconcileEarningsFavorites(){const fav=new Set(state.favorites);const before=(state.earningsSchedule||[]).length;state.earningsSchedule=(state.earningsSchedule||[]).filter(x=>fav.has(x.code));syncEarningsNative();return before!==state.earningsSchedule.length}
function afterFavoritesChanged(){reconcileEarningsFavorites();save();renderFavs();renderFeed();renderCalendar();renderUpcomingEarnings();refreshEarnings(false,true);refresh()}
function bindItems(root){root.querySelectorAll('.item[data-url]').forEach(el=>el.onclick=()=>{const u=el.dataset.url;if(/^https?:\/\//i.test(u))location.href=u;else toast('開示リンクがありません')});root.querySelectorAll('[data-fav-code]').forEach(b=>b.onclick=e=>{e.stopPropagation();const c=b.dataset.favCode;if(!c)return;if(state.favorites.includes(c))state.favorites=state.favorites.filter(x=>x!==c);else if(state.favorites.length<100)state.favorites.push(c);else return toast('お気に入りは100銘柄までです');afterFavoritesChanged()})}
function renderFeed(){let arr=feed.slice();if(filter==='fav')arr=favoriteFeed.slice();else if(filter!=='all')arr=arr.filter(o=>cat(o.title).includes(filter));$('#feedList').innerHTML=arr.length?arr.map(itemHtml).join(''):'<div class="empty">該当する開示はありません</div>';$('#favFeedList').innerHTML=favoriteFeed.map(itemHtml).join('')||'<div class="empty">登録銘柄の開示は見つかりませんでした</div>';$$('.item[data-url]').forEach(el=>el.onclick=()=>{const u=el.dataset.url;if(/^https?:\/\//i.test(u))location.href=u;else toast('開示リンクがありません')});$$('[data-fav-code]').forEach(b=>b.onclick=e=>{e.stopPropagation();const c=b.dataset.favCode;if(!c)return;if(state.favorites.includes(c)){state.favorites=state.favorites.filter(x=>x!==c);favoriteFeed=favoriteFeed.filter(o=>rowCode(o)!==c);toast(`${c}をお気に入りから削除`)}else if(state.favorites.length<100){state.favorites.push(c);toast(`${c}をお気に入りに追加`)}else{toast('お気に入りは100銘柄までです')}afterFavoritesChanged()})}
let refreshing=false;
function rememberNames(rows){for(const o of rows){const c=rowCode(o),n=String(o.company_name||o.companyName||'').trim();if(c&&n)state.companyNames[c]=n}}
async function getRows(url,signal){const r=await fetch(url,{cache:'no-store',signal});if(!r.ok)throw new Error('HTTP '+r.status);const j=await r.json();const rows=Array.isArray(j)?j:(Array.isArray(j.items)?j.items:(Array.isArray(j.Tdnet)?j.Tdnet:null));if(!rows)throw new Error('開示配列なし');return rows.map(o=>o&&o.Tdnet?o.Tdnet:o).filter(validRow)}
async function refresh(){if(refreshing)return;refreshing=true;const st=$('#statusText');st.textContent='最新開示を取得中…';const ctl=new AbortController();const timer=setTimeout(()=>ctl.abort(),15000);try{const favUrl=state.favorites.length?`${API_BASE}/${state.favorites.join('-')}.json2?limit=300`:null;const [allRes,favRes]=await Promise.allSettled([getRows(API,ctl.signal),favUrl?getRows(favUrl,ctl.signal):Promise.resolve([])]);let anyLive=false;if(allRes.status==='fulfilled'){feed=allRes.value.slice(0,300);state.cachedFeed=feed;anyLive=true;}else if(!feed.length&&state.cachedFeed.length)feed=state.cachedFeed.slice();if(favRes.status==='fulfilled'){favoriteFeed=favRes.value.slice(0,300);state.cachedFavoriteFeed=favoriteFeed;anyLive=true;}else if(!favoriteFeed.length&&state.cachedFavoriteFeed.length)favoriteFeed=state.cachedFavoriteFeed.slice();rememberNames(feed);rememberNames(favoriteFeed);if(anyLive){liveSource=true;state.lastFetch=new Date().toISOString();save();if(allRes.status==='fulfilled')detectNew();const partial=(allRes.status!=='fulfilled'||favRes.status!=='fulfilled');st.textContent=`${partial?'一部更新失敗・':''}市場${feed.length}件 / お気に入り${favoriteFeed.length}件・${new Date().toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit'})}更新`;}else{st.textContent=feed.length?'更新失敗・保存済みデータを表示':'通信取得できません。再取得を押してください';}}catch(e){if(!feed.length&&state.cachedFeed.length)feed=state.cachedFeed.slice();if(!favoriteFeed.length&&state.cachedFavoriteFeed.length)favoriteFeed=state.cachedFavoriteFeed.slice();st.textContent=feed.length?'更新失敗・保存済みデータを表示':'通信取得できません。再取得を押してください';}finally{clearTimeout(timer);refreshing=false;}renderFavs();renderFeed();renderCalendar();}
function detectNew(){const nowKeys=feed.map(o=>String(o.id||rowTime(o)+'|'+rowCode(o)+'|'+o.title));const unseen=feed.filter((o,i)=>!state.lastSeen.includes(nowKeys[i])&&(!state.prefs.favoritesOnly||isFav(o))&&cat(o.title).some(c=>state.prefs.categories[c]));if(state.prefs.enabled&&state.initialized){unseen.forEach(o=>{const title=`${rowCode(o)} ${o.company_name||o.companyName||''}`.trim(),body=o.title;recordHistory(title,body);tryNotify(title,body,rowUrl(o))})}state.lastSeen=[...new Set([...nowKeys,...state.lastSeen])].slice(0,1000);state.initialized=true;save()}
function tryNotify(title,body,url=''){if(window.AndroidBridge&&typeof window.AndroidBridge.notifyDisclosure==='function'){try{if(window.AndroidBridge.notifyDisclosure(title,body,url)===true)return true}catch(e){}}if('Notification'in window&&Notification.permission==='granted'){try{new Notification(title,{body});return true}catch(e){}}toast(body);return false}
function recordHistory(title,body){state.history.unshift({id:Date.now()+Math.random(),title,body,at:new Date().toISOString(),read:false});state.history=state.history.slice(0,200);save();renderHistory()}
function parseBulk(text){let accepted=[],dups=[],rejected=[];for(const line of String(text||'').normalize('NFKC').toUpperCase().split(/\r?\n/)){const trimmed=line.trim();if(!trimmed)continue;const matches=trimmed.match(/(?<![0-9A-Z])[0-9A-Z]{4,5}(?![0-9A-Z])/g)||[];const codes=matches.map(normCode).filter(Boolean);if(!codes.length){rejected.push(trimmed);continue}for(const c of codes){if(accepted.includes(c)){if(!dups.includes(c))dups.push(c)}else accepted.push(c)}}return{accepted,dups,rejected}}
function renderFavs(){const el=$('#favCodeList');$('#favCount').textContent=state.favorites.length;el.innerHTML=state.favorites.length?state.favorites.slice().sort().map(c=>`<span class="codePill"><span>★ <b>${esc(c)}</b><small>${esc(state.companyNames[c]||'会社名取得中')}</small></span><button data-rm="${esc(c)}">×</button></span>`).join(''):'<div class="empty">まだ登録されていません</div>';$$('[data-rm]').forEach(b=>b.onclick=()=>{const c=b.dataset.rm;state.favorites=state.favorites.filter(x=>x!==c);favoriteFeed=favoriteFeed.filter(o=>rowCode(o)!==c);afterFavoritesChanged()})}
function previewBulk(){const p=parseBulk($('#bulkInput').value);const newCodes=p.accepted.filter(c=>!state.favorites.includes(c));const room=Math.max(0,100-state.favorites.length);const add=newCodes.slice(0,room);const existing=p.accepted.length-newCodes.length;$('#modalTitle').textContent='一括登録を確認';$('#modalOk').textContent='追加する';$('#modalBody').innerHTML=`<p>新規 <b>${add.length}</b>件を追加します。</p><p class="muted">登録済み ${existing}件 / 貼り付け内重複 ${p.dups.length}件 / 読み取れない行 ${p.rejected.length}件 / 100件超過 ${Math.max(0,newCodes.length-room)}件</p><p>${add.slice(0,30).join('　')}${add.length>30?`<br>＋${add.length-30}件`:''}</p>`;showModal(()=>{state.favorites=[...new Set([...state.favorites,...add])].slice(0,100);afterFavoritesChanged();$('#bulkInput').value='';$('#bulkResult').textContent=`${add.length}件追加しました（${state.favorites.length}/100）`;renderFavs();renderFeed();renderCalendar();toast(`${add.length}件追加しました`)},add.length>0)}
function showModal(ok,enabled=true){const m=$('#modal');m.classList.remove('hidden');$('#modalOk').disabled=!enabled;$('#modalCancel').onclick=()=>{m.classList.add('hidden');$('#modalOk').textContent='追加する'};$('#modalOk').onclick=()=>{m.classList.add('hidden');ok&&ok()}}
function confirmModal(title,body,ok,okLabel='実行する'){$('#modalTitle').textContent=title;$('#modalBody').innerHTML=`<p>${esc(body)}</p>`;$('#modalOk').textContent=okLabel;showModal(()=>{ok();$('#modalOk').textContent='追加する'})}
function ym(){const d=new Date();d.setDate(1);d.setMonth(d.getMonth()+monthOffset);return d}
function renderCalendar(){const d=ym(),y=d.getFullYear(),m=d.getMonth(),schedule=state.earningsSchedule||[];$('#monthLabel').textContent=`${y}年${m+1}月`;const first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();let html='';for(let i=0;i<first;i++)html+='<div class="calCell out"></div>';for(let day=1;day<=days;day++){const key=`${y}-${String(m+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;const dayRows=schedule.filter(o=>o.date===key);const fav=dayRows.filter(o=>state.favorites.includes(o.code)).length;html+=`<div class="calCell ${selectedDate===key?'selected':''}" data-date="${key}"><div class="num">${day}</div>${dayRows.length?`<div class="counts">●${dayRows.length} ★${fav}</div>`:''}</div>`}$('#calendarGrid').innerHTML=html;$$('[data-date]').forEach(c=>c.onclick=()=>{selectedDate=c.dataset.date;renderCalendar()});const only=$('#calendarFavOnly').checked;const rows=schedule.filter(o=>o.date===selectedDate&&(!only||state.favorites.includes(o.code)));$('#dayEvents').innerHTML=rows.length?rows.map(o=>`<div class="item scheduleItem"><div class="itemHead"><span class="favStar">${state.favorites.includes(o.code)?'★':'☆'}</span><span class="code">${esc(o.code)}</span><span class="company">${esc(o.company||state.companyNames[o.code]||'')}</span></div><div class="title"><span class="period">${esc(o.period)}</span>${o.time?`　<span class="date">${esc(o.time)}${o.timeEstimated?'頃（推定）':'予定'}</span>`:''}</div></div>`).join(''):'<div class="empty">この日の決算発表予定はありません</div>';$('#calendarSource').textContent=schedule.length?`決算発表予定 ${schedule.length}件を表示中（結果開示とは別データ）`:'東証の予定日がまだ取得できていません。過去の決算結果を予定として誤表示しません。'}

function earningsStamp(){return localYmd(new Date())}
function syncEarningsNative(){
  if(window.AndroidBridge&&typeof window.AndroidBridge.syncEarningsSchedule==='function'){
    try{const fav=new Set(state.favorites);window.AndroidBridge.syncEarningsSchedule(JSON.stringify((state.earningsSchedule||[]).filter(x=>fav.has(x.code))))}catch(e){}
  }
}
window.PinoNative=window.PinoNative||{};
window.PinoNative.onEarningsResult=function(payload){
  earningsRefreshing=false;
  const st=$('#earningsSyncStatus');
  try{
    const result=typeof payload==='string'?JSON.parse(payload):payload;
    const rows=Array.isArray(result&&result.items)?result.items:[];
    state.earningsSchedule=rows.map(x=>({
      date:String(x.date||''),time:String(x.time||''),code:normCode(x.code)||'',
      company:String(x.company||state.companyNames[normCode(x.code)||'']||''),period:String(x.period||'決算'),
      timeEstimated:x.timeEstimated===true,timeSource:String(x.timeSource||''),timeSamples:Number(x.timeSamples||0),timeConfidence:String(x.timeConfidence||''),
      stale:x.stale===true,confirmed:x.confirmed!==false,source:String(x.source||'JPX')
    })).filter(x=>x.code&&state.favorites.includes(x.code)&&/^\d{4}-\d{2}-\d{2}$/.test(x.date));
    for(const x of state.earningsSchedule)if(x.code&&x.company)state.companyNames[x.code]=x.company;
    state.earningsLastAttempt=String(result&&result.attemptedAt||new Date().toISOString());
    state.earningsLastAutoFetchDay=String(result&&result.day||earningsStamp());
    state.earningsLastError=result&&result.ok===false?String(result.error||'取得失敗'):null;
    if(result&&result.fetchedAt)state.earningsLastSync=String(result.fetchedAt);
    else if(result&&result.ok&&!result.cached)state.earningsLastSync=new Date().toISOString();
    save();syncEarningsNative();renderCalendar();renderUpcomingEarnings();
    const errCount=Array.isArray(result&&result.errors)?result.errors.length:0;
    const took=result&&Number.isFinite(Number(result.durationMs))?`・${Math.max(1,Math.round(Number(result.durationMs)/1000))}秒`:'';
    if(st){
      if(result&&result.ok===false){
        const old=state.earningsLastSync?`${new Date(state.earningsLastSync).toLocaleString('ja-JP')}取得分`:'保存データなし';
        st.textContent=`本日の取得失敗・${old}を表示中。自動再取得はせず、必要なら「手動再取得」を押してください。${result.error?' '+result.error:''}`;
      }else if(result&&result.cached){
        st.textContent=state.earningsLastSync?`今日は取得済み・最終確認 ${new Date(state.earningsLastSync).toLocaleString('ja-JP')}`:'今日は取得済み';
      }else if(result&&result.ok){
        st.textContent=`最終確認 ${new Date(state.earningsLastSync).toLocaleString('ja-JP')}・${state.earningsSchedule.length}件${errCount?'（一部取得失敗 '+errCount+'銘柄）':''}${took}`;
      }else st.textContent='決算予定の取得状態を確認できませんでした。';
    }
  }catch(e){if(st)st.textContent='決算予定データの読み込みに失敗しました。';}
};
window.PinoNative.onAppResume=function(){refreshEarnings(false)};
async function refreshEarnings(force=false,favoriteChange=false){
  const today=earningsStamp(),st=$('#earningsSyncStatus');
  if(earningsRefreshing)return;
  if(!force&&!favoriteChange&&state.earningsLastAutoFetchDay===today){
    if(st){
      if(state.earningsLastError){const old=state.earningsLastSync?`${new Date(state.earningsLastSync).toLocaleString('ja-JP')}取得分を表示中`:'保存データなし';st.textContent=`本日の取得失敗・${old}。手動再取得できます。`;}
      else st.textContent=state.earningsLastSync?`今日は取得済み・最終確認 ${new Date(state.earningsLastSync).toLocaleString('ja-JP')}`:'今日は取得済み';
    }
    syncEarningsNative();return;
  }
  if(!state.favorites.length){state.earningsSchedule=[];state.earningsLastSync=new Date().toISOString();state.earningsLastAttempt=state.earningsLastSync;state.earningsLastAutoFetchDay=today;state.earningsLastError=null;save();syncEarningsNative();renderCalendar();renderUpcomingEarnings();if(st)st.textContent='お気に入り銘柄がありません';return;}
  if(st)st.textContent=force?'東証から決算発表予定日を手動更新中…':favoriteChange?'お気に入り変更分の決算予定を確認中…':'本日最初の起動：東証から決算発表予定日を確認中…';
  if(window.AndroidBridge&&typeof window.AndroidBridge.requestEarningsSchedule==='function'){
    try{earningsRefreshing=true;window.AndroidBridge.requestEarningsSchedule(JSON.stringify(state.favorites),!!force);return}catch(e){earningsRefreshing=false;}
  }
  if(st)st.textContent='この端末では決算予定の自動取得を利用できません。';
}
function renderUpcomingEarnings(){
 const box=$('#earningsUpcomingList');if(!box)return;const today=localYmd(new Date());
 const byCode=new Map();(state.earningsSchedule||[]).filter(x=>state.favorites.includes(x.code)&&x.date>=today).sort((a,b)=>(a.date+(a.time||'99:99')).localeCompare(b.date+(b.time||'99:99'))).forEach(x=>{if(!byCode.has(x.code))byCode.set(x.code,x)});
 const known=[...byCode.values()].sort((a,b)=>(a.date+(a.time||'99:99')).localeCompare(b.date+(b.time||'99:99')));
 const missing=state.favorites.filter(c=>!byCode.has(c)).map(c=>({code:c,company:state.companyNames[c]||'',missing:true}));
 const rows=[...known,...missing];
 box.innerHTML=rows.length?rows.map((o,i)=>o.missing?`<div class="item scheduleItem mutedSchedule"><div class="itemHead"><span class="rank">${i+1}</span><span class="favStar">★</span><span class="code">${esc(o.code)}</span><span class="company">${esc(o.company)}</span></div><div class="title"><b>次回予定 未公表／未取得</b></div></div>`:(()=>{const tm=o.time?(o.timeEstimated?`${esc(o.time)}頃 <span class="muted">（過去のTDnet実績から推定${o.timeConfidence?`・信頼度${esc(o.timeConfidence)}`:''}）</span>`:`${esc(o.time)}予定`):'時刻未定';return `<div class="item scheduleItem${o.stale?' mutedSchedule':''}"><div class="itemHead"><span class="rank">${i+1}</span><span class="favStar">★</span><span class="code">${esc(o.code)}</span><span class="company">${esc(o.company||state.companyNames[o.code]||'')}</span></div><div class="title"><b>${esc(o.date.replaceAll('-','/'))} ${tm}</b>　<span class="period">${esc(o.period)}</span> <span class="tag earnings">東証予定</span>${o.stale?' <span class="muted">保存データ</span>':''}</div></div>`})()).join(''):'<div class="empty">お気に入り銘柄がありません</div>';
}
function showCalendarMode(mode){const cal=mode==='calendar';$('#calendarViewBtn').classList.toggle('active',cal);$('#earningsListBtn').classList.toggle('active',!cal);$('#calendarPane').classList.toggle('hidden',!cal);$('#earningsListPane').classList.toggle('hidden',cal);if(!cal)renderUpcomingEarnings()}

function renderPrefs(){$$('[data-pref]').forEach(i=>{i.checked=!!state.prefs[i.dataset.pref];i.onchange=()=>{state.prefs[i.dataset.pref]=i.checked;save()}});const box=$('#categorySettings');box.innerHTML=categoryDefs.map(([k,l])=>`<label class="toggle"><span>${l}</span><input data-cat="${k}" type="checkbox" ${state.prefs.categories[k]?'checked':''}></label>`).join('');$$('[data-cat]').forEach(i=>i.onchange=()=>{state.prefs.categories[i.dataset.cat]=i.checked;save()})}
function renderHistory(){const h=state.history||[];$('#unreadCount').textContent=h.filter(x=>!x.read).length;$('#historyList').innerHTML=h.length?h.slice(0,30).map(x=>`<div class="item"><div class="itemHead"><span>${x.read?'':'●'}</span><b>${esc(x.title)}</b><span class="time">${new Date(x.at).toLocaleString('ja-JP',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})}</span></div><div class="title">${esc(x.body)}</div></div>`).join(''):'<div class="empty">履歴はありません</div>'}
async function testNotification(){const t='ピノウォッチ テスト通知',b='新着開示はこの形式で通知されます。';const sent=tryNotify(t,b,'');recordHistory(t,b);toast(sent?'テスト通知を送信しました':'通知権限を許可すると端末通知を確認できます')}
function fmtTs(v){const n=Number(v||0);return n>0?new Date(n).toLocaleString('ja-JP'):'未記録'}
function diagnose(){
  let native={pushStatus:'非対応',notificationPermission:'不明',exactAlarm:'不明'};
  if(window.AndroidBridge&&typeof window.AndroidBridge.getNotificationDiagnostics==='function'){
    try{native=JSON.parse(window.AndroidBridge.getNotificationDiagnostics()||'{}')}catch(e){}
  }else if(window.AndroidBridge&&typeof window.AndroidBridge.getPushStatus==='function'){
    try{native.pushStatus=window.AndroidBridge.getPushStatus()}catch(e){native.pushStatus='確認失敗'}
  }
  const lines=[
    `アプリUI: OK`,
    `ローカル保存: ${storageOK?'OK':'失敗'}`,
    `お気に入り: ${state.favorites.length}/100`,
    `OS通知権限: ${native.notificationPermission||'不明'}`,
    `新着開示チャンネル: ${native.disclosureChannel||'不明'}`,
    `決算通知チャンネル: ${native.earningsChannel||'不明'}`,
    `Firebase Push: ${native.pushStatus||'不明'}`,
    `20時決算通知: ${native.exactAlarm||'不明'}`,
    `最終FCM受信: ${fmtTs(native.lastFcmReceivedAt)}`,
    `最終取りこぼし確認: ${fmtTs(native.lastCatchupAt)}${native.lastCatchupStatus?'・'+native.lastCatchupStatus:''}`,
    `回収した通知: ${Number(native.recoveredCount||0)}件`,
    `重複抑止: ${Number(native.duplicatesSuppressed||0)}件`,
    `最終通知エラー: ${native.lastNotificationError?native.lastNotificationError+'・'+fmtTs(native.lastNotificationErrorAt):'なし'}`,
    `次回20時アラーム: ${fmtTs(native.nextEarningsAlarmAt)}`,
    `最終データ取得: ${state.lastFetch?new Date(state.lastFetch).toLocaleString('ja-JP'):'未取得'}`,
    `開示データ: ${liveSource?'接続済み':'未取得'}`,
    `決算発表予定: ${state.earningsSchedule.length?state.earningsSchedule.length+'件':'未取得'}`
  ];
  $('#diagBox').textContent=lines.join('\n')
}
function bind(){$$('.bottom button').forEach(b=>b.onclick=()=>{$$('.bottom button').forEach(x=>x.classList.remove('active'));b.classList.add('active');$$('.screen').forEach(x=>x.classList.remove('active'));$('#'+b.dataset.tab).classList.add('active');if(b.dataset.tab==='settings'){renderPrefs();renderHistory()}});$$('.chip').forEach(b=>b.onclick=()=>{$$('.chip').forEach(x=>x.classList.remove('active'));b.classList.add('active');filter=b.dataset.filter;renderFeed()});$('#refreshBtn').onclick=refresh;$('#previewBulk').onclick=previewBulk;$('#clearFavs').onclick=()=>confirmModal('お気に入りを全削除','登録中のお気に入り銘柄をすべて削除します。',()=>{state.favorites=[];favoriteFeed=[];afterFavoritesChanged();toast('お気に入りを全削除しました')},'全削除する');$('#favDisclosureBtn').onclick=()=>{$('#favDisclosureBtn').classList.add('active');$('#favManageBtn').classList.remove('active');$('#favDisclosurePane').classList.remove('hidden');$('#favManagePane').classList.add('hidden')};$('#favManageBtn').onclick=()=>{$('#favManageBtn').classList.add('active');$('#favDisclosureBtn').classList.remove('active');$('#favManagePane').classList.remove('hidden');$('#favDisclosurePane').classList.add('hidden');renderFavs()};$('#prevMonth').onclick=()=>{monthOffset--;const d=ym();selectedDate=localYmd(d);renderCalendar()};$('#nextMonth').onclick=()=>{monthOffset++;const d=ym();selectedDate=localYmd(d);renderCalendar()};$('#calendarFavOnly').onchange=renderCalendar;$('#calendarViewBtn').onclick=()=>showCalendarMode('calendar');$('#earningsListBtn').onclick=()=>showCalendarMode('list');$('#earningsRefresh').onclick=()=>refreshEarnings(true);$('#exactAlarmAccess').onclick=()=>{if(window.AndroidBridge&&typeof window.AndroidBridge.requestExactAlarmAccess==='function'){window.AndroidBridge.requestExactAlarmAccess();toast('設定画面で「アラームとリマインダー」を許可してください')}else toast('この端末では設定不要です')};$('#testNotify').onclick=testNotification;$('#diagnose').onclick=diagnose;$('#readAll').onclick=()=>{state.history.forEach(x=>x.read=true);save();renderHistory()};$('#clearHistory').onclick=()=>{state.history=[];save();renderHistory()}}
bind();renderFavs();renderPrefs();renderHistory();feed=state.cachedFeed.slice();favoriteFeed=state.cachedFavoriteFeed.slice();reconcileEarningsFavorites();renderFeed();renderCalendar();renderUpcomingEarnings();syncEarningsNative();refresh();refreshEarnings(false);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshEarnings(false)});setInterval(()=>{if(!document.hidden){refresh();refreshEarnings(false)}},60000);
})();
