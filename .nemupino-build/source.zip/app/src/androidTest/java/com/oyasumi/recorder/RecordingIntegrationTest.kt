package com.oyasumi.recorder

import android.content.Intent
import android.media.MediaMetadataRetriever
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class RecordingIntegrationTest {
    @Test fun decodedAacAndJoinedPartsHaveDetailedWaveform() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val part = File(context.cacheDir, "fixture.m4a")
        instrumentation.context.assets.open("part.m4a").use { input -> part.outputStream().use { input.copyTo(it) } }
        val joined = File(context.cacheDir, "joined.m4a")
        joined.delete()
        val duration = AudioJoiner.join(listOf(part, part), joined) {}
        assertTrue(duration in 3900L..4400L)
        val analysis = AudioEnvelope.readDetailed(joined)
        assertTrue(analysis.samples.size in 75..90)
        assertTrue(analysis.features.map { it.lowRatio }.average() > 0.7)
        val reader = MediaMetadataRetriever()
        reader.setDataSource(joined.absolutePath)
        assertTrue(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong() > 3900)
        reader.release()
    }

    @Test fun shortRotationsProduceCheckpointsThenOnePlayableFinalSession() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SessionStore.get(context)
        val before = store.sessions.value.map { it.id }.toSet()
        context.startForegroundService(Intent(context, RecordingService::class.java).apply {
            action = RecordingService.ACTION_START
            putExtra("test_part_ms", 3000L)
        })
        val deadline = System.currentTimeMillis() + 30000
        while (store.sessions.value.none { it.id !in before && "途中保存" in it.tags } && System.currentTimeMillis() < deadline) Thread.sleep(100)
        assertTrue(store.sessions.value.any { it.id !in before && "途中保存" in it.tags })
        Thread.sleep(4000)
        RecordingService.stop(context)
        val savedDeadline = System.currentTimeMillis() + 180000
        while (RecordingBus.state.value !is RecordingUiState.Idle && System.currentTimeMillis() < savedDeadline) Thread.sleep(100)
        assertTrue("State=${RecordingBus.state.value}, error=${RecordingBus.error.value}", RecordingBus.state.value is RecordingUiState.Idle)
        val final = store.sessions.value.filter { it.id !in before }
        assertEquals(1, final.size)
        assertFalse("途中保存" in final.first().tags)
        assertTrue(final.first().samples.isNotEmpty())
        assertTrue(store.recordingFile(final.first().fileName).length() > 0)
        assertNull(RecordingBus.error.value)
    }
    @Test fun rangeCompletionCanChainPlaybackWithoutStaleCallbacks() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val file = File(context.cacheDir, "chain-fixture.m4a")
        instrumentation.context.assets.open("part.m4a").use { input -> file.outputStream().use { input.copyTo(it) } }
        val player = SegmentAudioPlayer()
        val completed = java.util.Collections.synchronizedList(mutableListOf<Int>())
        try {
            instrumentation.runOnMainSync {
                player.onRangeFinished = { index ->
                    completed.add(index)
                    if (index == 0) player.play(file, SoundEvent(1000, 1700, -20f), 1)
                }
                player.play(file, SoundEvent(0, 700, -20f), 0)
            }
            val deadline = System.currentTimeMillis() + 25000
            while (completed.size < 2 && System.currentTimeMillis() < deadline) Thread.sleep(100)
            assertEquals(listOf(0, 1), completed.toList())
            assertNull(player.error.value)
        } finally { instrumentation.runOnMainSync { player.release() } }
    }

    @Test fun zzResultControlsAndManualLabelsWork() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val store = SessionStore.get(context)
        val file = store.recordingFile("ui-fixture.m4a")
        val part = File(context.cacheDir, "fixture.m4a")
        instrumentation.context.assets.open("part.m4a").use { input -> part.outputStream().use { input.copyTo(it) } }
        file.delete()
        instrumentation.context.assets.open("ui-bursts.m4a").use { input -> file.outputStream().use { input.copyTo(it) } }
        val duration = 18_000L
        val samples = AudioEnvelope.read(file)
        val now = System.currentTimeMillis()
        store.save(RecordingSession("ui-fixture", now - duration, now, file.name,
            listOf(SoundEvent(1000, 4000, -18f, "いびき候補"), SoundEvent(8000, 12000, -20f, "不明")), samples))
        RecordingBus.completed("ui-fixture")
        instrumentation.startActivitySync(Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("show_results", true))
        Thread.sleep(4000)
        fun tap(target: android.view.accessibility.AccessibilityNodeInfo) {
            val bounds = android.graphics.Rect()
            target.getBoundsInScreen(bounds)
            val now = android.os.SystemClock.uptimeMillis()
            for (action in listOf(android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_UP)) {
                val event = android.view.MotionEvent.obtain(now, android.os.SystemClock.uptimeMillis(), action, bounds.exactCenterX(), bounds.exactCenterY(), 0)
                event.source = android.view.InputDevice.SOURCE_TOUCHSCREEN
                assertTrue(instrumentation.uiAutomation.injectInputEvent(event, true))
                event.recycle()
            }
        }
        fun click(text: String) {
            fun find(node: android.view.accessibility.AccessibilityNodeInfo?): android.view.accessibility.AccessibilityNodeInfo? {
                if (node == null) return null
                fun normalized(value: String) = value.filterNot { it.isWhitespace() }
                val matches = node.text?.toString()?.split("\n")?.any { normalized(it) == normalized(text) } == true || node.contentDescription?.toString() == text
                if (matches) {
                    var button = node
                    while (button != null && !button.isClickable) button = button.parent
                    if (button != null && button.isEnabled) return button
                }
                repeat(node.childCount) { find(node.getChild(it))?.let { found -> return found } }
                return null
            }
            val deadline = System.currentTimeMillis() + 90000
            var node: android.view.accessibility.AccessibilityNodeInfo? = null
            while (node == null && System.currentTimeMillis() < deadline) {
                val root = instrumentation.uiAutomation.rootInActiveWindow
                root?.refresh()
                node = find(root)
                if (node == null) {
                    val waiting = instrumentation.uiAutomation.rootInActiveWindow?.findAccessibilityNodeInfosByText("Wait")?.firstOrNull()
                    waiting?.let(::tap)
                    Thread.sleep(200)
                }
            }
            if (node == null) {
                val screenshot = instrumentation.uiAutomation.takeScreenshot()
                File(context.cacheDir, "actual-result.png").outputStream().use { screenshot.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                screenshot.recycle()
            }
            assertNotNull("Missing control: $text; sessions=${store.sessions.value.map { it.id }}", node)
            tap(node!!)
            Thread.sleep(500)
        }
        click("＋")
        click("−")
        click("全ての音")
        click("候補のみ ✓")
        click("区間一覧")
        click("録音区間 1")
        click("区間再生 OFF")
        click("いびき候補")
        click("環境音")
        val labelDeadline = System.currentTimeMillis() + 15000
        while (store.sessions.value.first { it.id == "ui-fixture" }.events.first().label != "環境音" && System.currentTimeMillis() < labelDeadline) Thread.sleep(100)
        assertEquals("環境音", store.sessions.value.first { it.id == "ui-fixture" }.events.first().label)
        val bitmap = instrumentation.uiAutomation.takeScreenshot()
        File(context.cacheDir, "actual-result.png").outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
    }

    @Test fun analysisPreservesEditsAndDoesNotResurrectDeletedRecords() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SessionStore.get(context)
        val id = "analysis-edit-fixture"
        val file = store.recordingFile("analysis-edit-fixture.m4a")
        InstrumentationRegistry.getInstrumentation().context.assets.open("part.m4a").use { input -> file.outputStream().use { input.copyTo(it) } }
        val now = System.currentTimeMillis()
        store.save(RecordingSession(id, now - 2000, now, file.name, listOf(SoundEvent(0, 1000, -20f)), listOf(VolumeSample(0, -30f)), tags = listOf(SessionRefiner.PENDING)))
        store.labelEvent(id, 0, "いびき")
        store.updateReview(id, "聞いて確認したメモ", listOf("鼻づまり"))
        assertTrue(SessionRefiner.PENDING in store.sessions.value.first { it.id == id }.tags)
        val analysis = AudioEnvelope.readDetailed(file)
        store.finishAnalysis(id, analysis)
        val saved = store.sessions.value.first { it.id == id }
        assertEquals("いびき", saved.events.first().label)
        assertEquals("聞いて確認したメモ", saved.note)
        assertEquals(listOf("鼻づまり"), saved.tags)
        assertTrue(saved.samples.size > 20)
        store.delete(id)
        store.finishAnalysis(id, analysis)
        assertFalse(store.sessions.value.any { it.id == id })
    }

    @Test fun decodedRhythmicAudioCreatesSnoreCandidates() {
        val inst = InstrumentationRegistry.getInstrumentation()
        val file = File(inst.targetContext.cacheDir, "rhythmic.m4a")
        inst.context.assets.open("ui-bursts.m4a").use { input -> file.outputStream().use { input.copyTo(it) } }
        val detailed = AudioEnvelope.readDetailed(file)
        val detector = SoundEventDetector(-26f)
        val events = mutableListOf<SoundEvent>()
        detailed.samples.forEach { detector.onSample(it.offsetMs, it.db)?.let { event -> events.add(event) } }
        detector.finish(18_000L)?.let { events.add(it) }
        assertTrue(events.size >= 4)
        assertTrue(SoundCandidates.classify(events, detailed.features).count { it.candidate == "いびき候補" } >= 4)
    }

}
