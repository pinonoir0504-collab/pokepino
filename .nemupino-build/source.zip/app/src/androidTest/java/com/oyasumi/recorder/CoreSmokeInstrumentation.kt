package com.oyasumi.recorder

import android.app.Activity
import android.app.Instrumentation
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.content.FileProvider

/** Runs real service, MediaRecorder, MediaPlayer and legacy-history checks. */
class CoreSmokeInstrumentation : Instrumentation() {
    override fun onCreate(arguments: Bundle?) { super.onCreate(arguments); start() }
    private fun waitUntil(timeoutMs: Long = 15000L, test: () -> Boolean) {
        val end = android.os.SystemClock.elapsedRealtime() + timeoutMs
        while (!test()) {
            check(android.os.SystemClock.elapsedRealtime() < end) { "Timed out waiting for recording state" }
            Thread.sleep(100L)
        }
    }
    override fun onStart() {
        val result = Bundle()
        var player: SegmentAudioPlayer? = null
        try {
            val activity = startActivitySync(Intent(targetContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            waitForIdleSync()
            val store = SessionStore.get(targetContext)
            val before = store.sessions.value.size
            runOnMainSync { RecordingService.start(activity, 3000L) }
            waitUntil { RecordingBus.state.value is RecordingUiState.Waiting }
            check(store.sessions.value.size == before)
            uiAutomation.executeShellCommand("input keyevent 26").close()
            waitUntil { RecordingBus.state.value is RecordingUiState.Active }
            Thread.sleep(4000L)
            runOnMainSync { RecordingService.stop(activity) }
            waitUntil { RecordingBus.state.value == RecordingUiState.Idle && store.sessions.value.size == before + 1 }
            val session = store.sessions.value.first()
            val file = store.recordingFile(session.fileName)
            check(file.length() > 0 && session.samples.isNotEmpty())
            check(session.durationMs in 3000L..15000L)
            check(session.samples.zipWithNext().all { (a, b) -> a.offsetMs <= b.offsetMs })
            uiAutomation.executeShellCommand("input keyevent 26").close()
            uiAutomation.executeShellCommand("wm dismiss-keyguard").close()
            runOnMainSync {
                player = SegmentAudioPlayer()
                player!!.play(file, SoundEvent(0, session.durationMs, 0f), -1)
            }
            waitUntil { player!!.isPrepared.value && player!!.isPlaying.value }
            runOnMainSync { player!!.togglePause() }
            check(!player!!.isPlaying.value)
            runOnMainSync { player!!.seekTo(1000L) }
            Thread.sleep(500L)
            check(!player!!.isPlaying.value && player!!.playingIndex.value == -1)
            runOnMainSync { player!!.togglePause() }
            check(player!!.isPlaying.value)
            runOnMainSync { player!!.release() }; player = null
            check(FileProvider.getUriForFile(targetContext, targetContext.packageName + ".files", file).scheme == "content")
            store.updateReview(session.id, "smoke test note", listOf("横向き"))
            val constructor = SessionStore::class.java.getDeclaredConstructor(Context::class.java).apply { isAccessible = true }
            val reloaded = constructor.newInstance(targetContext).sessions.value.first()
            check(reloaded.note == "smoke test note" && reloaded.tags == listOf("横向き"))
            check(reloaded.samples.map { it.offsetMs } == session.samples.map { it.offsetMs })
            val prefs = targetContext.getSharedPreferences("sessions", Context.MODE_PRIVATE)
            val saved = prefs.getString("session_json", null)
            try {
                prefs.edit().putString("session_json", """[{"id":"legacy","startedAt":0,"endedAt":2000,"fileName":"legacy.m4a","events":[{"startMs":0,"endMs":2000,"peakDb":-10}],"samples":[[0,-60],[200,-10]]}]""").commit()
                val legacy = constructor.newInstance(targetContext).sessions.value.first()
                check(legacy.samples.size == 2 && legacy.note.isEmpty() && legacy.tags.isEmpty())
            } finally { prefs.edit().putString("session_json", saved).commit() }
            runOnMainSync { RecordingService.start(activity, 3000L) }
            waitUntil { RecordingBus.state.value is RecordingUiState.Waiting }
            runOnMainSync { RecordingService.stop(activity) }
            waitUntil { RecordingBus.state.value == RecordingUiState.Idle }
            Thread.sleep(3500L)
            check(RecordingBus.state.value == RecordingUiState.Idle && store.sessions.value.size == before + 1)
            result.putString("stream", "PASS: delayed-start with screen off, real recording, save, playback/pause/resume, notes, timestamp persistence, legacy migration, share URI and reservation cancellation\n")
            finish(Activity.RESULT_OK, result)
        } catch (error: Throwable) {
            runOnMainSync { player?.release() }
            result.putString("stream", "FAIL: ${error.stackTraceToString()}\n")
            finish(Activity.RESULT_CANCELED, result)
        }
    }
}
