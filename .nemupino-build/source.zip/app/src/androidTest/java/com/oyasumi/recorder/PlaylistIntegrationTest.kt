package com.oyasumi.recorder

import android.media.MediaMetadataRetriever
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class PlaylistIntegrationTest {
    private val inst get() = InstrumentationRegistry.getInstrumentation()
    private fun fixture(dir: File, name: String): Pair<File, Long> {
        val file = File(dir, name)
        inst.context.assets.open("part.m4a").use { input -> file.outputStream().use { input.copyTo(it) } }
        val reader = MediaMetadataRetriever()
        val duration = try { reader.setDataSource(file.path); reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong() } finally { reader.release() }
        return file to duration
    }
    private fun waitUntil(message: String, predicate: () -> Boolean) {
        val deadline = System.currentTimeMillis() + 25000
        while (!predicate() && System.currentTimeMillis() < deadline) Thread.sleep(50)
        assertTrue(message, predicate())
    }
    @Test fun playlistDecodingOffsetsSecondPartAndKeepsOriginalAudio() {
        val (a, duration) = fixture(inst.targetContext.cacheDir, "playlist-a.m4a")
        val (b, _) = fixture(inst.targetContext.cacheDir, "playlist-b.m4a")
        val file = File(a.parentFile, "decode.playlist")
        AudioPlaylist.write(file, listOf(AudioPart(a.name, duration), AudioPart(b.name, duration)))
        val decoded = AudioEnvelope.readDetailed(file)
        assertTrue(decoded.samples.any { it.offsetMs < duration })
        assertTrue(decoded.samples.any { it.offsetMs >= duration })
        assertTrue(decoded.samples.zipWithNext().all { it.first.offsetMs <= it.second.offsetMs })
        assertTrue(a.exists() && b.exists())
    }
    @Test fun playbackCrossesPartsAndCrossPartSeekKeepsPauseChoice() {
        val (a, duration) = fixture(inst.targetContext.cacheDir, "play-a.m4a")
        val (b, _) = fixture(inst.targetContext.cacheDir, "play-b.m4a")
        val file = File(a.parentFile, "play.playlist")
        AudioPlaylist.write(file, listOf(AudioPart(a.name, duration), AudioPart(b.name, duration)))
        val player = SegmentAudioPlayer()
        try {
            inst.runOnMainSync { player.play(file, SoundEvent(0, duration * 2, 0f), -1) }
            waitUntil("Must continue after first AAC file") { player.positionMs.longValue > duration + 250 }
            assertNull(player.error.value)
            inst.runOnMainSync { player.togglePause(); player.seekTo(300) }
            waitUntil("Seek back to first part") { player.isPrepared.value && player.positionMs.longValue < duration }
            Thread.sleep(350)
            assertFalse(player.isPlaying.value)
            assertTrue(player.positionMs.longValue < 700)
            inst.runOnMainSync { player.seekTo(duration + 400) }
            waitUntil("Seek forward while paused") { player.isPrepared.value && player.positionMs.longValue > duration }
            Thread.sleep(350)
            assertFalse(player.isPlaying.value)
            inst.runOnMainSync { player.togglePause() }
            waitUntil("Resume to end of second part") { player.playingIndex.value == null }
            assertNull(player.error.value)
        } finally { inst.runOnMainSync { player.release() } }
    }
    @Test fun finalSessionRetainsReferencedCheckpointsAndDeleteRemovesAllParts() {
        val store = SessionStore.get(inst.targetContext)
        val id = "ownership-${System.nanoTime()}"
        val (a, duration) = fixture(store.recordingFile("x").parentFile!!, "$id-a.m4a")
        val (b, _) = fixture(a.parentFile!!, "$id-b.m4a")
        val now = System.currentTimeMillis()
        store.save(RecordingSession("$id-a",now,now+duration,a.name,emptyList(),emptyList()))
        store.save(RecordingSession("$id-b",now+duration,now+duration*2,b.name,emptyList(),emptyList()))
        val manifest = store.recordingFile("$id.playlist")
        val parts = listOf(AudioPart(a.name,duration),AudioPart(b.name,duration))
        AudioPlaylist.write(manifest,parts)
        store.finalizeRecording(RecordingSession(id,now,now+duration*2,manifest.name,emptyList(),emptyList(),audioParts=parts),listOf("$id-a","$id-b"))
        assertTrue(a.exists() && b.exists())
        store.recoverOrphans()
        assertFalse(store.sessions.value.any { it.id == "recovered-${a.nameWithoutExtension}" || it.id == "recovered-${b.nameWithoutExtension}" })
        assertEquals(parts,AudioPlaylist.read(manifest))
        store.delete(id)
        assertFalse(a.exists() || b.exists() || manifest.exists())
    }
}
