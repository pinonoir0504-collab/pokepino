package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class NemuPino363Test {
    private fun session(duration: Long = 3_600_000L, events: List<SoundEvent>, samples: List<VolumeSample> = emptyList()) =
        RecordingSession("s", 0L, duration, "a.m4a", events, samples)

    @Test fun postAnalysisRecoversQuietRhythmicSnoringBelowOldLiveThreshold() {
        val features = (0..500).map { i ->
            val t = i * 50L
            val phase = t % 3_000L
            val snore = phase in 400L..1_000L
            SoundFeature(t, if (snore) -44f else -58f, if (snore) 0.82f else 0.05f, if (snore) 0.04f else 0.02f)
        }
        val refined = SoundCandidates.refine(emptyList(), features, features.last().offsetMs + 50L)
        assertTrue(refined.isNotEmpty())
        assertTrue(refined.count { it.candidate == "いびき候補" } >= 3)
        assertTrue(refined.any { it.peakDb < -26f })
    }

    @Test fun adaptiveDetectorDoesNotCreateEventsFromSteadyRoomNoise() {
        val features = (0..400).map { SoundFeature(it * 50L, -35f, 0.1f, 0.3f) }
        assertTrue(SoundCandidates.detectAdaptive(features, 20_000L).isEmpty())
    }

    @Test fun manualReviewSurvivesEventRebuild() {
        val features = (0..240).map { i ->
            val t = i * 50L
            val loud = t in 3_000L..3_800L
            SoundFeature(t, if (loud) -18f else -58f, if (loud) 0.2f else 0.05f, if (loud) 0.30f else 0.02f)
        }
        val existing = listOf(SoundEvent(2_700L, 4_200L, -18f, "不明", "咳"))
        val refined = SoundCandidates.refine(existing, features, 12_000L)
        assertTrue(refined.any { it.label == "咳" })
    }

    @Test fun frequencyContributesModestlyAtEqualDurationAndIntensity() {
        val one = session(events = listOf(SoundEvent(0L, 600_000L, -32f, "いびき候補")))
        val many = session(events = (0 until 10).map { i ->
            val start = i * 70_000L
            SoundEvent(start, start + 60_000L, -32f, "いびき候補")
        })
        assertTrue(SessionMetrics.snoreScore(many) > SessionMetrics.snoreScore(one))
        assertTrue(SessionMetrics.snoreScore(many) < SessionMetrics.snoreScore(one) * 2)
    }

    @Test fun relativeVolumeIsMonotonicAndBounded() {
        val s = session(events = emptyList(), samples = listOf(VolumeSample(0, -58f), VolumeSample(1000, -30f), VolumeSample(2000, -8f)))
        val values = listOf(-58f, -30f, -8f, 0f).map { SessionMetrics.relativeVolume(s, it) }
        assertTrue(values.all { it in 0..100 })
        assertTrue(values.zipWithNext().all { (a, b) -> a <= b })
    }

    @Test fun top5UsesSustainedPeakInsteadOfSingleFrameSpike() {
        val events = listOf(
            SoundEvent(0L, 5_000L, -1f, "いびき候補"),
            SoundEvent(20_000L, 25_000L, -12f, "いびき候補")
        )
        val samples = buildList {
            for (t in 0L..5_000L step 50L) add(VolumeSample(t, if (t == 2_500L) -1f else -18f))
            for (t in 20_000L..25_000L step 50L) add(VolumeSample(t, -12f))
        }
        val ranked = LoudMoments.rankSnores(session(60_000L, events, samples), 2)
        assertEquals(2, ranked.size)
        assertTrue(ranked[0].offsetMs in 20_000L..25_000L)
        assertTrue(ranked[0].peakDb >= -12.1f)
    }
    @Test fun frozenMetricsSurviveWaveformCompaction() {
        val original = session(
            duration = 60_000L,
            events = listOf(SoundEvent(0L, 20_000L, -18f, "いびき候補")),
            samples = (0..1200).map { i -> VolumeSample(i * 50L, if (i in 100..300) -18f else -58f) }
        )
        val duration = SessionMetrics.snoreDuration(original)
        val score = SessionMetrics.snoreScore(original)
        val compact = original.copy(
            audioDeleted = true,
            samples = listOf(VolumeSample(0L, -58f), VolumeSample(60_000L, -18f)),
            storedSnoreDurationMs = duration,
            storedSnoreScore = score
        )
        assertEquals(duration, SessionMetrics.snoreDuration(compact))
        assertEquals(score, SessionMetrics.snoreScore(compact))
    }

    @Test fun manualLabelsAreCountedInMatchingDisplayBuckets() {
        val s = session(
            duration = 60_000L,
            events = listOf(
                SoundEvent(0, 1000, -15f, "不明", "いびき"),
                SoundEvent(2000, 3000, -15f, "不明", "咳"),
                SoundEvent(4000, 5000, -15f, "不明", "犬の鳴き声")
            )
        )
        val counts = SessionMetrics.automaticClassCounts(s)
        assertEquals(1, counts["いびき候補"])
        assertEquals(1, counts["咳候補"])
        assertEquals(1, counts["声・犬候補"])
    }

}
