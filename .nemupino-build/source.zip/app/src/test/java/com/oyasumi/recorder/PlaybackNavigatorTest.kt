package com.oyasumi.recorder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackNavigatorTest {
    private val events = listOf(
        SoundEvent(10_000L, 16_000L, -18f),
        SoundEvent(40_000L, 46_000L, -11f),
        SoundEvent(90_000L, 96_000L, -22f)
    )

    @Test
    fun nextAndPreviousRespectBounds() {
        assertEquals(1, PlaybackNavigator.nextIndex(0, events.size))
        assertEquals(1, PlaybackNavigator.previousIndex(2, events.size))
        assertNull(PlaybackNavigator.previousIndex(0, events.size))
        assertNull(PlaybackNavigator.nextIndex(2, events.size))
    }

    @Test
    fun nearestEventUsesEventCenter() {
        assertEquals(0, PlaybackNavigator.nearestEventIndex(events, 12_000L))
        assertEquals(1, PlaybackNavigator.nearestEventIndex(events, 44_000L))
        assertEquals(2, PlaybackNavigator.nearestEventIndex(events, 100_000L))
    }

    @Test
    fun waveformWindowKeepsOnlyNearbySamples() {
        val samples = (0..120).map { VolumeSample(it * 1_000L, -30f) }
        val sliced = PlaybackNavigator.samplesAroundEvent(samples, events[1], 120_000L, paddingMs = 5_000L)
        assertTrue(sliced.isNotEmpty())
        assertEquals(35_000L, sliced.first().offsetMs)
        assertEquals(51_000L, sliced.last().offsetMs)
    }
}
