package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class NemuPino360Test {
    private fun session(
        duration: Long = 3_600_000L,
        events: List<SoundEvent>,
        samples: List<VolumeSample> = emptyList()
    ) = RecordingSession("s", 0L, duration, "a.m4a", events, samples)

    @Test fun scoreCanExceed100ForSustainedEpicSnoring() {
        val event = SoundEvent(0, 3_600_000L, -6f, "いびき候補")
        val s = session(events = listOf(event))
        assertTrue(SessionMetrics.snoreScore(s) > 100)
    }

    @Test fun scoreRewardsIntensityAtSameDuration() {
        val light = session(events = listOf(SoundEvent(0, 600_000L, -32f, "いびき候補")))
        val loud = session(events = listOf(SoundEvent(0, 600_000L, -20f, "いびき候補")))
        val epic = session(events = listOf(SoundEvent(0, 600_000L, -8f, "いびき候補")))
        assertTrue(SessionMetrics.snoreScore(light) < SessionMetrics.snoreScore(loud))
        assertTrue(SessionMetrics.snoreScore(loud) < SessionMetrics.snoreScore(epic))
    }

    @Test fun nonSnoreNeverAddsScoreEvenWhenVeryLoud() {
        val s = session(events = listOf(
            SoundEvent(0, 600_000L, -1f, "物音候補"),
            SoundEvent(700_000L, 900_000L, -2f, "声・犬候補")
        ))
        assertEquals(0, SessionMetrics.snoreScore(s))
    }

    @Test fun fastSaveEnvelopeReducesOvernightMeterPointsAndKeepsPeak() {
        val duration = 8L * 60 * 60 * 1000
        val samples = ArrayList<VolumeSample>()
        var t = 0L
        while (t <= duration) {
            samples += VolumeSample(t, if (t == 12_400L) -5f else -40f)
            t += 200L
        }
        val span = PartSpan(0L, duration, 0L, duration)
        val result = FastSaveEnvelope.build(samples, listOf(span), duration)
        assertTrue(result.size <= duration / 1000 + 2)
        assertTrue(result.size < samples.size / 4)
        assertTrue(result.any { it.db == -5f })
    }

    @Test fun fastSaveEnvelopeRemovesRecorderRestartGapFromTimeline() {
        val spans = listOf(
            PartSpan(0, 10_000, 0, 10_000),
            PartSpan(12_000, 22_000, 10_000, 10_000)
        )
        val result = FastSaveEnvelope.build(
            listOf(VolumeSample(9_800, -20f), VolumeSample(12_200, -10f), VolumeSample(21_800, -15f)),
            spans,
            20_000,
            bucketMs = 200
        )
        assertTrue(result.all { it.offsetMs <= 20_000 })
        assertTrue(result.any { it.offsetMs in 10_000L..10_500L && it.db == -10f })
    }
}
