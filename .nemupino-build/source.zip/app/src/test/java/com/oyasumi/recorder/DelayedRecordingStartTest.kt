package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class DelayedRecordingStartTest {
    @Test fun waitsThirtyMinutesAndStartsOnlyOnce() {
        val timer = DelayedRecordingStart()
        timer.arm(100L, 1_800_000L)
        assertEquals(1_800_000L, timer.remainingMs(100L))
        assertFalse(timer.consumeIfDue(1_800_099L))
        assertTrue(timer.consumeIfDue(1_800_100L))
        assertFalse(timer.consumeIfDue(1_800_101L))
        assertNull(timer.remainingMs(1_800_101L))
    }
    @Test fun cancelledReservationNeverStarts() {
        val timer = DelayedRecordingStart()
        timer.arm(0L, 1_800_000L)
        timer.cancel()
        assertFalse(timer.consumeIfDue(2_000_000L))
        assertNull(timer.remainingMs(0L))
    }
    @Test fun delayedTickStartsImmediatelyWithoutNegativeCountdown() {
        val timer = DelayedRecordingStart()
        timer.arm(0L, 1_800_000L)
        assertEquals(0L, timer.remainingMs(1_900_000L))
        assertTrue(timer.consumeIfDue(1_900_000L))
    }
}
