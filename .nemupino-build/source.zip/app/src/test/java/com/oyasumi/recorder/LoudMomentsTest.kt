package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class LoudMomentsTest {
    private fun session(samples: List<VolumeSample>, events: List<SoundEvent> = emptyList()) = RecordingSession("rank", 0, 60_000, "test.m4a", events, samples)
    @Test fun descendingPeaksSuppressNearbyPartsOfTheSameSound() {
        val ranks = LoudMoments.rank(session(listOf(VolumeSample(1000,-20f), VolumeSample(1400,-5f), VolumeSample(6000,-7f), VolumeSample(22000,-10f), VolumeSample(40000,-15f))))
        assertEquals(listOf(1400L,22000L,40000L), ranks.map { it.offsetMs })
        assertEquals(0L,ranks.first().playbackStartMs)
        assertEquals(20500L,ranks[1].playbackStartMs)
    }
    @Test fun invalidSamplesAreIgnoredAndTiesUseEarlierTime() {
        val ranks = LoudMoments.rank(session(listOf(VolumeSample(-1,0f),VolumeSample(60000,0f),VolumeSample(1000,Float.NaN),VolumeSample(23000,-5f),VolumeSample(21000,-5f),VolumeSample(45000,-5f))))
        assertEquals(listOf(21000L,45000L),ranks.map { it.offsetMs })
    }
    @Test fun missingWaveformUsesEventsAndLimitIsHonored() {
        val s=session(emptyList(),listOf(SoundEvent(0,1000,-20f),SoundEvent(20000,21000,-5f)))
        assertEquals(20000L,LoudMoments.rank(s,1).single().offsetMs)
        assertTrue(LoudMoments.rank(s,0).isEmpty())
        assertTrue(LoudMoments.rank(session(emptyList())).isEmpty())
    }
    @Test fun navigationPlaysToRecordingEndWithoutExcerptMode() {
        val event=SoundEvent(20000,20100,-5f)
        assertEquals(SoundEvent(20000,60000,-5f),PlaybackRanges.fromEvent(event,60000,false))
        assertEquals(event,PlaybackRanges.fromEvent(event,60000,true))
    }
    @Test fun graphSeekClampsBothEdgesAndAllowsRecordingsWithoutEvents() {
        assertEquals(SoundEvent(0,60000,0f),PlaybackRanges.fromTime(-100,60000))
        assertEquals(SoundEvent(59999,60000,0f),PlaybackRanges.fromTime(60000,60000))
        assertNull(PlaybackRanges.fromTime(0,0))
    }
    @Test fun nextFromGraphPositionSkipsEarlierEventsAndSeekRounding() {
        val events=listOf(SoundEvent(1000,1500,-5f),SoundEvent(20000,21000,-5f),SoundEvent(40000,41000,-5f))
        assertEquals(2,PlaybackNavigator.nextAfterPosition(events,listOf(0,1,2),19980))
        assertEquals(2,PlaybackNavigator.nextAfterPosition(events,listOf(0,2),20000))
        assertNull(PlaybackNavigator.nextAfterPosition(events,listOf(0,1,2),45000))
    }
}
