package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class SaveAndMetricsTest {
    private fun session(events: List<SoundEvent> = emptyList(), samples: List<VolumeSample> = emptyList()) = RecordingSession("test", 0, 10000, "test.m4a", events, samples)
    @Test fun labelsOverrideCandidatesAndOverlappingTimeIsCountedOnce() {
        val events = listOf(SoundEvent(1000, 4000, -20f, "いびき候補"), SoundEvent(3000, 5000, -20f, "いびき候補"), SoundEvent(6000, 8000, -20f, "いびき候補", "環境音"), SoundEvent(8500, 9500, -20f, "不明", "いびき"))
        assertEquals(5000L, SessionMetrics.snoreDuration(session(events)))
        assertEquals(50, SessionMetrics.snorePercent(session(events)))
    }
    @Test fun outOfRangeEventsCannotExceedTheRecording() {
        assertEquals(10000L, SessionMetrics.snoreDuration(session(listOf(SoundEvent(-1000, 20000, -10f, "いびき候補")))))
        assertEquals(0L, SessionMetrics.snoreDuration(session(listOf(SoundEvent(8000, 1000, -10f, "いびき候補")))))
    }
    @Test fun levelDurationsUseTimeRatherThanSampleCounts() {
        val values = listOf(VolumeSample(1000, -40f), VolumeSample(2000, -28f), VolumeSample(6000, -20f), VolumeSample(9000, -10f))
        assertEquals(listOf(2000L, 4000L, 3000L, 1000L), SessionMetrics.intensityDurations(session(samples = values)))
    }
    @Test fun emptyDecoderOutputCannotResetTheWatchdog() {
        val watchdog = DecodeWatchdog(100, 0)
        watchdog.check(false, 80)
        watchdog.check(true, 90)
        watchdog.check(false, 180)
        assertThrows(IllegalStateException::class.java) { watchdog.check(false, 191) }
    }
}
