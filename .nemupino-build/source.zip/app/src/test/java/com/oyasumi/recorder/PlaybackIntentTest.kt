package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class PlaybackIntentTest {
    @Test fun pauseDuringSeekWinsOverTheCompletionCallback() {
        val state = PlaybackIntent()
        state.start()
        assertFalse(state.toggle())
        assertFalse(state.finishSeek())
        assertFalse(state.seeking)
    }
    @Test fun seekingWhilePausedDoesNotResumeAudio() {
        val state = PlaybackIntent()
        state.start(); state.finishSeek(); state.toggle()
        state.beginSeek()
        assertFalse(state.finishSeek())
    }
    @Test fun repeatedSeeksUseTheLatestPlayPauseChoice() {
        val state = PlaybackIntent()
        state.start(); state.finishSeek(); state.beginSeek(); state.toggle()
        state.beginSeek(); state.toggle()
        assertTrue(state.finishSeek())
    }
    @Test fun stoppingClearsPendingPlayback() {
        val state = PlaybackIntent()
        state.start(); state.reset()
        assertFalse(state.finishSeek())
        assertFalse(state.wantsPlayback)
    }
}
