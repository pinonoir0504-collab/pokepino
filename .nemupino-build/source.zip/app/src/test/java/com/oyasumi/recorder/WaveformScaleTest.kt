package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class WaveformScaleTest {
    @Test fun quietAudioRemainsThinButVisible() {
        val heights = listOf(-60f, -50f, -40f, -34f).map { WaveformScale.height(it) }
        assertTrue(heights.all { it > 0f && it <= 0.03001f })
        assertTrue(heights.zipWithNext().all { (a, b) -> a < b })
        assertEquals(0f, WaveformScale.height(Float.NaN), 0f)
        assertEquals(0f, WaveformScale.height(Float.POSITIVE_INFINITY), 0f)
    }
    @Test fun raisingDisplayFloorCompressesRoomNoiseWithoutErasingIt() {
        assertTrue(WaveformScale.height(-30f, -40f) > WaveformScale.height(-30f, -28f))
        assertTrue(WaveformScale.height(-30f, -28f) > 0f)
    }
    @Test fun scaleIsContinuousOrderedAndBounded() {
        val heights = (-60..0).map { WaveformScale.height(it.toFloat()) }
        assertTrue(heights.all { it in 0f..1f })
        assertTrue(heights.zipWithNext().all { (a, b) -> a <= b })
        assertEquals(WaveformScale.height(-34f), WaveformScale.height(-33.999f), 0.00001f)
        assertEquals(1f, WaveformScale.height(-12f), 0.00001f)
    }
}
