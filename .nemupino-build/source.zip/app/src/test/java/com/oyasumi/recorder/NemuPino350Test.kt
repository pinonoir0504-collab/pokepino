package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class NemuPino350Test {
    private fun session(events: List<SoundEvent>, samples: List<VolumeSample> = emptyList(), duration: Long = 60_000L) =
        RecordingSession("s", 0L, duration, "a.m4a", events, samples)

    @Test fun bigSnoreRankingExcludesLouderNonSnoreSounds() {
        val events = listOf(
            SoundEvent(1_000, 4_000, -3f, "物音候補"),
            SoundEvent(15_000, 18_000, -16f, "いびき候補"),
            SoundEvent(35_000, 38_000, -10f, "いびき候補"),
            SoundEvent(50_000, 52_000, -5f, "声・犬候補")
        )
        val ranked = LoudMoments.rankSnores(session(events), 5)
        assertEquals(listOf(35_000L, 15_000L), ranked.map { it.offsetMs })
        assertTrue(ranked.none { it.offsetMs == 1_000L || it.offsetMs == 50_000L })
    }

    @Test fun manualLabelsOverrideAutomaticNoiseAndSnoreClassification() {
        assertTrue(SessionMetrics.isSnore(SoundEvent(0, 1_000, -10f, "声・犬候補", "いびき")))
        assertFalse(SessionMetrics.isSnore(SoundEvent(0, 1_000, -10f, "いびき候補", "咳")))
    }

    @Test fun scoreUsesOnlySnoringEvents() {
        val noSnore = session(listOf(SoundEvent(0, 10_000, -1f, "物音候補")))
        assertEquals(0, SessionMetrics.snoreScore(noSnore))
        val snores = session(listOf(SoundEvent(0, 6_000, -12f, "いびき候補"), SoundEvent(20_000, 25_000, -18f, "いびき候補")))
        assertTrue(SessionMetrics.snoreScore(snores) > 0)
        assertEquals(2, SessionMetrics.bigSnoreCount(snores))
    }

    @Test fun shortSharpImpactIsNotSnoreCandidate() {
        val features = (0..120).map { i ->
            val t = i * 50L
            SoundFeature(t, if (i in 40..44) -4f else -58f, 0.05f, 0.55f)
        }
        val event = SoundEvent(0, 6_000, -4f)
        val result = SoundCandidates.classify(listOf(event), features).single()
        assertEquals("物音候補", result.candidate)
    }

    @Test fun repeatedHigherFrequencyBurstsAreExcludedAsVoiceOrDog() {
        val features = (0..200).map { i ->
            val loud = (i in 20..28) || (i in 42..50) || (i in 66..74)
            SoundFeature(i * 50L, if (loud) -12f else -55f, if (loud) 0.18f else 0.05f, if (loud) 0.35f else 0.05f)
        }
        val event = SoundEvent(0, 10_000, -12f)
        val result = SoundCandidates.classify(listOf(event), features).single()
        assertEquals("声・犬候補", result.candidate)
    }
    @Test fun coughIsExcludedFromSnoreCandidate() {
        val features = (0..120).map { i ->
            val loud = i in 35..50
            SoundFeature(i * 50L, if (loud) -10f else -56f, if (loud) 0.32f else 0.05f, if (loud) 0.28f else 0.03f)
        }
        val result = SoundCandidates.classify(listOf(SoundEvent(0, 6_000, -10f)), features).single()
        assertEquals("咳候補", result.candidate)
    }

    @Test fun longerBroadbandVoiceIsSleepTalkCandidate() {
        val features = (0..160).map { i ->
            val loud = i in 45..80
            SoundFeature(i * 50L, if (loud) -16f else -56f, if (loud) 0.30f else 0.05f, if (loud) 0.24f else 0.03f)
        }
        val result = SoundCandidates.classify(listOf(SoundEvent(0, 8_000, -16f)), features).single()
        assertEquals("寝言候補", result.candidate)
    }

}
