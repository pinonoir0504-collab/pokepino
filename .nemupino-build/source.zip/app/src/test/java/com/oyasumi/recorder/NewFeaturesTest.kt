package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class NewFeaturesTest {
    @Test fun timelineRemovesRecorderRestartGap() {
        val spans = listOf(PartSpan(0, 600_000, 0, 600_000), PartSpan(600_250, 1_200_250, 600_000, 600_000))
        assertEquals(600_000L, PartTimeline.audioTime(600_100, spans))
        assertEquals(610_000L, PartTimeline.audioTime(610_250, spans))
        assertEquals(1_200_000L, PartTimeline.audioTime(2_000_000, spans))
    }
    @Test fun waveformClampsAndRetainsBoundaryTimes() {
        assertEquals(0L, WaveWindow.start(2000, 30_000, 120_000))
        assertEquals(90_000L, WaveWindow.start(119_000, 30_000, 120_000))
        val samples = (0..100).map { VolumeSample(it * 100L, -30f) }
        val window = WaveWindow.slice(samples, 3050, 9050)
        assertEquals(3050L, window.first().offsetMs)
        assertEquals(9050L, window.last().offsetMs)
        assertTrue(window.zipWithNext().all { (a,b) -> a.offsetMs <= b.offsetMs })
    }
    @Test fun silenceDoesNotBecomeSnoring() {
        assertEquals("不明", SoundCandidates.classifyWindow((0..200).map { SoundFeature(it * 50L, -60f, 0f, 0f) }))
    }
    @Test fun steadyBackgroundGetsEnvironmentCandidate() {
        assertEquals("環境音候補", SoundCandidates.classifyWindow((0..200).map { SoundFeature(it * 50L, -25f, 0.1f, 0.3f) }))
    }
    @Test fun repeatedLowFrequencyBurstsAreCandidatesNotConfirmedSnoring() {
        val features = (0..400).map { val loud = it % 60 < 12; SoundFeature(it * 50L, if (loud) -18f else -55f, 0.8f, 0.04f) }
        assertEquals("いびき候補", SoundCandidates.classifyWindow(features))
        assertEquals("不明", SoundCandidates.classifyWindow(features.map { it.copy(lowRatio = 0.01f, crossingRate = 0.8f) }))
    }
    @Test fun signalMeterDistinguishesLowAndHighFrequency() {
        fun ratio(freq: Int): Float {
            val meter = SoundFeatureMeter(16000)
            repeat(8000) { meter.add((10000 * sin(2 * PI * freq * it / 16000)).toInt()) }
            return meter.finish(0, -20f).lowRatio
        }
        assertTrue(ratio(150) > 0.75)
        assertTrue(ratio(4000) < 0.1)
    }
    @Test fun shortBreathsUseNeighbouringRhythmWithoutLabellingNearbyNoise() {
        val features = (0..400).map { val loud = it % 60 < 12; SoundFeature(it * 50L, if (loud) -18f else -55f, 0.8f, 0.04f) }
        val breaths = listOf(SoundEvent(0, 550, -18f), SoundEvent(3000, 3550, -18f), SoundEvent(6000, 6550, -18f))
        assertTrue(SoundCandidates.classify(breaths, features).all { it.candidate == "いびき候補" })
        val nearbyNoise = features.map { if (it.offsetMs in 9000L..9550L) it.copy(lowRatio = 0.01f, crossingRate = 0.8f) else it }
        assertEquals("不明", SoundCandidates.classify(listOf(SoundEvent(9000, 9550, -18f)), nearbyNoise).single().candidate)
        assertEquals("不明", SoundCandidates.classify(listOf(SoundEvent(1500, 2000, -55f)), features).single().candidate)
        assertEquals("不明", SoundCandidates.classify(breaths.take(1), features.take(60)).single().candidate)
    }
    @Test fun packedSamplesPreserveTimesAndHalfDbPrecision() {
        val samples = (0..10000).map { VolumeSample(it * 50L, -30.5f) }
        val packed = PackedVolumeSamples.pack(samples)
        assertTrue(packed is PackedVolumeSamples)
        assertEquals(samples, packed)
        assertSame(packed, PackedVolumeSamples.pack(packed))
        assertEquals(samples, SampleCodec.decode(SampleCodec.encode(packed)))
    }

    @Test fun eightHourWaveformSurvivesStorageAndEndOfNightZoom() {
        val night = object : AbstractList<VolumeSample>() {
            override val size = 8 * 60 * 60 * 20
            override fun get(index: Int) = VolumeSample(index * 50L, -60f + (index % 121) / 2f)
        }
        val restored = SampleCodec.decode(SampleCodec.encode(PackedVolumeSamples.pack(night)))
        assertEquals(night.size, restored.size)
        listOf(0, 10000, night.size / 2, night.lastIndex).forEach { assertEquals(night[it], restored[it]) }
        val end = 8 * 60 * 60 * 1000L
        val window = WaveWindow.slice(restored, end - 5000, end)
        assertEquals(end - 5000, window.first().offsetMs)
        assertEquals(end, window.last().offsetMs)
        assertTrue(window.size <= 102)
    }

}
