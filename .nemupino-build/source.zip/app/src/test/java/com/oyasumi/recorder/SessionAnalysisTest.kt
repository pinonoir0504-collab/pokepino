package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class SessionAnalysisTest {
    @Test fun graphReductionKeepsBriefPeakBetweenOtherSamples() {
        val samples = (0 until 1000).map { VolumeSample(it * 200L, if (it == 317) -9f else -60f) }
        val reduced = SessionAnalysis.peaks(samples, 50)
        assertEquals(50, reduced.size)
        assertTrue(reduced.any { it.offsetMs == 317 * 200L && it.db == -9f })
        assertTrue(reduced.zipWithNext().all { (a, b) -> a.offsetMs <= b.offsetMs })
    }
    @Test fun loudPercentageUsesMeasuredTimeNotPaddedEvents() {
        val session = RecordingSession("s", 0, 10000, "a.m4a", listOf(SoundEvent(0, 10000, -10f)),
            listOf(VolumeSample(0, -60f), VolumeSample(2000, -10f), VolumeSample(3000, -60f)))
        assertEquals(10, SessionAnalysis.loudPercent(session))
    }
    @Test fun emptyRecordingHasNoLoudPercentageOrLoudestEvent() {
        assertEquals(0, SessionAnalysis.loudPercent(RecordingSession("s", 0, 0, "", emptyList(), emptyList())))
        assertNull(SessionAnalysis.loudestIndex(emptyList()))
    }
    @Test fun loudestJumpUsesPeakNotLongestDuration() {
        assertEquals(1, SessionAnalysis.loudestIndex(listOf(SoundEvent(0, 9000, -20f), SoundEvent(10000, 11000, -8f))))
    }
}
