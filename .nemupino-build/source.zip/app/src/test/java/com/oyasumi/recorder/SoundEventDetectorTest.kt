package com.oyasumi.recorder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SoundEventDetectorTest {
    @Test
    fun quietSamplesDoNotCreateEvent() {
        val detector = SoundEventDetector(thresholdDb = -26f)
        repeat(20) { i ->
            assertNull(detector.onSample(i * 250L, -40f))
        }
        assertNull(detector.finish(5_000L))
    }

    @Test
    fun loudBurstCreatesPaddedEvent() {
        val detector = SoundEventDetector(thresholdDb = -26f)
        detector.onSample(5_000L, -15f)
        detector.onSample(5_250L, -12f)
        detector.onSample(5_500L, -18f)
        assertNull(detector.onSample(6_000L, -40f))
        val event = detector.onSample(7_100L, -40f)
        requireNotNull(event)
        assertEquals(3_000L, event.startMs)
        assertEquals(8_000L, event.endMs)
        assertEquals(-12f, event.peakDb)
    }

    @Test
    fun finishClosesOpenEvent() {
        val detector = SoundEventDetector(thresholdDb = -26f)
        detector.onSample(1_000L, -10f)
        val event = detector.finish(1_250L)
        requireNotNull(event)
        assertEquals(0L, event.startMs)
        assertTrue(event.endMs >= 3_500L)
    }
}
