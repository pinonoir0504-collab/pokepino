package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class SeekQueueTest {
    @Test fun rapidRequestsKeepOnlyTheLatestPendingTarget() {
        val q=SeekQueue()
        assertEquals(1000L,q.request(1000))
        assertNull(q.request(2000)); assertNull(q.request(3000))
        assertEquals(3000L,q.complete()); assertTrue(q.inFlight)
        assertNull(q.complete()); assertFalse(q.inFlight)
    }
    @Test fun newRequestDuringQueuedSeekIsAlsoSerialized() {
        val q=SeekQueue()
        q.request(1000); q.request(2000)
        assertEquals(2000L,q.complete())
        assertNull(q.request(4000))
        assertEquals(4000L,q.complete())
        assertNull(q.complete())
        assertEquals(5000L,q.request(5000))
    }
    @Test fun stopDiscardsQueuedSeekBeforeNewRecording() {
        val q=SeekQueue();q.request(1000);q.request(3000);q.reset()
        assertFalse(q.inFlight)
        assertEquals(7000L,q.request(7000));assertNull(q.complete())
    }
    @Test fun pauseChoiceSurvivesBothSeekCompletions() {
        val q=SeekQueue();val intent=PlaybackIntent();intent.start()
        q.request(1000);q.request(3000);assertFalse(intent.toggle())
        assertEquals(3000L,q.complete());assertTrue(intent.seeking)
        assertNull(q.complete());assertFalse(intent.finishSeek())
    }
    @Test fun previousAndLabelsUseTheActualSeekPosition() {
        val events=listOf(SoundEvent(1000,1500,-5f),SoundEvent(20000,21000,-5f),SoundEvent(40000,41000,-5f))
        assertEquals(1,PlaybackNavigator.previousBeforePosition(events,listOf(0,1,2),30000))
        assertEquals(0,PlaybackNavigator.previousBeforePosition(events,listOf(0,1,2),20020))
        assertNull(PlaybackNavigator.previousBeforePosition(events,listOf(0,1,2),0))
        assertEquals(1,PlaybackNavigator.containingEvent(events,listOf(0,1,2),20000))
        assertNull(PlaybackNavigator.containingEvent(events,listOf(0,1,2),21000))
        assertNull(PlaybackNavigator.containingEvent(events,listOf(0,2),20000))
    }
    @Test fun labelTargetDoesNotMoveToAnotherSoundWhenAnalysisInsertsEvents() {
        val target=SoundEvent(20000,21000,-5f)
        val updated=listOf(SoundEvent(1000,1500,-5f),SoundEvent(10000,11000,-5f),target.copy(candidate="いびき候補"))
        assertEquals(2,PlaybackNavigator.matchingEventIndex(updated,target))
        assertNull(PlaybackNavigator.matchingEventIndex(updated,target.copy(endMs=22000)))
    }
}
