package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class EventLookupTest {
    @Test fun cachedLookupMatchesLinearNavigationAcrossLongRecording() {
        val events=(0 until 2000).map { SoundEvent(it*1000L,it*1000L+400L,-10f) }
        val visible=events.indices.filter { it%3!=0 }
        val lookup=EventLookup(events,visible)
        for(time in 0L..2_000_000L step 997L) {
            assertEquals(PlaybackNavigator.nextAfterPosition(events,visible,time),lookup.next(time))
            assertEquals(PlaybackNavigator.previousBeforePosition(events,visible,time),lookup.previous(time))
            assertEquals(PlaybackNavigator.containingEvent(events,visible,time),lookup.containing(time))
        }
    }
    @Test fun overlappingEventsChooseFirstContainingInterval() {
        val events=listOf(SoundEvent(0,30000,-10f),SoundEvent(5000,6000,-5f),SoundEvent(10000,12000,-5f))
        val lookup=EventLookup(events,listOf(0,1,2))
        assertEquals(0,lookup.containing(11000))
        assertNull(lookup.containing(30000))
        assertEquals(2,EventLookup(events,listOf(1,2)).containing(11000))
    }
    @Test fun emptyAndInvalidIndicesAreSafe() {
        val lookup=EventLookup(emptyList(),listOf(-1,5))
        assertNull(lookup.next(0));assertNull(lookup.previous(0));assertNull(lookup.containing(0))
    }
}
