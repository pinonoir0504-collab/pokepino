package com.oyasumi.recorder

import org.junit.Assert.*
import org.junit.Test

class SampleCodecTest {
    @Test fun delayedSamplesKeepExactTimestampAfterSaving() {
        val samples = listOf(VolumeSample(0, -60f), VolumeSample(213, -32.5f), VolumeSample(9017, -9f))
        assertEquals(samples, SampleCodec.decode(SampleCodec.encode(samples)))
    }
    @Test fun wholeNightRoundTripKeepsEverySample() {
        val samples = (0 until 144000).map { VolumeSample(it * 200L, if (it % 19 == 0) -12f else -50f) }
        val decoded = SampleCodec.decode(SampleCodec.encode(samples))
        assertEquals(samples.size, decoded.size)
        assertEquals(samples.last(), decoded.last())
    }
    @Test fun corruptAudioEnvelopeDoesNotCrashHistoryLoading() {
        assertTrue(SampleCodec.decode("not-valid!").isEmpty())
        val valid = SampleCodec.encode(listOf(VolumeSample(0, -20f)))
        assertTrue(SampleCodec.decode(valid.take(valid.length / 2)).isEmpty())
    }
    @Test fun nonmonotonicEnvelopeIsRejected() {
        assertTrue(SampleCodec.decode(SampleCodec.encode(listOf(VolumeSample(500, -20f), VolumeSample(100, -10f)))).isEmpty())
    }
}
