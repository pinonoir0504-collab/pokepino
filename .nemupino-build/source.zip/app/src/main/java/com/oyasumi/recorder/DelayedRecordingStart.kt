package com.oyasumi.recorder

/** A one-shot deadline based on elapsed realtime, independent of wall-clock changes. */
class DelayedRecordingStart {
    private var deadlineMs: Long? = null
    fun arm(nowMs: Long, delayMs: Long) { deadlineMs = nowMs + delayMs.coerceAtLeast(0L) }
    fun remainingMs(nowMs: Long): Long? = deadlineMs?.let { (it - nowMs).coerceAtLeast(0L) }
    fun consumeIfDue(nowMs: Long): Boolean {
        val deadline = deadlineMs ?: return false
        if (nowMs < deadline) return false
        deadlineMs = null
        return true
    }
    fun cancel() { deadlineMs = null }
}
