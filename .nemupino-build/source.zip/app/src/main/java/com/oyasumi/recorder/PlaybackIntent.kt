package com.oyasumi.recorder

/** Keeps the user's play/pause choice independent of asynchronous seek completion. */
class PlaybackIntent {
    var wantsPlayback = false
        private set
    var seeking = false
        private set
    fun start() { wantsPlayback = true; seeking = true }
    fun beginSeek() { seeking = true }
    fun finishSeek(): Boolean { seeking = false; return wantsPlayback }
    fun toggle(): Boolean { wantsPlayback = !wantsPlayback; return wantsPlayback }
    fun reset() { wantsPlayback = false; seeking = false }
}
