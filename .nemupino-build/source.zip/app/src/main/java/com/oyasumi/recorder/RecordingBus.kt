package com.oyasumi.recorder

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object RecordingBus {
    private val _state = MutableStateFlow<RecordingUiState>(RecordingUiState.Idle)
    val state = _state.asStateFlow()

    private val _lastCompletedSessionId = MutableStateFlow<String?>(null)
    val lastCompletedSessionId = _lastCompletedSessionId.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()

    fun reportError(message: String?) { _error.value = message }

    fun update(state: RecordingUiState) {
        _state.value = state
    }

    fun completed(sessionId: String) {
        _lastCompletedSessionId.value = sessionId
    }
}
