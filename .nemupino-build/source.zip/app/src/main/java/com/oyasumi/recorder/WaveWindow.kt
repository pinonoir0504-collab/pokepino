package com.oyasumi.recorder

object WaveWindow {
    fun start(center: Long, width: Long, duration: Long): Long = (center - width / 2).coerceIn(0L, (duration - width).coerceAtLeast(0L))
    fun slice(samples: List<VolumeSample>, start: Long, end: Long): List<VolumeSample> {
        if (samples.isEmpty() || end <= start) return emptyList()
        var low = 0; var high = samples.size
        while (low < high) { val middle = (low + high) / 2; if (samples[middle].offsetMs < start) low = middle + 1 else high = middle }
        val first = low
        high = samples.size
        while (low < high) { val middle = (low + high) / 2; if (samples[middle].offsetMs <= end) low = middle + 1 else high = middle }
        val actual = samples.subList(first, low)
        return buildList {
            add(VolumeSample(start, samples.getOrNull((first - 1).coerceAtLeast(0))?.db ?: -60f))
            addAll(actual)
            if (last().offsetMs < end) add(VolumeSample(end, last().db))
        }
    }
}
