package com.oyasumi.recorder

import java.io.File
import org.json.JSONArray
import org.json.JSONObject

data class AudioPart(val fileName: String, val durationMs: Long)

/** Small durable index: saving never copies the overnight AAC payload. */
object AudioPlaylist {
    fun write(output: File, parts: List<AudioPart>) {
        require(parts.isNotEmpty() && parts.all { it.durationMs > 0 })
        val temp = File(output.path + ".pending")
        try {
            java.io.FileOutputStream(temp).use { stream ->
                val array = JSONArray()
                parts.forEach { array.put(JSONObject().put("file", it.fileName).put("duration", it.durationMs)) }
                stream.write(array.toString().toByteArray(Charsets.UTF_8))
                stream.fd.sync()
            }
            check(temp.renameTo(output))
        } finally { temp.delete() }
    }
    fun read(file: File): List<AudioPart> {
        if (file.extension != "playlist") return emptyList()
        val array = JSONArray(file.readText())
        return (0 until array.length()).map {
            val row = array.getJSONObject(it)
            val name = row.getString("file")
            require(File(name).name == name && name.endsWith(".m4a"))
            AudioPart(name, row.getLong("duration").also { duration -> require(duration > 0) })
        }
    }
}
