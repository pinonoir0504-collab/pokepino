package com.oyasumi.recorder

import kotlin.math.PI
import kotlin.math.exp

/** Lightweight offline signal heuristics, not a trained classifier or medical measurement. */
data class SoundFeature(val offsetMs: Long, val db: Float, val lowRatio: Float, val crossingRate: Float)
data class EnvelopeAnalysis(val samples: List<VolumeSample>, val features: List<SoundFeature>)

class SoundFeatureMeter(rate: Int) {
    private val alpha = 1.0 - exp(-2 * PI * 500 / rate)
    private var low = 0.0
    private var energy = 0.0
    private var lowEnergy = 0.0
    private var crossings = 0
    private var count = 0
    private var previous = 0
    fun add(value: Int) {
        low += alpha * (value - low)
        energy += value.toDouble() * value
        lowEnergy += low * low
        if (count > 0 && (value >= 0) != (previous >= 0)) crossings++
        previous = value; count++
    }
    fun finish(offset: Long, db: Float): SoundFeature {
        val result = SoundFeature(offset, db, if (energy > 0) (lowEnergy / energy).toFloat().coerceIn(0f, 1f) else 0f,
            if (count > 1) crossings.toFloat() / (count - 1) else 0f)
        energy = 0.0; lowEnergy = 0.0; crossings = 0; count = 0
        return result
    }
}

object SoundCandidates {
    fun classify(events: List<SoundEvent>, features: List<SoundFeature>): List<SoundEvent> = events.map { event ->
        val local = window(features, event.startMs, event.endMs)
        val localCandidate = classifyWindow(local)
        val audible = local.filter { it.db > -42f }
        val neighbour = window(features, (event.startMs - 12_000L).coerceAtLeast(0L), event.endMs + 12_000L)

        val candidate = when {
            localCandidate == "環境音候補" -> localCandidate
            isImpact(local) -> "物音候補"
            isCough(local) -> "咳候補"
            isSleepTalk(local) -> "寝言候補"
            isVoiceOrBark(local) -> "声・犬候補"
            audible.size >= 3 && audible.map { it.lowRatio }.average() >= 0.25 &&
                audible.map { it.crossingRate }.average() <= 0.25 &&
                classifyWindow(neighbour) == "いびき候補" -> "いびき候補"
            else -> "不明"
        }
        event.copy(candidate = candidate)
    }

    private fun window(features: List<SoundFeature>, start: Long, end: Long): List<SoundFeature> {
        fun bound(time: Long, inclusive: Boolean): Int {
            var low = 0
            var high = features.size
            while (low < high) {
                val middle = (low + high) ushr 1
                if (features[middle].offsetMs < time || (inclusive && features[middle].offsetMs == time)) low = middle + 1
                else high = middle
            }
            return low
        }
        return features.subList(bound(start, false), bound(end, true))
    }

    private data class Burst(val start: Long, val end: Long, val peak: Float) {
        val duration get() = (end - start).coerceAtLeast(50L)
    }

    private fun bursts(window: List<SoundFeature>): Pair<Float, List<Burst>> {
        if (window.size < 3) return -60f to emptyList()
        val sorted = window.map { it.db }.sorted()
        val floor = sorted[sorted.size / 5]
        val threshold = maxOf(floor + 9f, -38f)
        val result = mutableListOf<Burst>()
        var start: Long? = null
        var end = 0L
        var peak = -60f
        window.forEach { f ->
            if (f.db >= threshold) {
                if (start == null) start = f.offsetMs
                end = f.offsetMs + 50L
                peak = maxOf(peak, f.db)
            } else if (start != null) {
                result += Burst(start!!, end, peak)
                start = null; peak = -60f
            }
        }
        if (start != null) result += Burst(start!!, end, peak)
        return floor to result
    }

    /** Phone set-down / bedside bump: a very brief isolated transient with a large crest. */
    private fun isImpact(window: List<SoundFeature>): Boolean {
        val (floor, bs) = bursts(window)
        if (bs.size != 1) return false
        val b = bs.single()
        return b.duration <= 450L && b.peak - floor >= 18f
    }

    /** Cough-like: one or two short broadband bursts, not the low/rhythmic profile used for snoring. */
    private fun isCough(window: List<SoundFeature>): Boolean {
        val (_, bs) = bursts(window)
        if (bs.isEmpty() || bs.size > 2) return false
        if (bs.any { it.duration !in 200L..1400L }) return false
        val loud = window.filter { f -> bs.any { f.offsetMs in it.start..it.end } }
        if (loud.size < 3) return false
        val low = loud.map { it.lowRatio }.average()
        val crossing = loud.map { it.crossingRate }.average()
        return crossing >= 0.16 && low < 0.55
    }

    /** Longer broadband voice-like activity. Kept separate from snoring totals. */
    private fun isSleepTalk(window: List<SoundFeature>): Boolean {
        val (_, bs) = bursts(window)
        if (bs.isEmpty() || bs.size > 5) return false
        if (bs.none { it.duration >= 1200L }) return false
        val loud = window.filter { f -> bs.any { f.offsetMs in it.start..it.end } }
        if (loud.size < 8) return false
        val low = loud.map { it.lowRatio }.average()
        val crossing = loud.map { it.crossingRate }.average()
        return crossing >= 0.17 && low < 0.48
    }

    /** Repeated short higher-frequency bursts are treated as voice/bark candidates and excluded from snore totals. */
    private fun isVoiceOrBark(window: List<SoundFeature>): Boolean {
        val (_, bs) = bursts(window)
        if (bs.size < 2 || bs.size > 7) return false
        if (bs.count { it.duration <= 1200L } < 2) return false
        val starts = bs.map { it.start }
        val closeRepeats = starts.zipWithNext { a, b -> b - a }.count { it in 250L..2200L }
        if (closeRepeats < 1) return false
        val loud = window.filter { f -> bs.any { f.offsetMs in it.start..it.end } }
        if (loud.size < 4) return false
        val low = loud.map { it.lowRatio }.average()
        val crossing = loud.map { it.crossingRate }.average()
        return crossing >= 0.18 && low < 0.45
    }

    fun classifyWindow(window: List<SoundFeature>): String {
        if (window.size < 20) return "不明"
        val floor = window.map { it.db }.sorted()[window.size / 5]
        val range = window.maxOf { it.db } - window.minOf { it.db }
        if (range < 5 && floor > -50f && window.last().offsetMs - window.first().offsetMs >= 5000) return "環境音候補"
        val loud = window.filter { it.db > floor + 7 && it.db > -42f }
        if (loud.isEmpty()) return "不明"
        val starts = mutableListOf<Long>()
        var lastPeak = -10_000L
        var wasLoud = false
        window.forEach {
            val high = it.db > floor + 7 && it.db > -42f
            if (high && !wasLoud && it.offsetMs - lastPeak >= 1000) { starts.add(it.offsetMs); lastPeak = it.offsetMs }
            wasLoud = high
        }
        val intervals = starts.zipWithNext { a, b -> b - a }
        val rhythmic = intervals.size >= 2 && intervals.count { it in 1500L..8000L } >= intervals.size * 0.7
        val low = loud.map { it.lowRatio }.average()
        val crossing = loud.map { it.crossingRate }.average()
        if (rhythmic && low >= 0.25 && crossing <= 0.25) return "いびき候補"
        return "不明"
    }
}
