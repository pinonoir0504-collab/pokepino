package com.oyasumi.recorder

/** Cached chronological index; playback ticks no longer scan every event. */
class EventLookup(private val events: List<SoundEvent>, indices: List<Int>) {
    private val ordered = indices.filter { it in events.indices }.sortedBy { events[it].startMs }.toIntArray()
    private val maxEnds = LongArray(ordered.size).also { ends ->
        var max = Long.MIN_VALUE
        for (i in ordered.indices) { max = maxOf(max, events[ordered[i]].endMs); ends[i] = max }
    }
    private fun bound(time: Long, includeEqual: Boolean): Int {
        var low=0; var high=ordered.size
        while(low<high) {
            val mid=(low+high) ushr 1
            val start=events[ordered[mid]].startMs
            if(start<time || (includeEqual && start==time)) low=mid+1 else high=mid
        }
        return low
    }
    fun next(time: Long): Int? = ordered.getOrNull(bound(time + 250L, true))
    fun previous(time: Long): Int? = ordered.getOrNull(bound(time - 250L, false)-1)
    fun containing(time: Long): Int? {
        val upper=bound(time,true)
        var low=0; var high=upper
        while(low<high) { val mid=(low+high) ushr 1; if(maxEnds[mid]<=time) low=mid+1 else high=mid }
        return ordered.getOrNull(low)?.takeIf { low<upper && time<events[it].endMs }
    }
}
