package com.oyasumi.recorder

import kotlin.math.roundToInt

/**
 * Nightly snoring metrics.
 *
 * The score intentionally follows the public SnoreLab concept rather than its proprietary formula:
 * snoring duration is weighted by relative intensity (light/loud/epic). It is a trend metric only.
 * Unlike the old 0-100 score it can exceed 100, matching the behaviour described publicly by
 * SnoreLab. Relative dBFS thresholds are used because phone microphones are not calibrated SPL meters.
 */
object SessionMetrics {
    data class IntensityThresholds(val light: Float, val loud: Float, val epic: Float, val floor: Float)

    fun isSnore(event: SoundEvent): Boolean = if (event.label.isNotBlank()) event.label == "いびき" else event.candidate == "いびき候補"

    fun snoreEvents(session: RecordingSession): List<SoundEvent> = session.events.filter(::isSnore)

    fun snoreDuration(session: RecordingSession): Long {
        val snores = snoreEvents(session)
        if (snores.isEmpty() || session.durationMs <= 0L) return 0L
        if (session.samples.isNotEmpty()) {
            val activeThreshold = maxOf(noiseFloor(session) + 4f, -46f)
            val events = snores.sortedBy { it.startMs }
            var eventIndex = 0
            var total = 0L
            session.samples.forEachIndexed { index, sample ->
                while (eventIndex < events.size && events[eventIndex].endMs < sample.offsetMs) eventIndex++
                val event = events.getOrNull(eventIndex) ?: return@forEachIndexed
                if (sample.offsetMs !in event.startMs..event.endMs || sample.db < activeThreshold) return@forEachIndexed
                val end = (session.samples.getOrNull(index + 1)?.offsetMs ?: minOf(event.endMs, sample.offsetMs + 1_000L))
                    .coerceIn(sample.offsetMs, minOf(event.endMs, session.durationMs))
                total += end - sample.offsetMs
            }
            return total.coerceAtMost(session.durationMs)
        }

        var coveredEnd = 0L
        var total = 0L
        snores.sortedBy { it.startMs }.forEach {
            val start = it.startMs.coerceIn(0L, session.durationMs)
            val end = it.endMs.coerceIn(start, session.durationMs)
            total += (end - maxOf(start, coveredEnd)).coerceAtLeast(0L)
            coveredEnd = maxOf(coveredEnd, end)
        }
        return total
    }

    fun snorePercent(session: RecordingSession): Int = if (session.durationMs > 0)
        (snoreDuration(session).toDouble() * 100 / session.durationMs).roundToInt().coerceIn(0, 100) else 0

    /** Robust background estimate. It is relative recorder dBFS, not calibrated acoustic dB SPL. */
    fun noiseFloor(session: RecordingSession): Float {
        if (session.samples.isEmpty()) return -50f
        val finite = session.samples.asSequence().map { it.db }.filter { it.isFinite() }.toList().sorted()
        if (finite.isEmpty()) return -50f
        return finite[(finite.lastIndex * 0.20).toInt().coerceIn(0, finite.lastIndex)].coerceIn(-60f, -18f)
    }

    /**
     * Adaptive categories: relative to the night background, with absolute dBFS guards so a very
     * quiet digital floor does not make ordinary room noise look like loud/epic snoring.
     */
    fun intensityThresholds(session: RecordingSession): IntensityThresholds {
        val floor = noiseFloor(session)
        val light = maxOf(floor + 7f, -42f)
        val loud = maxOf(floor + 16f, -28f, light + 6f)
        val epic = maxOf(floor + 25f, -18f, loud + 7f)
        return IntensityThresholds(light, loud, epic, floor)
    }

    /** 1=light, 2=loud, 3=epic. */
    fun snoreIntensity(event: SoundEvent, session: RecordingSession): Int {
        val t = intensityThresholds(session)
        return when {
            event.peakDb >= t.epic -> 3
            event.peakDb >= t.loud -> 2
            else -> 1
        }
    }

    fun lightSnoreCount(session: RecordingSession): Int = snoreEvents(session).count { snoreIntensity(it, session) == 1 }
    fun loudSnoreCount(session: RecordingSession): Int = snoreEvents(session).count { snoreIntensity(it, session) == 2 }
    fun intenseSnoreCount(session: RecordingSession): Int = snoreEvents(session).count { snoreIntensity(it, session) == 3 }
    fun bigSnoreCount(session: RecordingSession): Int = loudSnoreCount(session) + intenseSnoreCount(session)
    fun peakSnoreDb(session: RecordingSession): Float? = snoreEvents(session).maxOfOrNull { it.peakDb }

    /**
     * SnoreLab-like public-model approximation.
     *
     * Public SnoreLab documentation says Snore Score reflects average volume and total duration,
     * with light/loud/epic intensity bands, and scores can exceed 100. We therefore calculate a
     * weighted snoring burden per recording hour instead of adding arbitrary event-count bonuses.
     * Light/Loud/Epic contribute 1x/2.5x/4.5x. 2 points per weighted minute/hour places an
     * ordinary mild night around the same tens-scale while sustained loud/epic nights can exceed 100.
     */
    fun snoreScore(session: RecordingSession): Int {
        if (session.durationMs <= 0L) return 0
        val snores = snoreEvents(session)
        if (snores.isEmpty()) return 0
        val weightedMs = weightedSnoreMs(session)
        val hours = session.durationMs / 3_600_000.0
        if (hours <= 0.0) return 0
        val weightedMinutesPerHour = weightedMs / 60_000.0 / hours
        return (weightedMinutesPerHour * 2.0).roundToInt().coerceIn(0, 999)
    }

    private fun weightedSnoreMs(session: RecordingSession): Double {
        val snores = snoreEvents(session)
        if (session.samples.isEmpty()) {
            return snores.sumOf { event ->
                val weight = when (snoreIntensity(event, session)) { 3 -> 4.5; 2 -> 2.5; else -> 1.0 }
                event.durationMs.coerceAtMost(session.durationMs).toDouble() * weight
            }
        }

        val thresholds = intensityThresholds(session)
        val activeThreshold = maxOf(thresholds.floor + 4f, -46f)
        val sortedEvents = snores.sortedBy { it.startMs }
        var eventIndex = 0
        var total = 0.0
        session.samples.forEachIndexed { index, sample ->
            while (eventIndex < sortedEvents.size && sortedEvents[eventIndex].endMs < sample.offsetMs) eventIndex++
            val event = sortedEvents.getOrNull(eventIndex) ?: return@forEachIndexed
            if (sample.offsetMs !in event.startMs..event.endMs) return@forEachIndexed
            val end = (session.samples.getOrNull(index + 1)?.offsetMs ?: minOf(event.endMs, sample.offsetMs + 1_000L))
                .coerceIn(sample.offsetMs, minOf(event.endMs, session.durationMs))
            val sliceMs = end - sample.offsetMs
            if (sliceMs <= 0L) return@forEachIndexed
            val weight = when {
                sample.db >= thresholds.epic -> 4.5
                sample.db >= thresholds.loud -> 2.5
                sample.db >= thresholds.light -> 1.0
                sample.db >= activeThreshold -> 0.5
                else -> 0.0
            }
            total += sliceMs * weight
        }
        return total
    }

    fun scoreLabel(score: Int): String = when {
        score <= 5 -> "とても静か"
        score <= 15 -> "静かめ"
        score <= 35 -> "ふつう"
        score <= 65 -> "いびき多め"
        score <= 100 -> "かなり多め"
        else -> "非常に多い"
    }

    fun automaticClassCounts(session: RecordingSession): Map<String, Int> = session.events
        .groupingBy { it.label.ifBlank { it.candidate } }
        .eachCount()

    fun intensityBucket(db: Float, session: RecordingSession): Int {
        val t = intensityThresholds(session)
        return when { db >= t.epic -> 3; db >= t.loud -> 2; db >= t.light -> 1; else -> 0 }
    }

    fun intensityDurations(session: RecordingSession): List<Long> {
        val totals = LongArray(4)
        if (session.samples.isEmpty()) return totals.toList()
        totals[0] = session.samples.first().offsetMs.coerceIn(0L, session.durationMs)
        session.samples.forEachIndexed { i, sample ->
            val start = sample.offsetMs.coerceIn(0L, session.durationMs)
            val end = (session.samples.getOrNull(i + 1)?.offsetMs ?: session.durationMs).coerceIn(start, session.durationMs)
            totals[intensityBucket(sample.db, session)] += end - start
        }
        return totals.toList()
    }
}
