package com.oyasumi.recorder

import android.content.Context

data class RecorderSettings(
    val autoDetect: Boolean,
    val sensitivity: Int,
    val retentionDays: Int,
    val waveformFloorDb: Float = -34f
) {
    val thresholdDb: Float
        get() = when (sensitivity) {
            0 -> -20f   // low sensitivity: only louder sounds
            2 -> -32f   // high sensitivity: quieter sounds too
            else -> -26f
        }
}

class AppSettings private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun get(): RecorderSettings = RecorderSettings(
        autoDetect = prefs.getBoolean(KEY_AUTO_DETECT, true),
        sensitivity = prefs.getInt(KEY_SENSITIVITY, 1),
        retentionDays = prefs.getInt(KEY_RETENTION_DAYS, 7),
        waveformFloorDb = prefs.getFloat("waveform_floor", -34f).coerceIn(-48f, -20f)
    )

    fun setAutoDetect(value: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_DETECT, value).apply()
    }

    fun setSensitivity(value: Int) {
        prefs.edit().putInt(KEY_SENSITIVITY, value.coerceIn(0, 2)).apply()
    }

    fun setWaveformFloor(value: Float) {
        prefs.edit().putFloat("waveform_floor", value.coerceIn(-48f, -20f)).apply()
    }

    fun setRetentionDays(value: Int) {
        prefs.edit().putInt(KEY_RETENTION_DAYS, value).apply()
    }

    companion object {
        private const val KEY_AUTO_DETECT = "auto_detect"
        private const val KEY_SENSITIVITY = "sensitivity"
        private const val KEY_RETENTION_DAYS = "retention_days"

        @Volatile private var instance: AppSettings? = null

        fun get(context: Context): AppSettings = instance ?: synchronized(this) {
            instance ?: AppSettings(context).also { instance = it }
        }
    }
}
