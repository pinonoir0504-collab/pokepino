package com.oyasumi.recorder

import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.*
import java.io.File

class SegmentAudioPlayer {
    val playingIndex: MutableState<Int?> = mutableStateOf(null)
    val isPlaying = mutableStateOf(false)
    val error = mutableStateOf<String?>(null)
    val positionMs = mutableLongStateOf(0L)
    val isPrepared = mutableStateOf(false)
    val durationMs = mutableIntStateOf(0)
    val volume = mutableFloatStateOf(0.85f)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var player: MediaPlayer? = null
    private var progressJob: Job? = null
    private var segmentStartMs = 0L
    private var segmentEndMs = 0L
    private var playToFileEnd = false
    private val intent = PlaybackIntent()
    private val seekQueue = SeekQueue()
    private var sources = emptyList<Pair<File, Long>>()
    private var partIndex = 0
    private var partOffset = 0L
    private var loadingTarget = 0L
    var onRangeFinished: ((Int) -> Unit)? = null

    private fun finishRange() {
        val index = playingIndex.value
        stop()
        if (index != null && index >= 0) onRangeFinished?.invoke(index)
    }
    fun play(file: File, event: SoundEvent, index: Int) {
        stop(); error.value = null
        runCatching {
            val parts = AudioPlaylist.read(file)
            sources = if (parts.isEmpty()) listOf(file to 0L) else parts.map { File(file.parentFile, it.fileName) to it.durationMs }
            require(sources.all { it.first.exists() && it.first.length() > 0 })
            durationMs.intValue = sources.sumOf { it.second }.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            segmentStartMs = event.startMs.coerceAtLeast(0)
            segmentEndMs = event.endMs
            playingIndex.value = index
            intent.start(); isPlaying.value = true
            loadAt(segmentStartMs)
        }.onFailure { error.value = "音声ファイルを読み込めませんでした"; stop() }
    }
    /** Switch AAC files using the same whole-recording timeline and playback intent. */
    private fun loadAt(target: Long) {
        progressJob?.cancel(); progressJob = null
        player?.let { old -> runCatching { old.release() } }
        player = null; isPrepared.value = false; seekQueue.reset()
        partOffset = 0L; partIndex = 0
        while (partIndex < sources.lastIndex && target >= partOffset + sources[partIndex].second) {
            partOffset += sources[partIndex].second; partIndex++
        }
        loadingTarget = target
        positionMs.longValue = target
        intent.beginSeek()
        val mp = MediaPlayer(); player = mp
        runCatching {
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            mp.setDataSource(sources[partIndex].first.absolutePath)
            mp.setOnPreparedListener { prepared ->
                if (player !== prepared) return@setOnPreparedListener
                runCatching {
                    if (sources.size == 1 && sources[0].second == 0L) durationMs.intValue = prepared.duration
                    val total = durationMs.intValue.toLong()
                    segmentStartMs = segmentStartMs.coerceIn(0L, total)
                    segmentEndMs = if (playToFileEnd) total else segmentEndMs.coerceIn(segmentStartMs, total)
                    if (segmentEndMs <= segmentStartMs) { stop(); return@setOnPreparedListener }
                    prepared.setVolume(volume.floatValue, volume.floatValue)
                    isPrepared.value = true
                    prepared.setOnSeekCompleteListener { seeked ->
                        if (player === seeked && seekQueue.inFlight) {
                            runCatching {
                                val next = seekQueue.complete()
                                if (next != null) seeked.seekTo(next, MediaPlayer.SEEK_CLOSEST)
                                else {
                                    val resume = intent.finishSeek()
                                    if (resume) seeked.start()
                                    isPlaying.value = resume
                                    startProgressLoop()
                                }
                            }.onFailure { error.value = "再生位置を変更できませんでした"; stop() }
                        }
                    }
                    val local = (loadingTarget - partOffset).coerceIn(0L, (prepared.duration - 1L).coerceAtLeast(0))
                    seekQueue.request(local)?.let { prepared.seekTo(it, MediaPlayer.SEEK_CLOSEST) }
                }.onFailure { error.value = "再生できませんでした"; stop() }
            }
            mp.setOnCompletionListener { if (player === it) {
                val next = partOffset + sources[partIndex].second
                if (partIndex < sources.lastIndex && next < segmentEndMs) loadAt(next) else finishRange()
            } }
            mp.setOnErrorListener { _, _, _ -> if (player === mp) { error.value = "音声を読み込めませんでした"; stop() }; true }
            mp.prepareAsync()
        }.onFailure { error.value = "再生できませんでした"; stop() }
    }
    fun togglePause() {
        val mp = player ?: return
        runCatching {
            val shouldPlay = intent.toggle(); isPlaying.value = shouldPlay
            if (isPrepared.value && !intent.seeking) {
                if (shouldPlay) mp.start() else if (mp.isPlaying) mp.pause()
            }
        }.onFailure { error.value = "再生できませんでした"; stop() }
    }
    fun seekTo(timeMs: Long) {
        val mp = player ?: return
        runCatching {
            val total = durationMs.intValue.toLong()
            if (total <= 0) return
            segmentStartMs = 0; segmentEndMs = total; playToFileEnd = true
            val target = timeMs.coerceIn(0L, total - 1)
            playingIndex.value = -1; positionMs.longValue = target
            val currentEnd = partOffset + if (sources[partIndex].second > 0) sources[partIndex].second else total
            if (!isPrepared.value || target < partOffset || target >= currentEnd) { loadAt(target); return }
            intent.beginSeek(); progressJob?.cancel()
            if (mp.isPlaying) mp.pause()
            seekQueue.request(target - partOffset)?.let { mp.seekTo(it, MediaPlayer.SEEK_CLOSEST) }
        }.onFailure { error.value = "再生位置を変更できませんでした"; stop() }
    }
    fun setVolume(value: Float) {
        val safe = value.coerceIn(0f, 1f); volume.floatValue = safe
        player?.let { runCatching { it.setVolume(safe, safe) } }
    }
    fun extendToRecordingEnd() {
        playToFileEnd = true
        if (durationMs.intValue > 0) segmentEndMs = durationMs.intValue.toLong()
    }
    private fun startProgressLoop() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                val mp = player ?: break
                val pos = runCatching { partOffset + mp.currentPosition.toLong() }.getOrDefault(positionMs.longValue)
                positionMs.longValue = pos
                isPlaying.value = runCatching { mp.isPlaying }.getOrDefault(false)
                if (pos >= segmentEndMs && segmentEndMs > segmentStartMs) { finishRange(); break }
                delay(80)
            }
        }
    }
    fun stop() {
        progressJob?.cancel(); progressJob = null
        player?.let { runCatching { it.release() } }; player = null
        playingIndex.value = null; isPlaying.value = false; isPrepared.value = false
        positionMs.longValue = 0; durationMs.intValue = 0
        segmentStartMs = 0; segmentEndMs = 0; playToFileEnd = false
        intent.reset(); seekQueue.reset(); sources = emptyList(); partOffset = 0; partIndex = 0
    }
    fun release() { stop(); scope.cancel() }
}
