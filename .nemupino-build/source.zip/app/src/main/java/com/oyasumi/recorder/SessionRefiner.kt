package com.oyasumi.recorder

import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap

/** The playable recording is committed before refinement. Pending work resumes on app launch. */
object SessionRefiner {
    const val PENDING = "解析待ち"
    const val FAILED = "解析失敗"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = ConcurrentHashMap.newKeySet<String>()
    private val decoderLock = Mutex()
    private class RecordingStarted : RuntimeException()

    fun resumePending(context: Context) {
        SessionStore.get(context).sessions.value.filter { PENDING in it.tags && !it.audioDeleted }.forEach { enqueue(context, it.id) }
    }

    fun enqueue(context: Context, id: String) {
        if (!running.add(id)) return
        val app = context.applicationContext
        scope.launch {
            try {
                decoderLock.withLock {
                    val store = SessionStore.get(app)
                    store.markAnalysisPending(id)
                    while (isActive) {
                        while (RecordingBus.state.value !is RecordingUiState.Idle) delay(1000)
                        val session = store.sessions.value.firstOrNull { it.id == id } ?: break
                        if (session.audioDeleted) break
                        val jobContext = currentCoroutineContext()
                        try {
                            val detailed = AudioEnvelope.readDetailed(store.recordingFile(session.fileName), checkContinuation = {
                                jobContext.ensureActive()
                                if (RecordingBus.state.value !is RecordingUiState.Idle) throw RecordingStarted()
                            })
                            store.finishAnalysis(id, detailed)
                            break
                        } catch (_: RecordingStarted) {
                            delay(1000)
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            store.failAnalysis(id)
                            break
                        }
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                RecordingBus.reportError("詳細波形の更新を保存できませんでした。録音音声と先に保存した記録は残っています。")
            } finally { running.remove(id) }
        }
    }
}
