package com.oyasumi.recorder

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.log10

/** Decode the saved AAC; one real PCM peak every 50 ms, without loading the audio into RAM. */
object AudioEnvelope {
    fun read(file: File): List<VolumeSample> = readDetailed(file).samples
    fun readDetailed(file: File, progress: (Float) -> Unit = {}, checkContinuation: () -> Unit = {}): EnvelopeAnalysis {
        if (file.extension == "playlist") {
            val samples = ArrayList<VolumeSample>()
            val features = ArrayList<SoundFeature>()
            var offset = 0L
            val parts = AudioPlaylist.read(file)
            parts.forEachIndexed { index, part ->
                checkContinuation()
                val data = readDetailed(File(file.parentFile, part.fileName), checkContinuation = checkContinuation)
                samples.addAll(data.samples.filter { it.offsetMs < part.durationMs }.map { it.copy(offsetMs = it.offsetMs + offset) })
                features.addAll(data.features.filter { it.offsetMs < part.durationMs }.map { it.copy(offsetMs = it.offsetMs + offset) })
                offset += part.durationMs
                progress((index + 1f) / parts.size)
            }
            return EnvelopeAnalysis(samples, features)
        }
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            extractor.setDataSource(file.absolutePath)
            val track = (0 until extractor.trackCount).first { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
            val format = extractor.getTrackFormat(track)
            extractor.selectTrack(track)
            val codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
            decoder = codec
            codec.configure(format, null, null, 0)
            codec.start()
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var inputDone = false
            var outputDone = false
            var frames = 0L
            var peak = 0
            var count = 0
            val watchdog = DecodeWatchdog()
            val result = ArrayList<VolumeSample>()
            val info = MediaCodec.BufferInfo()
            val features = ArrayList<SoundFeature>()
            var featureMeter = SoundFeatureMeter(rate)
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
            var progressAt = 0L
            while (!outputDone) {
                checkContinuation()
                if (!inputDone) {
                    val index = codec.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val buffer = codec.getInputBuffer(index)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val index = codec.dequeueOutputBuffer(info, 10_000)
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    rate = codec.outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = codec.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    featureMeter = SoundFeatureMeter(rate)
                }
                if (index >= 0) {
                    watchdog.check(info.size > 0 || info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0)
                    val buffer = codec.getOutputBuffer(index)!!
                    buffer.position(info.offset)
                    buffer.limit(info.offset + info.size)
                    buffer.order(ByteOrder.LITTLE_ENDIAN)
                    while (buffer.remaining() >= channels * 2) {
                        var value = 0
                        repeat(channels) { val sample = buffer.short.toInt(); peak = maxOf(peak, abs(sample)); value += sample }
                        featureMeter.add(value / channels)
                        frames++
                        count++
                        if (count >= rate / 20) {
                            val db = if (peak == 0) -60f else (20 * log10(peak / 32768.0)).toFloat().coerceIn(-60f, 0f)
                            check(result.size < 2_000_000) { "Recording too long" }
                            result.add(VolumeSample((frames - count) * 1000 / rate, db))
                            features.add(featureMeter.finish((frames - count) * 1000 / rate, db))
                            peak = 0
                            count = 0
                        }
                    }
                    outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    codec.releaseOutputBuffer(index, false)
                    if (durationUs > 0 && info.presentationTimeUs - progressAt >= 1_000_000) {
                        progressAt = info.presentationTimeUs
                        progress((progressAt.toDouble() / durationUs).toFloat().coerceIn(0f, 1f))
                    }
                } else watchdog.check(false)
            }
            if (count > 0) result.add(VolumeSample((frames - count) * 1000 / rate, if (peak == 0) -60f else (20 * log10(peak / 32768.0)).toFloat().coerceIn(-60f, 0f)))
            return EnvelopeAnalysis(result, features)
        } finally {
            decoder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            extractor.release()
        }
    }
}
