package com.oyasumi.recorder

/**
 * Builds the lightweight waveform committed at Stop time.
 *
 * The recorder meters every 200 ms, which is useful while recording but unnecessarily expensive
 * to remap and serialize when the user taps Stop. The full 50 ms envelope is decoded after the
 * playable recording has already been committed by SessionRefiner. Until then a one-second peak
 * envelope is enough for the overview chart and makes the synchronous save much smaller.
 */
object FastSaveEnvelope {
    fun build(
        samples: List<VolumeSample>,
        spans: List<PartSpan>,
        durationMs: Long,
        bucketMs: Long = 1_000L
    ): List<VolumeSample> {
        if (samples.isEmpty() || spans.isEmpty() || durationMs <= 0L) return emptyList()
        require(bucketMs >= 200L)

        val result = ArrayList<VolumeSample>((durationMs / bucketMs + 2).toInt().coerceAtLeast(16))
        var spanIndex = 0
        var bucket = -1L
        var peakDb = -60f
        var peakAt = 0L
        var hasPeak = false

        fun flush() {
            if (!hasPeak) return
            result += VolumeSample(peakAt.coerceIn(0L, durationMs), peakDb)
            hasPeak = false
            peakDb = -60f
        }

        for (sample in samples) {
            while (spanIndex + 1 < spans.size && sample.offsetMs >= spans[spanIndex + 1].wallStart) spanIndex++
            val span = spans[spanIndex]
            if (sample.offsetMs < span.wallStart || sample.offsetMs > span.wallEnd) continue
            val wallDuration = (span.wallEnd - span.wallStart).coerceAtLeast(1L)
            val mapped = (span.audioStart +
                ((sample.offsetMs - span.wallStart).coerceIn(0L, wallDuration).toDouble() * span.audioDuration / wallDuration).toLong())
                .coerceIn(0L, durationMs)
            val nextBucket = mapped / bucketMs
            if (nextBucket != bucket) {
                flush()
                bucket = nextBucket
            }
            if (!hasPeak || sample.db > peakDb) {
                hasPeak = true
                peakDb = sample.db
                peakAt = mapped
            }
        }
        flush()
        return result
    }
}
