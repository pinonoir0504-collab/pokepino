package com.oyasumi.recorder

data class LoudMoment(val offsetMs: Long, val peakDb: Float) {
    val playbackStartMs: Long get() = (offsetMs - 1500L).coerceAtLeast(0L)
}

/** One peak per five seconds, then suppress nearby peaks from the same sound. */
object LoudMoments {
    fun rank(session: RecordingSession, limit: Int = 20): List<LoudMoment> {
        if (limit <= 0 || session.durationMs <= 0L) return emptyList()
        val buckets = mutableMapOf<Long, LoudMoment>()
        fun add(time: Long, db: Float) {
            if (time !in 0 until session.durationMs || !db.isFinite()) return
            val bucket = time / 5000L
            val old = buckets[bucket]
            if (old == null || db > old.peakDb || (db == old.peakDb && time < old.offsetMs)) buckets[bucket] = LoudMoment(time, db)
        }
        if (session.samples.isNotEmpty()) session.samples.forEach { add(it.offsetMs, it.db) }
        else session.events.forEach { add(it.startMs, it.peakDb) }
        return suppressAndLimit(buckets.values, limit)
    }

    /**
     * Rank only events already classified as snoring. A phone bump, cough, bark or other loud
     * transient therefore cannot enter the ranking merely because it was loud.
     */
    fun rankSnores(session: RecordingSession, limit: Int = 5): List<LoudMoment> {
        if (limit <= 0 || session.durationMs <= 0L) return emptyList()
        val snores = SessionMetrics.snoreEvents(session)
        val scored = snores.mapNotNull { event ->
            val start = event.startMs.coerceAtLeast(0L)
            val end = event.endMs.coerceAtMost(session.durationMs)
            if (end <= start) return@mapNotNull null
            val local = sampleWindow(session.samples, start, end)
            val moment = sustainedPeak(local)
                ?: if (event.peakDb.isFinite()) LoudMoment(start, event.peakDb) else null
                ?: return@mapNotNull null
            val durationBonus = (event.durationMs / 1000.0).coerceIn(0.0, 5.0) * 1.2
            val intensityBonus = (SessionMetrics.snoreIntensity(event, session) - 1) * 2.0
            ScoredMoment(moment, moment.peakDb + durationBonus + intensityBonus)
        }
        val chosen = mutableListOf<ScoredMoment>()
        for (candidate in scored.sortedWith(compareByDescending<ScoredMoment> { it.score }.thenBy { it.moment.offsetMs })) {
            if (chosen.none { kotlin.math.abs(it.moment.offsetMs - candidate.moment.offsetMs) < 10_000L }) chosen += candidate
            if (chosen.size == limit) break
        }
        return chosen.map { it.moment }
    }

    private data class ScoredMoment(val moment: LoudMoment, val score: Double)

    private fun sampleWindow(samples: List<VolumeSample>, start: Long, end: Long): List<VolumeSample> {
        if (samples.isEmpty()) return emptyList()
        fun lowerBound(target: Long): Int {
            var low = 0
            var high = samples.size
            while (low < high) {
                val mid = (low + high) ushr 1
                if (samples[mid].offsetMs < target) low = mid + 1 else high = mid
            }
            return low
        }
        val from = lowerBound(start)
        var to = lowerBound(end + 1L)
        if (to < from) to = from
        return samples.subList(from, to).filter { it.db.isFinite() }
    }

    /**
     * Use a short rolling median instead of a single 50-ms maximum. A one-frame phone tap/bark
     * embedded near an otherwise real snore therefore cannot become the night's #1 moment merely
     * because its instantaneous peak was higher.
     */
    private fun sustainedPeak(samples: List<VolumeSample>): LoudMoment? {
        if (samples.isEmpty()) return null
        if (samples.size < 5) {
            val peak = samples.maxByOrNull { it.db } ?: return null
            return LoudMoment(peak.offsetMs, peak.db)
        }
        var best: LoudMoment? = null
        val half = 4
        samples.indices.forEach { index ->
            val from = (index - half).coerceAtLeast(0)
            val to = (index + half).coerceAtMost(samples.lastIndex)
            if (to - from + 1 < 5) return@forEach
            val values = (from..to).map { samples[it].db }.sorted()
            val median = values[values.size / 2]
            if (best == null || median > best!!.peakDb) best = LoudMoment(samples[index].offsetMs, median)
        }
        return best ?: samples.maxByOrNull { it.db }?.let { LoudMoment(it.offsetMs, it.db) }
    }

    private fun suppressAndLimit(values: Collection<LoudMoment>, limit: Int): List<LoudMoment> {
        val chosen = mutableListOf<LoudMoment>()
        for (peak in values.sortedWith(compareByDescending<LoudMoment> { it.peakDb }.thenBy { it.offsetMs })) {
            if (chosen.none { kotlin.math.abs(it.offsetMs - peak.offsetMs) < 10_000L }) chosen.add(peak)
            if (chosen.size == limit) break
        }
        return chosen
    }
}

object PlaybackRanges {
    fun fromTime(timeMs: Long, durationMs: Long): SoundEvent? {
        if (durationMs <= 0L) return null
        return SoundEvent(timeMs.coerceIn(0L, durationMs - 1L), durationMs, 0f)
    }
    fun fromEvent(event: SoundEvent, durationMs: Long, excerptOnly: Boolean): SoundEvent? {
        val range = fromTime(event.startMs, durationMs) ?: return null
        return range.copy(endMs = if (excerptOnly) event.endMs.coerceIn(range.startMs + 1L, durationMs) else durationMs, peakDb = event.peakDb)
    }
}
