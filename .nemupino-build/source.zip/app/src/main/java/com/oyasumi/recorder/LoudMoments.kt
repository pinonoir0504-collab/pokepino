package com.oyasumi.recorder

data class LoudMoment(val offsetMs: Long, val peakDb: Float) {
    val playbackStartMs: Long get() = (offsetMs - 1500L).coerceAtLeast(0L)
}

/** One peak per five seconds, then suppress nearby peaks from the same sound. */
object LoudMoments {
    fun rank(session: RecordingSession, limit: Int = 20): List<LoudMoment> {
        if (limit <= 0 || session.durationMs <= 0L) return emptyList()
        val buckets = mutableMapOf<Long, LoudMoment>()
        fun add(time: Long, db: Float) {
            if (time !in 0 until session.durationMs || !db.isFinite()) return
            val bucket = time / 5000L
            val old = buckets[bucket]
            if (old == null || db > old.peakDb || (db == old.peakDb && time < old.offsetMs)) buckets[bucket] = LoudMoment(time, db)
        }
        if (session.samples.isNotEmpty()) session.samples.forEach { add(it.offsetMs, it.db) }
        else session.events.forEach { add(it.startMs, it.peakDb) }
        return suppressAndLimit(buckets.values, limit)
    }

    /**
     * Rank only events already classified as snoring. A phone bump, cough, bark or other loud
     * transient therefore cannot enter the ranking merely because it was loud.
     */
    fun rankSnores(session: RecordingSession, limit: Int = 5): List<LoudMoment> {
        if (limit <= 0 || session.durationMs <= 0L) return emptyList()
        val snores = SessionMetrics.snoreEvents(session)
        val moments = snores.mapNotNull { event ->
            val start = event.startMs.coerceAtLeast(0L)
            val end = event.endMs.coerceAtMost(session.durationMs)
            val localPeak = session.samples.asSequence()
                .filter { it.offsetMs in start..end && it.db.isFinite() }
                .maxByOrNull { it.db }
            if (localPeak != null) LoudMoment(localPeak.offsetMs, localPeak.db)
            else if (event.peakDb.isFinite()) LoudMoment(start, event.peakDb)
            else null
        }
        return suppressAndLimit(moments, limit)
    }

    private fun suppressAndLimit(values: Collection<LoudMoment>, limit: Int): List<LoudMoment> {
        val chosen = mutableListOf<LoudMoment>()
        for (peak in values.sortedWith(compareByDescending<LoudMoment> { it.peakDb }.thenBy { it.offsetMs })) {
            if (chosen.none { kotlin.math.abs(it.offsetMs - peak.offsetMs) < 10_000L }) chosen.add(peak)
            if (chosen.size == limit) break
        }
        return chosen
    }
}

object PlaybackRanges {
    fun fromTime(timeMs: Long, durationMs: Long): SoundEvent? {
        if (durationMs <= 0L) return null
        return SoundEvent(timeMs.coerceIn(0L, durationMs - 1L), durationMs, 0f)
    }
    fun fromEvent(event: SoundEvent, durationMs: Long, excerptOnly: Boolean): SoundEvent? {
        val range = fromTime(event.startMs, durationMs) ?: return null
        return range.copy(endMs = if (excerptOnly) event.endMs.coerceIn(range.startMs + 1L, durationMs) else durationMs, peakDb = event.peakDb)
    }
}
