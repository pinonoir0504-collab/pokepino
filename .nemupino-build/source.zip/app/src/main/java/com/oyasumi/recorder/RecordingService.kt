package com.oyasumi.recorder

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Executors
import java.io.File
import java.util.UUID
import kotlin.math.log10

class RecordingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val recorderDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private var recorder: MediaRecorder? = null
    private var meterJob: Job? = null
    private var waitingJob: Job? = null
    private var waiting = false
    private var foreground = false
    private val startTimer = DelayedRecordingStart()
    private var wakeLock: PowerManager.WakeLock? = null
    private var startedAt: Long = 0L
    private var startedElapsed: Long = 0L
    private var sessionId: String = ""
    private var fileName: String = ""
    private var active = false
    private var saving = false

    private val events = mutableListOf<SoundEvent>()
    private val samples = mutableListOf<VolumeSample>()
    private var detector: SoundEventDetector? = null
    private var autoDetect = true
    private var thresholdDb = -26f
    private val completedParts = mutableListOf<File>()
    private val checkpointIds = mutableListOf<String>()
    private var partStartMs = 0L
    private var partIndex = 0
    private var partIntervalMs = 600_000L
    private var lastCheckpointEndMs = 0L
    private val partSpans = mutableListOf<PartSpan>()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (saving) return START_NOT_STICKY
        when (intent?.action) {
            ACTION_STOP -> if (waiting) cancelWaiting() else stopRecordingAndSave()
            ACTION_DELAYED_START -> if (!active && !waiting) scheduleRecording(intent?.getLongExtra(EXTRA_DELAY_MS, THIRTY_MINUTES_MS) ?: THIRTY_MINUTES_MS)
            ACTION_START -> if (!active) {
                partIntervalMs = if (BuildConfig.DEBUG) intent.getLongExtra("test_part_ms", 600_000L).coerceIn(3000L, 600_000L) else 600_000L
                waitingJob?.cancel()
                waitingJob = null
                startTimer.cancel()
                waiting = false
                startRecording()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun scheduleRecording(delayMs: Long) {
        RecordingBus.reportError(null)
        try {
            waiting = true
            startTimer.arm(SystemClock.elapsedRealtime(), delayMs.coerceIn(0L, THIRTY_MINUTES_MS))
            startAsForeground()
            acquireWakeLock()
            waitingJob = scope.launch {
                var lastMinute = -1L
                while (isActive && waiting) {
                    val now = SystemClock.elapsedRealtime()
                    if (startTimer.consumeIfDue(now)) {
                        waiting = false
                        waitingJob = null
                        startRecording()
                        break
                    }
                    val remaining = startTimer.remainingMs(now) ?: break
                    RecordingBus.update(RecordingUiState.Waiting(remaining))
                    val minute = (remaining + 59_999L) / 60_000L
                    if (minute != lastMinute) {
                        lastMinute = minute
                        updateNotification(0L)
                    }
                    delay(1_000L)
                }
            }
        } catch (_: Exception) {
            RecordingBus.reportError("録音予約を開始できませんでした。マイクの許可を確認してください。")
            cancelWaiting()
        }
    }

    private fun cancelWaiting() {
        waiting = false
        waitingJob?.cancel()
        waitingJob = null
        startTimer.cancel()
        releaseWakeLock()
        RecordingBus.update(RecordingUiState.Idle)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        foreground = false
        stopSelf()
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            RecordingBus.update(RecordingUiState.Idle)
            stopSelf()
            return
        }

        RecordingBus.reportError(null)
        events.clear()
        samples.clear()

        val settings = AppSettings.get(this).get()
        autoDetect = settings.autoDetect
        thresholdDb = settings.thresholdDb
        detector = if (autoDetect) SoundEventDetector(settings.thresholdDb) else null

        partSpans.clear()
        completedParts.clear()
        checkpointIds.clear()
        partStartMs = 0L
        partIndex = 0
        lastCheckpointEndMs = 0L
        sessionId = UUID.randomUUID().toString()
        fileName = "$sessionId.m4a"
        val output = SessionStore.get(this).recordingFile(fileName)
        output.parentFile?.mkdirs()

        try {
            if (!foreground) startAsForeground() else updateNotification(0L)
            acquireWakeLock()
            startPart(output)
            startedAt = System.currentTimeMillis()
            startedElapsed = SystemClock.elapsedRealtime()
            active = true
            RecordingBus.update(RecordingUiState.Active(startedAt, 0L, -60f))
            beginMetering()
        } catch (_: Exception) {
            RecordingBus.reportError("録音を開始できませんでした。マイクの使用状況と空き容量を確認してください。")
            runCatching { recorder?.release() }
            recorder = null
            output.delete()
            active = false
            releaseWakeLock()
            RecordingBus.update(RecordingUiState.Idle)
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun startPart(output: File) {
        @Suppress("DEPRECATION")
        val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(this) else MediaRecorder()
        recorder = mr
        mr.setOnErrorListener { _, _, _ ->
            scope.launch { if (active && recorder === mr) { RecordingBus.reportError("録音が中断されました。途中保存した記録を確認してください。"); stopRecordingAndSave() } }
        }
        mr.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioChannels(1)
            setAudioSamplingRate(16_000)
            setAudioEncodingBitRate(24_000)
            setOutputFile(output.absolutePath)
            prepare(); start()
        }
    }

    private fun closePart(elapsed: Long, persistCheckpoint: Boolean = true): Boolean {
        val mr = recorder ?: return false
        val clean = runCatching { mr.stop() }.isSuccess
        runCatching { mr.release() }
        recorder = null
        val file = SessionStore.get(this).recordingFile(fileName)
        if (!clean || file.length() <= 0) { file.delete(); return false }
        val metadata = android.media.MediaMetadataRetriever()
        val audioDuration = try { metadata.setDataSource(file.absolutePath); metadata.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: (elapsed - partStartMs) } finally { runCatching { metadata.release() } }
        val audioStart = partSpans.lastOrNull()?.let { it.audioStart + it.audioDuration } ?: 0L
        partSpans.add(PartSpan(partStartMs, elapsed, audioStart, audioDuration))
        completedParts.add(file)
        if (persistCheckpoint) {
            val id = "$sessionId-part-$partIndex"
            val checkpoint = RecordingSession(
                id, startedAt + partStartMs, startedAt + elapsed, file.name,
                events.map { it.copy(startMs = (it.startMs - partStartMs).coerceAtLeast(0), endMs = (it.endMs.coerceAtMost(elapsed) - partStartMs).coerceAtLeast(0)) }.filter { it.durationMs > 0 },
                samples.filter { it.offsetMs >= partStartMs }.map { it.copy(offsetMs = it.offsetMs - partStartMs) },
                note = "途中保存（通常終了すると一晩の記録にまとめます）", tags = listOf("途中保存"), thresholdDb = thresholdDb
            )
            // Periodic checkpoints remain durable. Final Stop skips this extra history write and
            // commits the complete session once; an unindexed final m4a is still recoverable as an orphan.
            SessionStore.get(this).save(checkpoint)
            checkpointIds.add(id)
        }
        lastCheckpointEndMs = elapsed
        return true
    }

    private fun rotatePart(elapsed: Long) {
        try {
            check(closePart(elapsed))
            partIndex++
            fileName = "$sessionId-part-$partIndex.m4a"
            startPart(SessionStore.get(this).recordingFile(fileName))
            // Prepare/start can take seconds under load. Count this part only once capture has started.
            partStartMs = (SystemClock.elapsedRealtime() - startedElapsed).coerceAtLeast(elapsed)
        } catch (_: Exception) {
            RecordingBus.reportError("録音を継続できませんでした。保存済みの区間は履歴に残っています。")
            stopRecordingAndSave()
        }
    }

    private fun beginMetering() {
        meterJob?.cancel()
        meterJob = scope.launch(recorderDispatcher) {
            var lastSampleAt = -SAMPLE_INTERVAL_MS
            var samplePeakDb = -60f
            var lastNotificationMinute = -1L

            while (isActive && active) {
                val elapsed = (SystemClock.elapsedRealtime() - startedElapsed).coerceAtLeast(0L)
                val amplitude = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)
                val db = amplitudeToDb(amplitude)
                samplePeakDb = maxOf(samplePeakDb, db)

                detector?.onSample(elapsed, db)?.let(::appendEvent)

                if (elapsed - lastSampleAt >= SAMPLE_INTERVAL_MS) {
                    samples += VolumeSample(elapsed, samplePeakDb)
                    lastSampleAt = elapsed
                    samplePeakDb = -60f
                }

                RecordingBus.update(RecordingUiState.Active(startedAt, elapsed, db))

                val minute = elapsed / 60_000L
                if (minute != lastNotificationMinute) {
                    lastNotificationMinute = minute
                    updateNotification(elapsed)
                }
                if (elapsed - partStartMs >= partIntervalMs) rotatePart(elapsed)
                delay(SAMPLE_INTERVAL_MS)
            }
        }
    }

    private fun appendEvent(newEvent: SoundEvent) {
        val last = events.lastOrNull()
        if (last != null && newEvent.startMs <= last.endMs) {
            events[events.lastIndex] = SoundEvent(
                startMs = last.startMs,
                endMs = maxOf(last.endMs, newEvent.endMs),
                peakDb = maxOf(last.peakDb, newEvent.peakDb)
            )
        } else {
            events += newEvent
        }
    }

    private fun stopRecordingAndSave(saveSynchronously: Boolean = false) {
        if (!active) { if (!saving) stopSelf(); return }
        active = false
        val previousMeter = meterJob
        previousMeter?.cancel()
        meterJob = null
        val elapsed = (SystemClock.elapsedRealtime() - startedElapsed).coerceAtLeast(0L)
        if (saveSynchronously) {
            runBlocking(recorderDispatcher) {
                previousMeter?.join()
                detector?.finish(elapsed)?.let(::appendEvent)
                runCatching { closePart(elapsed) }
            }
            return
        }
        saving = true
        RecordingBus.update(RecordingUiState.Saving("音声を保存しています", 0.05f))
        scope.launch(recorderDispatcher) {
            previousMeter?.join()
            detector?.finish(elapsed)?.let(::appendEvent)
            val result = runCatching {
                val closed = runCatching { closePart(elapsed, persistCheckpoint = false) }.getOrDefault(false)
                check(closed || completedParts.isNotEmpty()) { "No playable recording" }
                val parts = completedParts.toList()
                val audioParts = parts.zip(partSpans).map { (file, span) -> AudioPart(file.name, span.audioDuration) }
                val duration = audioParts.sumOf { it.durationMs }
                val finalFile = if (parts.size == 1) parts.first() else
                    SessionStore.get(this@RecordingService).recordingFile("$sessionId.playlist").also { AudioPlaylist.write(it, audioParts) }
                val spans = partSpans.toList()
                val validEvents = events.map { it.copy(
                    startMs = PartTimeline.audioTime(it.startMs, spans).coerceAtMost(duration),
                    endMs = PartTimeline.audioTime(it.endMs, spans).coerceAtMost(duration)) }.filter { it.durationMs >= 250L }
                RecordingBus.update(RecordingUiState.Saving("記録をまとめています", 0.72f))
                val coarse = FastSaveEnvelope.build(samples, spans, duration)
                val session = RecordingSession(sessionId, startedAt, startedAt + duration, finalFile.name,
                    validEvents, coarse, tags = listOf(SessionRefiner.PENDING), thresholdDb = thresholdDb, audioParts = audioParts)
                RecordingBus.update(RecordingUiState.Saving("履歴を保存しています", 0.9f))
                SessionStore.get(this@RecordingService).finalizeRecording(session, checkpointIds.toList())
                session
            }
            withContext(Dispatchers.Main) {
                result.onSuccess { RecordingBus.completed(it.id) }
                    .onFailure { RecordingBus.reportError("保存に失敗しました。途中保存した音声は履歴に残っています。") }
                saving = false
                releaseWakeLock()
                finishService()
                result.getOrNull()?.let { SessionRefiner.enqueue(applicationContext, it.id) }
            }
        }
    }

    private fun finishService() {
        RecordingBus.update(RecordingUiState.Idle)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        foreground = false
        stopSelf()
    }

    private fun amplitudeToDb(amplitude: Int): Float {
        if (amplitude <= 0) return -60f
        val normalized = amplitude.toDouble() / 32767.0
        return (20.0 * log10(normalized)).toFloat().coerceIn(-60f, 0f)
    }

    private fun startAsForeground() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else 0
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(0L),
            type
        )
        foreground = true
    }

    private fun updateNotification(elapsed: Long) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(elapsed))
    }

    private fun buildNotification(elapsed: Long): Notification {
        val stopIntent = Intent(this, RecordingService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java)
        val openPendingIntent = PendingIntent.getActivity(
            this,
            2,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val elapsedText = if (waiting) "録音開始まで ${formatDuration(startTimer.remainingMs(SystemClock.elapsedRealtime()) ?: 0L)}" else if (elapsed <= 0L) "録音を開始しています" else "録音中 ${formatDuration(elapsed)}"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ねむピーノ")
            .setContentText(elapsedText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_media_pause, if (waiting) "予約をキャンセル" else "録音を終了", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.recording_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.recording_channel_description)
                setSound(null, null)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:SleepRecording").apply {
            setReferenceCounted(false)
            acquire(16L * 60L * 60L * 1000L)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) runCatching { it.release() } }
        wakeLock = null
    }

    override fun onDestroy() {
        waiting = false
        waitingJob?.cancel()
        startTimer.cancel()
        if (active) {
            stopRecordingAndSave(saveSynchronously = true)
        }
        releaseWakeLock()
        scope.cancel()
        recorderDispatcher.close()
        RecordingBus.update(RecordingUiState.Idle)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.oyasumi.recorder.START"
        const val ACTION_DELAYED_START = "com.oyasumi.recorder.DELAYED_START"
        private const val EXTRA_DELAY_MS = "delay_ms"
        const val THIRTY_MINUTES_MS = 30L * 60L * 1000L
        const val ACTION_STOP = "com.oyasumi.recorder.STOP"
        private const val CHANNEL_ID = "sleep_recording"
        private const val NOTIFICATION_ID = 1001
        private const val SAMPLE_INTERVAL_MS = 200L

        fun start(context: Context, delayMs: Long = 0L) {
            val intent = Intent(context, RecordingService::class.java).apply {
                action = if (delayMs > 0L) ACTION_DELAYED_START else ACTION_START
                putExtra(EXTRA_DELAY_MS, delayMs)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, RecordingService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }
}
