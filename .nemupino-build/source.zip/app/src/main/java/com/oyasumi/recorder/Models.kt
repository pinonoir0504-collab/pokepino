package com.oyasumi.recorder

data class SoundEvent(
    val startMs: Long,
    val endMs: Long,
    val peakDb: Float,
    val candidate: String = "不明",
    val label: String = ""
) {
    val durationMs: Long get() = (endMs - startMs).coerceAtLeast(0L)
}

data class VolumeSample(
    val offsetMs: Long,
    val db: Float
)

data class RecordingSession(
    val id: String,
    val startedAt: Long,
    val endedAt: Long,
    val fileName: String,
    val events: List<SoundEvent>,
    val samples: List<VolumeSample>,
    val note: String = "",
    val tags: List<String> = emptyList(),
    val thresholdDb: Float = -26f,
    val audioParts: List<AudioPart> = emptyList(),
    val audioDeleted: Boolean = false,
    val storedSnoreDurationMs: Long? = null,
    val storedSnoreScore: Int? = null
) {
    val durationMs: Long get() = (endedAt - startedAt).coerceAtLeast(0L)
}

sealed interface RecordingUiState {
    data object Idle : RecordingUiState
    data class Saving(val message: String = "録音を保存しています", val progress: Float = 0f) : RecordingUiState
    data class Waiting(val remainingMs: Long) : RecordingUiState
    data class Active(
        val startedAt: Long,
        val elapsedMs: Long,
        val db: Float
    ) : RecordingUiState
}
