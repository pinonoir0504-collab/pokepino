package com.oyasumi.recorder

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt

class SessionStore private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("sessions", Context.MODE_PRIVATE)
    private val recordingsDir = File(context.filesDir, "recordings").apply { mkdirs() }

    private val sampleCache = mutableMapOf<String, Pair<List<VolumeSample>, String>>()
    private val _sessions = MutableStateFlow(loadSessions())
    val sessions = _sessions.asStateFlow()

    fun recordingFile(fileName: String): File = File(recordingsDir, fileName)

    @Synchronized
    fun save(session: RecordingSession) {
        val current = _sessions.value.toMutableList()
        val packed = session.copy(samples = PackedVolumeSamples.pack(session.samples))
        val existing = current.indexOfFirst { it.id == session.id }
        if (existing >= 0) current[existing] = packed else current.add(packed)
        current.sortByDescending { it.startedAt }
        persist(current)
        _sessions.value = current
        cleanupExpired()
    }

    /** Commit the final recording and remove its checkpoints in one durable write. */
    @Synchronized
    fun finalizeRecording(session: RecordingSession, checkpointIds: List<String>) {
        val removed = _sessions.value.filter { it.id in checkpointIds && it.id != session.id }
        val current = _sessions.value.filterNot { it.id in checkpointIds || it.id == session.id }.toMutableList()
        current.add(session.copy(samples = PackedVolumeSamples.pack(session.samples)))
        current.sortByDescending { it.startedAt }
        persist(current)
        _sessions.value = current
        // A failed commit leaves every checkpoint intact. Files are removed only afterwards.
        val retained = session.ownedFileNames()
        removed.flatMap { it.ownedFileNames() }.distinct().filterNot { it in retained }.forEach { recordingFile(it).delete() }
        cleanupExpired()
    }

    @Synchronized
    fun markAnalysisPending(id: String) {
        val session = _sessions.value.firstOrNull { it.id == id } ?: return
        if (SessionRefiner.PENDING !in session.tags) save(session.copy(tags = session.tags.filterNot { it == SessionRefiner.FAILED } + SessionRefiner.PENDING))
    }

    @Synchronized
    fun finishAnalysis(id: String, analysis: EnvelopeAnalysis) {
        val latest = _sessions.value.firstOrNull { it.id == id } ?: return
        // Use the current events, notes and tags; manual reviews made during decoding survive.
        save(latest.copy(samples = analysis.samples.filter { it.offsetMs <= latest.durationMs },
            events = SoundCandidates.classify(latest.events, analysis.features),
            tags = latest.tags.filterNot { it == SessionRefiner.PENDING || it == SessionRefiner.FAILED }))
    }

    @Synchronized
    fun failAnalysis(id: String) {
        val latest = _sessions.value.firstOrNull { it.id == id } ?: return
        save(latest.copy(tags = latest.tags.filterNot { it == SessionRefiner.PENDING || it == SessionRefiner.FAILED } + SessionRefiner.FAILED))
    }

    @Synchronized
    fun delete(sessionId: String) {
        val session = _sessions.value.firstOrNull { it.id == sessionId } ?: return
        val updated = _sessions.value.filterNot { it.id == sessionId }
        persist(updated)
        _sessions.value = updated
        session.ownedFileNames().forEach { recordingFile(it).delete() }
    }

    @Synchronized
    fun cleanupExpired() {
        val days = AppSettings.get(context).get().retentionDays
        if (days <= 0) return
        val cutoff = System.currentTimeMillis() - days * 24L * 60L * 60L * 1000L
        val expired = _sessions.value.filter { it.endedAt < cutoff }
        if (expired.isNotEmpty()) {
            val keep = _sessions.value - expired.toSet()
            persist(keep)
            _sessions.value = keep
            expired.flatMap { it.ownedFileNames() }.distinct().forEach { recordingFile(it).delete() }
        }
    }

    @Synchronized
    fun updateReview(id: String, note: String, tags: List<String>) {
        val session = _sessions.value.firstOrNull { it.id == id } ?: return
        save(session.copy(note = note.take(2000), tags = (tags.filterNot { it == SessionRefiner.PENDING || it == SessionRefiner.FAILED }.distinct().take(20) + session.tags.filter { it == SessionRefiner.PENDING || it == SessionRefiner.FAILED })))
    }

    @Synchronized
    fun recoverOrphans() {
        if (RecordingBus.state.value !is RecordingUiState.Idle) return
        val known = _sessions.value.flatMap { it.ownedFileNames() }.toSet()
        recordingsDir.listFiles()?.filter { it.extension == "m4a" && it.name !in known && it.length() > 0 }?.forEach { file ->
            val reader = android.media.MediaMetadataRetriever()
            runCatching {
                reader.setDataSource(file.absolutePath)
                val duration = reader.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0
                if (duration > 0) save(RecordingSession("recovered-${file.nameWithoutExtension}", file.lastModified() - duration, file.lastModified(), file.name, emptyList(), emptyList(), note = "中断後に復旧した録音です", tags = listOf("復旧")))
            }
            runCatching { reader.release() }
        }
    }

    @Synchronized
    fun labelEvent(id: String, index: Int, label: String, expectedEvent: SoundEvent? = null) {
        require(label in listOf("", "いびき", "寝言", "寝返り", "環境音"))
        val session = _sessions.value.firstOrNull { it.id == id } ?: return
        val targetIndex = if (expectedEvent == null) index else
            PlaybackNavigator.matchingEventIndex(session.events, expectedEvent) ?: error("音の区間が更新されました")
        if (targetIndex !in session.events.indices) return
        save(session.copy(events = session.events.mapIndexed { i, event -> if (i == targetIndex) event.copy(label = label) else event }))
    }

    private fun RecordingSession.ownedFileNames(): Set<String> = (audioParts.map { it.fileName } + fileName).toSet()

    private fun persist(items: List<RecordingSession>) {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        check(prefs.edit().putString(KEY_SESSIONS, arr.toString()).commit()) { "履歴の保存に失敗しました" }
        val ids = items.map { it.id }.toSet()
        sampleCache.keys.retainAll(ids)
    }

    private fun loadSessions(): List<RecordingSession> {
        val raw = prefs.getString(KEY_SESSIONS, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    runCatching { arr.getJSONObject(i).toSession() }.getOrNull()?.let { add(it) }
                }
            }.sortedByDescending { it.startedAt }
        }.getOrElse { emptyList() }
    }

    /**
     * v2 stores the overnight amplitude envelope as a compact Base64 byte string.
     * Each byte represents 0.5 dB steps from -60 dBFS to 0 dBFS. This keeps
     * long recordings small while preserving enough detail for the UI waveform.
     */
    private fun RecordingSession.toJson(): JSONObject = JSONObject().apply {
        put("v", 3)
        put("id", id)
        put("startedAt", startedAt)
        put("endedAt", endedAt)
        put("fileName", fileName)
        put("audioParts", JSONArray().apply { audioParts.forEach { put(JSONObject().put("file", it.fileName).put("duration", it.durationMs)) } })
        put("events", JSONArray().apply {
            events.forEach { e ->
                put(JSONArray().apply {
                    put(e.startMs)
                    put(e.endMs)
                    put(e.peakDb.toDouble())
                    put(e.candidate)
                    put(e.label)
                })
            }
        })

        put("note", note)
        put("tags", JSONArray(tags))
        put("thresholdDb", thresholdDb.toDouble())
        if (samples.isNotEmpty()) {
            val cached = sampleCache[id]
            val encoded = if (cached?.first === samples) cached.second else SampleCodec.encode(samples).also { sampleCache[id] = samples to it }
            put("samplesPackedB64", encoded)
        }
    }

    private fun JSONObject.toSession(): RecordingSession {
        val eventArray = optJSONArray("events") ?: JSONArray()
        val events = buildList {
            for (i in 0 until eventArray.length()) {
                val entry = eventArray.get(i)
                if (entry is JSONArray) {
                    add(SoundEvent(entry.getLong(0), entry.getLong(1), entry.getDouble(2).toFloat(), entry.optString(3, "不明"), entry.optString(4, "")))
                } else if (entry is JSONObject) {
                    // v1 compatibility
                    add(SoundEvent(entry.getLong("startMs"), entry.getLong("endMs"), entry.getDouble("peakDb").toFloat()))
                }
            }
        }

        val samples = when {
            has("samplesPackedB64") -> SampleCodec.decode(optString("samplesPackedB64"))
            has("sampleDbB64") -> decodeCompactSamples()
            else -> decodeLegacySamples()
        }

        if (has("samplesPackedB64")) sampleCache[getString("id")] = samples to optString("samplesPackedB64")
        return RecordingSession(
            id = getString("id"),
            startedAt = getLong("startedAt"),
            endedAt = getLong("endedAt"),
            fileName = getString("fileName"),
            events = events,
            samples = samples,
            note = optString("note", ""),
            tags = optJSONArray("tags")?.let { array -> (0 until array.length()).map { array.optString(it) } } ?: emptyList(),
            thresholdDb = optDouble("thresholdDb", -26.0).toFloat(),
            audioParts = optJSONArray("audioParts")?.let { a -> (0 until a.length()).map { val p = a.getJSONObject(it); AudioPart(p.getString("file"), p.getLong("duration")) } } ?: emptyList()
        )
    }

    private fun JSONObject.decodeCompactSamples(): List<VolumeSample> {
        val start = optLong("sampleStartMs", 0L)
        val period = optLong("samplePeriodMs", 200L).coerceAtLeast(100L)
        val raw = runCatching { Base64.decode(getString("sampleDbB64"), Base64.DEFAULT) }.getOrNull()
            ?: return emptyList()
        return raw.mapIndexed { index, byte ->
            val unsigned = byte.toInt() and 0xFF
            VolumeSample(
                offsetMs = start + index * period,
                db = (unsigned / 2f - 60f).coerceIn(-60f, 0f)
            )
        }
    }

    private fun JSONObject.decodeLegacySamples(): List<VolumeSample> {
        val sampleArray = optJSONArray("samples") ?: JSONArray()
        return buildList {
            for (i in 0 until sampleArray.length()) {
                val s = sampleArray.optJSONArray(i) ?: continue
                add(VolumeSample(s.getLong(0), s.getDouble(1).toFloat()))
            }
        }
    }

    companion object {
        private const val KEY_SESSIONS = "session_json"
        @Volatile private var instance: SessionStore? = null

        fun get(context: Context): SessionStore = instance ?: synchronized(this) {
            instance ?: SessionStore(context.applicationContext).also { instance = it }
        }
    }
}
