package com.oyasumi.recorder

import kotlin.math.pow

/** Display-only soft noise floor; preserves quiet variations without changing recorded audio. */
object WaveformScale {
    fun height(db: Float, floorDb: Float = -34f): Float {
        if (!db.isFinite()) return 0f
        val floor = floorDb.coerceIn(-48f, -20f)
        if (db <= floor) {
            val quiet = ((db + 60f) / (floor + 60f)).coerceIn(0f, 1f)
            return 0.004f + 0.026f * quiet.pow(2f)
        }
        return 0.03f + 0.97f * ((db - floor) / (-12f - floor)).coerceIn(0f, 1f).pow(1.6f)
    }
}
