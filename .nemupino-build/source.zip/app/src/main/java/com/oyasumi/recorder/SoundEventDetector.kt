package com.oyasumi.recorder

class SoundEventDetector(
    private val thresholdDb: Float,
    private val closeAfterMs: Long = 1_500L,
    private val preRollMs: Long = 2_000L,
    private val postRollMs: Long = 2_500L
) {
    private var firstLoudMs: Long? = null
    private var lastLoudMs: Long? = null
    private var peakDb: Float = -60f

    fun onSample(offsetMs: Long, db: Float): SoundEvent? {
        if (db >= thresholdDb) {
            if (firstLoudMs == null) firstLoudMs = offsetMs
            lastLoudMs = offsetMs
            if (db > peakDb) peakDb = db
            return null
        }

        val last = lastLoudMs ?: return null
        if (offsetMs - last < closeAfterMs) return null
        return closeEvent(last)
    }

    fun finish(finalOffsetMs: Long): SoundEvent? {
        val last = lastLoudMs ?: return null
        return closeEvent(last.coerceAtMost(finalOffsetMs))
    }

    private fun closeEvent(last: Long): SoundEvent {
        val first = firstLoudMs ?: last
        val result = SoundEvent(
            startMs = (first - preRollMs).coerceAtLeast(0L),
            endMs = last + postRollMs,
            peakDb = peakDb
        )
        firstLoudMs = null
        lastLoudMs = null
        peakDb = -60f
        return result
    }
}
