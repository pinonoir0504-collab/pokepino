package com.oyasumi.recorder

/** Maps metering timestamps across small recorder restart gaps to joined audio timestamps. */
data class PartSpan(val wallStart: Long, val wallEnd: Long, val audioStart: Long, val audioDuration: Long)
object PartTimeline {
    fun audioTime(time: Long, spans: List<PartSpan>): Long {
        val span = spans.lastOrNull { it.wallStart <= time } ?: spans.firstOrNull() ?: return time
        val wallDuration = (span.wallEnd - span.wallStart).coerceAtLeast(1)
        return span.audioStart + ((time - span.wallStart).coerceIn(0, wallDuration).toDouble() * span.audioDuration / wallDuration).toLong()
    }
}
