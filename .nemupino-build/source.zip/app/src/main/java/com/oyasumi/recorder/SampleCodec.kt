package com.oyasumi.recorder

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.Base64
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.math.roundToInt

/** Preserves actual timestamps even when Android delays a meter callback. */
object SampleCodec {
    fun encode(samples: List<VolumeSample>): String {
        val bytes = ByteArrayOutputStream()
        DataOutputStream(GZIPOutputStream(bytes)).use { out ->
            out.writeInt(samples.size)
            samples.forEach {
                out.writeLong(it.offsetMs)
                out.writeByte(((it.db.coerceIn(-60f, 0f) + 60f) * 2f).roundToInt())
            }
        }
        return Base64.getEncoder().encodeToString(bytes.toByteArray())
    }
    fun decode(encoded: String): List<VolumeSample> = runCatching {
        DataInputStream(GZIPInputStream(ByteArrayInputStream(Base64.getDecoder().decode(encoded)))).use { input ->
            val count = input.readInt()
            require(count in 0..2_000_000)
            var last = -1L
            val offsets = LongArray(count)
            val levels = ByteArray(count)
            repeat(count) { index ->
                val offset = input.readLong()
                require(offset >= 0 && offset >= last)
                last = offset
                offsets[index] = offset
                levels[index] = input.readUnsignedByte().coerceIn(0, 120).toByte()
            }
            val samples = PackedVolumeSamples(offsets, levels)
            require(input.read() == -1)
            samples
        }
    }.getOrDefault(emptyList())
}

/** Keeps a week of 50 ms waveforms in primitive arrays rather than millions of objects. */
class PackedVolumeSamples(private val offsets: LongArray, private val levels: ByteArray) : AbstractList<VolumeSample>() {
    override val size: Int get() = offsets.size
    override fun get(index: Int): VolumeSample = VolumeSample(offsets[index], (levels[index].toInt() and 0xff) / 2f - 60f)
    companion object {
        fun pack(samples: List<VolumeSample>): List<VolumeSample> {
            if (samples is PackedVolumeSamples) return samples
            val offsets = LongArray(samples.size)
            val levels = ByteArray(samples.size)
            samples.forEachIndexed { index, sample ->
                offsets[index] = sample.offsetMs
                levels[index] = ((sample.db.coerceIn(-60f, 0f) + 60f) * 2f).roundToInt().toByte()
            }
            return PackedVolumeSamples(offsets, levels)
        }
    }
}
