package com.oyasumi.recorder

/** MediaPlayer seeks are asynchronous: serialize them and keep the latest queued target. */
class SeekQueue {
    var inFlight = false
        private set
    private var pending: Long? = null
    fun request(target: Long): Long? {
        if (inFlight) { pending = target; return null }
        inFlight = true
        return target
    }
    fun complete(): Long? {
        val next = pending
        pending = null
        if (next == null) inFlight = false
        return next
    }
    fun reset() { inFlight = false; pending = null }
}
