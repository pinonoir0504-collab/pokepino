package com.oyasumi.recorder

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

/** Concatenates completed AAC parts without re-encoding or loading a night into memory. */
object AudioJoiner {
    fun join(parts: List<File>, output: File, progress: (Float) -> Unit): Long {
        require(parts.isNotEmpty())
        val temporary = File(output.parentFile, output.name + ".pending")
        val muxer = MediaMuxer(temporary.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var started = false
        var baseUs = 0L
        var expectedRate = 0
        var expectedChannels = 0
        var track = -1
        try {
            val buffer = ByteBuffer.allocateDirect(1024 * 1024)
            val info = MediaCodec.BufferInfo()
            parts.forEachIndexed { index, file ->
                val extractor = MediaExtractor()
                try {
                    extractor.setDataSource(file.absolutePath)
                    val source = (0 until extractor.trackCount).first { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                    val format = extractor.getTrackFormat(source)
                    val rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (!started) {
                        expectedRate = rate; expectedChannels = channels
                        track = muxer.addTrack(format); muxer.start(); started = true
                    }
                    require(rate == expectedRate && channels == expectedChannels)
                    extractor.selectTrack(source)
                    var first = -1L
                    var last = -1L
                    var step = 1024L * 1_000_000 / rate
                    var previous = -1L
                    while (true) {
                        buffer.clear()
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) break
                        val sourceTime = extractor.sampleTime
                        if (first < 0) first = sourceTime
                        if (previous >= 0 && sourceTime > previous) step = sourceTime - previous
                        val time = baseUs + sourceTime - first
                        info.set(0, size, time, 0)
                        buffer.position(0); buffer.limit(size)
                        muxer.writeSampleData(track, buffer, info)
                        last = time; previous = sourceTime
                        extractor.advance()
                    }
                    require(last >= 0) { "Empty audio part" }
                    baseUs = last + step
                    progress((index + 1f) / parts.size)
                } finally { extractor.release() }
            }
            muxer.stop(); started = false
            check(temporary.renameTo(output)) { "Could not finalize audio" }
            return baseUs / 1000
        } finally {
            if (started) runCatching { muxer.stop() }
            runCatching { muxer.release() }
            temporary.delete()
        }
    }
}
