package com.oyasumi.recorder

object SessionAnalysis {
    fun loudPercent(session: RecordingSession): Int {
        if (session.durationMs <= 0L || session.samples.isEmpty()) return 0
        var loud = 0L
        session.samples.forEachIndexed { i, sample ->
            val end = session.samples.getOrNull(i + 1)?.offsetMs ?: session.durationMs
            val width = (end.coerceAtMost(session.durationMs) - sample.offsetMs).coerceAtLeast(0L)
            if (sample.db >= session.thresholdDb) loud += width
        }
        return ((loud.toDouble() / session.durationMs) * 100).toInt().coerceIn(0, 100)
    }
    fun loudestIndex(events: List<SoundEvent>): Int? = events.indices.maxByOrNull { events[it].peakDb }
    fun peaks(samples: List<VolumeSample>, maxPoints: Int): List<VolumeSample> {
        require(maxPoints > 0)
        if (samples.size <= maxPoints) return samples
        return (0 until maxPoints).map { i ->
            val start = (i.toLong() * samples.size / maxPoints).toInt()
            val end = ((i + 1L) * samples.size / maxPoints).toInt()
            samples.subList(start, end).maxBy { it.db }
        }
    }
}
