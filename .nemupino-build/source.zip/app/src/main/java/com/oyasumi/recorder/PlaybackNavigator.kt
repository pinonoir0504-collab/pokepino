package com.oyasumi.recorder

import kotlin.math.abs

object PlaybackNavigator {
    fun matchingEventIndex(events: List<SoundEvent>, expected: SoundEvent): Int? =
        events.indices.firstOrNull { events[it].startMs == expected.startMs && events[it].endMs == expected.endMs }

    fun containingEvent(events: List<SoundEvent>, indices: List<Int>, positionMs: Long): Int? =
        indices.firstOrNull { index -> events.getOrNull(index)?.let { positionMs >= it.startMs && positionMs < it.endMs } == true }

    fun nextAfterPosition(events: List<SoundEvent>, indices: List<Int>, positionMs: Long): Int? =
        indices.firstOrNull { index -> events.getOrNull(index)?.startMs?.let { it > positionMs + 250L } == true }

    fun previousBeforePosition(events: List<SoundEvent>, indices: List<Int>, positionMs: Long): Int? =
        indices.lastOrNull { index -> events.getOrNull(index)?.startMs?.let { it < positionMs - 250L } == true }

    fun nextIndex(currentIndex: Int, eventCount: Int): Int? {
        if (eventCount <= 0) return null
        val next = currentIndex + 1
        return next.takeIf { it in 0 until eventCount }
    }

    fun previousIndex(currentIndex: Int, eventCount: Int): Int? {
        if (eventCount <= 0) return null
        val previous = currentIndex - 1
        return previous.takeIf { it in 0 until eventCount }
    }

    fun nearestEventIndex(events: List<SoundEvent>, offsetMs: Long): Int? {
        if (events.isEmpty()) return null
        return events.indices.minByOrNull { index ->
            val event = events[index]
            val center = event.startMs + event.durationMs / 2L
            abs(center - offsetMs)
        }
    }

    fun samplesAroundEvent(
        samples: List<VolumeSample>,
        event: SoundEvent?,
        sessionDurationMs: Long,
        paddingMs: Long = 8_000L
    ): List<VolumeSample> {
        if (event == null || samples.isEmpty()) return emptyList()
        val start = (event.startMs - paddingMs).coerceAtLeast(0L)
        val end = (event.endMs + paddingMs).coerceAtMost(sessionDurationMs)
        return samples.filter { it.offsetMs in start..end }
    }
}
