package com.oyasumi.recorder

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

private val AppBg = Color(0xFF191A20)
private val AppBgDeep = Color(0xFF111217)
private val Panel = Color(0xFF22252C)
private val PanelSoft = Color(0xFF272B32)
private val PanelRaised = Color(0xFF31363D)
private val Accent = Color(0xFF24B5E3)
private val AccentSoft = Color(0xFF67CDEB)
private val QuietColor = Color(0xFF3D4249)
private val LightColor = Color(0xFF4AABA0)
private val LoudColor = Color(0xFFD7AE6D)
private val IntenseColor = Color(0xFFDF6A35)
private val White90 = Color(0xFFF2F4F6)
private val White70 = Color(0xFFB7BCC3)
private val White50 = Color(0xFF9CA6B3)
private val Border = Color(0xFF3D4249)
private val Danger = Color(0xFFFF6B6B)
private const val WHOLE_PLAYBACK_INDEX = -1

private val NemuColorScheme = darkColorScheme(
    primary = Accent,
    secondary = AccentSoft,
    background = AppBg,
    surface = Panel,
    surfaceVariant = PanelSoft,
    onPrimary = Color.White,
    onBackground = White90,
    onSurface = White90
)

private enum class AppScreen(val label: String, val symbol: String) {
    RECORD("録音", "◉"),
    RESULTS("結果", "▷"),
    TRENDS("傾向", "▥"),
    MORE("履歴", "▤"),
    SETTINGS("設定", "⚙")
}

private enum class NoiseLevel(val label: String, val color: Color) {
    QUIET("静か", QuietColor),
    LIGHT("軽め", LightColor),
    LOUD("大きめ", LoudColor),
    INTENSE("激しい", IntenseColor)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = NemuColorScheme) {
                var loaded by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) {
                    withContext(Dispatchers.IO) { SessionStore.get(applicationContext) }
                    loaded = true
                    withContext(Dispatchers.IO) {
                        SessionStore.get(applicationContext).recoverOrphans()
                        SessionStore.get(applicationContext).cleanupExpired()
                        SessionRefiner.resumePending(applicationContext)
                    }
                }
                if (loaded) NemuPinoApp(openResults = BuildConfig.DEBUG && intent.getBooleanExtra("show_results", false))
                else Box(Modifier.fillMaxSize().background(AppBg), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
            }
        }
    }
}

@Composable
private fun NemuPinoApp(openResults: Boolean = false) {
    val context = LocalContext.current
    val uiScope = rememberCoroutineScope()
    val store = remember { SessionStore.get(context) }
    val sessions by store.sessions.collectAsStateWithLifecycle()
    val recordingState by RecordingBus.state.collectAsStateWithLifecycle()
    val recordingError by RecordingBus.error.collectAsStateWithLifecycle()
    val completedId by RecordingBus.lastCompletedSessionId.collectAsStateWithLifecycle()

    var screen by rememberSaveable { mutableStateOf(if (openResults) AppScreen.RESULTS else AppScreen.RECORD) }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var handledCompletedId by rememberSaveable { mutableStateOf<String?>(null) }
    var permissionMessage by rememberSaveable { mutableStateOf<String?>(null) }

    var pendingDelayMs by rememberSaveable { mutableStateOf(0L) }

    fun startService() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            RecordingService.start(context, pendingDelayMs)
            screen = AppScreen.RECORD
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            permissionMessage = null
            startService()
        } else {
            permissionMessage = "録音にはマイクの許可が必要です。"
        }
    }

    fun requestAndStart(delayMs: Long = 0L) {
        pendingDelayMs = delayMs
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startService()
            return
        }
        val permissions = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
        permissionLauncher.launch(permissions)
    }

    LaunchedEffect(sessions) {
        if (selectedId == null && sessions.isNotEmpty()) selectedId = sessions.first().id
        if (selectedId != null && sessions.none { it.id == selectedId }) selectedId = sessions.firstOrNull()?.id
    }

    LaunchedEffect(completedId, sessions) {
        val id = completedId
        if (id != null && id != handledCompletedId && sessions.any { it.id == id }) {
            handledCompletedId = id
            selectedId = id
            screen = AppScreen.RESULTS
        }
    }

    val selected = sessions.firstOrNull { it.id == selectedId } ?: sessions.firstOrNull()
    val selectedIndex = sessions.indexOfFirst { it.id == selectedId }.takeIf { it >= 0 } ?: 0

    Scaffold(
        containerColor = AppBg,
        bottomBar = {
            AppBottomBar(
                selected = screen,
                onSelect = {
                    screen = it
                    if (it == AppScreen.RESULTS && selectedId == null && sessions.isNotEmpty()) {
                        selectedId = sessions.first().id
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                AppScreen.RECORD -> HomeOrRecordingScreen(
                    recordingState = recordingState,
                    latest = sessions.firstOrNull(),
                    permissionMessage = permissionMessage ?: recordingError,
                    onStart = { requestAndStart() },
                    onDelayedStart = { requestAndStart(RecordingService.THIRTY_MINUTES_MS) },
                    onStop = { RecordingService.stop(context) },
                    onOpenLatest = {
                        selectedId = it.id
                        screen = AppScreen.RESULTS
                    }
                )

                AppScreen.RESULTS -> {
                    if (selected == null) {
                        EmptyResultsScreen(onGoRecord = { screen = AppScreen.RECORD })
                    } else {
                        ResultScreen(
                            sessions = sessions,
                            selectedIndex = selectedIndex,
                            session = selected,
                            file = store.recordingFile(selected.fileName),
                            onSelectSession = { index -> selectedId = sessions.getOrNull(index)?.id },
                            onOpenMore = { screen = AppScreen.MORE },
                            onOpenSettings = { screen = AppScreen.SETTINGS }
                        )
                    }
                }

                AppScreen.TRENDS -> TrendsScreen(sessions)

                AppScreen.MORE -> MoreScreen(
                    sessions = sessions,
                    onOpen = {
                        selectedId = it.id
                        screen = AppScreen.RESULTS
                    },
                    onDelete = { session ->
                        uiScope.launch {
                            val result = withContext(Dispatchers.IO) { runCatching { store.delete(session.id) } }
                            if (result.isFailure) Toast.makeText(context, "削除を保存できませんでした", Toast.LENGTH_LONG).show()
                        }
                    }
                )

                AppScreen.SETTINGS -> SettingsScreen(
                    onRetentionChanged = {
                        uiScope.launch {
                            val result = withContext(Dispatchers.IO) { runCatching { store.cleanupExpired() } }
                            if (result.isFailure) Toast.makeText(context, "保存期間の更新に失敗しました", Toast.LENGTH_LONG).show()
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun AppBottomBar(selected: AppScreen, onSelect: (AppScreen) -> Unit) {
    NavigationBar(containerColor = AppBgDeep, contentColor = White90) {
        AppScreen.entries.filterNot { it == AppScreen.MORE }.forEach { item ->
            NavigationBarItem(
                selected = selected == item,
                onClick = { onSelect(item) },
                icon = {
                    NavGlyph(item.ordinal, if (selected == item) Accent else White50)
                },
                label = {
                    Text(
                        item.label,
                        color = if (selected == item) Accent else White50,
                        fontSize = 10.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Accent.copy(alpha = 0.12f),
                    selectedIconColor = Accent,
                    selectedTextColor = Accent,
                    unselectedIconColor = White50,
                    unselectedTextColor = White50
                )
            )
        }
    }
}

@Composable
private fun HomeOrRecordingScreen(
    recordingState: RecordingUiState,
    latest: RecordingSession?,
    permissionMessage: String?,
    onStart: () -> Unit,
    onDelayedStart: () -> Unit,
    onStop: () -> Unit,
    onOpenLatest: (RecordingSession) -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = AppBg) {
        when (recordingState) {
            RecordingUiState.Idle -> HomeScreen(latest, permissionMessage, onStart, onDelayedStart, onOpenLatest)
            is RecordingUiState.Active -> RecordingScreen(recordingState, onStop)
            is RecordingUiState.Waiting -> WaitingScreen(recordingState, onStart, onStop)
            is RecordingUiState.Saving -> Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(recordingState.message, color = Accent, fontSize = 16.sp)
                Spacer(Modifier.height(16.dp))
                LinearProgressIndicator(progress = { recordingState.progress }, modifier = Modifier.fillMaxWidth())
                Text("${(recordingState.progress * 100).toInt()}%", color = White70)
                Text("途中保存した音声を残して処理しています", color = White50, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    latest: RecordingSession?,
    permissionMessage: String?,
    onStart: () -> Unit,
    onDelayedStart: () -> Unit,
    onOpenLatest: (RecordingSession) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF20232B), AppBgDeep)))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.pino_logo),
            contentDescription = "ねむピーノ ロゴ",
            modifier = Modifier.size(88.dp)
        )
        Text("NEMU PINO", color = Accent, fontSize = 12.sp, letterSpacing = 3.sp, modifier = Modifier.padding(top = 12.dp))
        Text("ねむピーノ  /  SLEEP AUDIO JOURNAL", color = White70, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().height(116.dp),
            shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("今すぐ録音", color = AppBgDeep, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("START YOUR NIGHT", color = AppBgDeep.copy(alpha = 0.6f), fontSize = 10.sp, letterSpacing = 2.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onDelayedStart,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = PanelRaised)
        ) { Text("30分後に録音開始", color = Accent, fontSize = 17.sp) }
        permissionMessage?.let {
            Text(it, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
        }

        latest?.let { session ->
            Spacer(Modifier.height(18.dp))
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpenLatest(session) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("前回の結果", color = White50, fontSize = 11.sp)
                        Text(formatDate(session.startedAt), color = White90, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "${formatClock(session.startedAt)}〜${formatClock(session.endedAt)}  ・  ${session.events.size}回検出",
                            color = White70,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                    Text("›", color = Accent, fontSize = 30.sp)
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("録音データはこの端末内だけに保存されます", color = White50, fontSize = 11.sp)
    }
}

@Composable
private fun WaitingScreen(state: RecordingUiState.Waiting, onStartNow: () -> Unit, onCancel: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("録音開始まで", color = White70, fontSize = 20.sp)
        Spacer(Modifier.height(18.dp))
        Text(formatDuration(state.remainingMs), color = Accent, fontSize = 48.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text("画面を消しても自動で録音を開始します", color = White70, fontSize = 13.sp)
        Text("待機中は録音されません", color = White50, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onStartNow, modifier = Modifier.fillMaxWidth()) { Text("今すぐ録音開始") }
        TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("予約をキャンセル", color = Danger) }
    }
}

@Composable
private fun RecordingScreen(state: RecordingUiState.Active, onStop: () -> Unit) {
    val level = ((state.db + 60f) / 60f).coerceIn(0f, 1f)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF111A22), AppBgDeep)))
            .padding(horizontal = 24.dp, vertical = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("測定中", color = AccentSoft, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(formatDuration(state.elapsedMs), color = White90, fontWeight = FontWeight.Bold, fontSize = 45.sp, modifier = Modifier.padding(top = 8.dp))
        Text("開始 ${formatClock(state.startedAt)}", color = White70, fontSize = 13.sp)

        Spacer(Modifier.height(42.dp))
        Button(
            onClick = onStop,
            modifier = Modifier.size(194.dp),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Danger)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("■", color = Color.White, fontSize = 42.sp)
                Text("停止", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("ワンタッチ", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(36.dp))
        Text("今の音の大きさ", color = White70, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { level },
            modifier = Modifier.fillMaxWidth().height(12.dp),
            color = noiseLevel(state.db).color,
            trackColor = Border,
            strokeCap = StrokeCap.Round
        )
        Text("画面を消しても録音は続きます", color = White50, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.weight(1f))
        Text("朝は中央の停止ボタンを1回押してください", color = White70, fontSize = 12.sp)
    }
}

@Composable
private fun EmptyResultsScreen(onGoRecord: () -> Unit) {
    Box(Modifier.fillMaxSize().background(AppBg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Text("まだ結果がありません", color = White90, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("まず録音タブで測定してください。", color = White70, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(16.dp))
            Button(onClick = onGoRecord, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                Text("録音画面へ")
            }
        }
    }
}

@Composable
private fun ResultScreen(
    sessions: List<RecordingSession>,
    selectedIndex: Int,
    session: RecordingSession,
    file: File,
    onSelectSession: (Int) -> Unit,
    onOpenMore: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val player = remember(session.id) { SegmentAudioPlayer() }
    val labelScope = rememberCoroutineScope()
    var reviewOpen by remember(session.id) { mutableStateOf(false) }
    var morningOpen by remember(session.id) { mutableStateOf(false) }
    var eventListOpen by remember(session.id) { mutableStateOf(false) }
    var rankingOpen by remember(session.id) { mutableStateOf(false) }
    var loudMoments by remember(session.id) { mutableStateOf<List<LoudMoment>?>(null) }
    LaunchedEffect(session.id, session.samples, session.events) {
        loudMoments = null
        loudMoments = withContext(Dispatchers.Default) { LoudMoments.rankSnores(session, 5) }
    }
    var selectedEventIndex by remember(session.id) { mutableIntStateOf(if (session.events.isEmpty()) -1 else 0) }

    DisposableEffect(player) { onDispose { player.release() } }

    var candidatesOnly by remember(session.id) { mutableStateOf(false) }
    var continuous by remember(session.id) { mutableStateOf(false) }
    var labelOpen by remember(session.id) { mutableStateOf(false) }
    var labelTarget by remember(session.id) { mutableStateOf<SoundEvent?>(null) }
    var labelTargetIndex by remember(session.id) { mutableIntStateOf(-1) }
    var windowMs by remember(session.id) { mutableLongStateOf(30_000L) }
    var waveCenter by remember(session.id) { mutableLongStateOf(session.events.firstOrNull()?.startMs ?: 15_000L) }
    var followPlayback by remember(session.id) { mutableStateOf(true) }
    val visibleIndices = remember(session.events, candidatesOnly) { session.events.indices.filter { !candidatesOnly || (if (session.events[it].label.isNotBlank()) session.events[it].label == "いびき" else session.events[it].candidate == "いびき候補") } }
    val eventLookup = remember(session.events, visibleIndices) { EventLookup(session.events, visibleIndices) }
    fun nextVisible(index: Int) = visibleIndices.firstOrNull { it > index }
    fun previousVisible(index: Int) = visibleIndices.lastOrNull { it < index }
    LaunchedEffect(candidatesOnly, visibleIndices) { if (selectedEventIndex !in visibleIndices) {
        player.stop(); selectedEventIndex = visibleIndices.firstOrNull() ?: -1
        session.events.getOrNull(selectedEventIndex)?.let { waveCenter = it.startMs + it.durationMs.coerceAtMost(10_000L) / 2 }
    } }
    val selectedEvent = session.events.getOrNull(selectedEventIndex)
    val waveStart = WaveWindow.start(waveCenter, windowMs, session.durationMs)
    val waveEnd = minOf(waveStart + windowMs, session.durationMs)
    val waveSamples = remember(session.samples, waveStart, waveEnd) { WaveWindow.slice(session.samples, waveStart, waveEnd) }
    LaunchedEffect(player.positionMs.longValue, followPlayback) {
        val position = player.positionMs.longValue
        if (followPlayback && player.isPrepared.value && position !in waveStart..waveEnd) waveCenter = position + windowMs / 3
    }
    val selectedLoaded = selectedEventIndex >= 0 && player.playingIndex.value == selectedEventIndex
    val wholeLoaded = player.playingIndex.value == WHOLE_PLAYBACK_INDEX
    val nextPlaybackIndex = if (player.isPrepared.value) eventLookup.next(player.positionMs.longValue) else nextVisible(selectedEventIndex)
    val previousPlaybackIndex = if (player.isPrepared.value) eventLookup.previous(player.positionMs.longValue) else previousVisible(selectedEventIndex)
    val currentLabelIndex = if (player.isPrepared.value) eventLookup.containing(player.positionMs.longValue) ?: -1 else selectedEventIndex
    val currentLabelEvent = session.events.getOrNull(currentLabelIndex)

    fun playEvent(index: Int) {
        val event = session.events.getOrNull(index) ?: return
        val range = PlaybackRanges.fromEvent(event, session.durationMs, excerptOnly = continuous) ?: return
        selectedEventIndex = index
        waveCenter = event.startMs + event.durationMs.coerceAtMost(10_000L) / 2
        followPlayback = true
        player.play(file, range, index)
    }

    fun playFromTime(timeMs: Long) {
        val range = PlaybackRanges.fromTime(timeMs, session.durationMs) ?: return
        continuous = false
        selectedEventIndex = eventLookup.containing(range.startMs) ?: -1
        followPlayback = true
        waveCenter = range.startMs
        player.play(file, range, WHOLE_PLAYBACK_INDEX)
    }


    val completionHandler by rememberUpdatedState<(Int) -> Unit> { index ->
        if (continuous) nextVisible(index)?.let(::playEvent)
    }
    DisposableEffect(player) { player.onRangeFinished = { completionHandler(it) }; onDispose { player.onRangeFinished = null } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF20232B), AppBg)))
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        ResultsHeader(
            session = session,
            canGoOlder = selectedIndex < sessions.lastIndex,
            canGoNewer = selectedIndex > 0,
            onOlder = { if (selectedIndex < sessions.lastIndex) onSelectSession(selectedIndex + 1) },
            onNewer = { if (selectedIndex > 0) onSelectSession(selectedIndex - 1) },
            onMenu = onOpenMore,
            onSettings = onOpenSettings
        )

        ResultSummary(session, onReview = { reviewOpen = true }, onMorning = { morningOpen = true }, onLoudest = { rankingOpen = true })
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatClock(session.startedAt), color = White70, fontSize = 13.sp)
            Text(formatClock(session.endedAt), color = White70, fontSize = 13.sp)
        }

        NightTimelinePanel(
            session = session,
            selectedEvent = selectedEvent,
            playbackPositionMs = if (player.isPrepared.value) player.positionMs.longValue else null,
            onSeek = ::playFromTime,
            modifier = Modifier.fillMaxWidth().weight(1.15f)
        )

        SelectedTimeBar(
            session = session,
            event = selectedEvent,
            wholeLoaded = wholeLoaded,
            playbackPositionMs = if (player.isPrepared.value) player.positionMs.longValue else null,
            wholePlaying = wholeLoaded && player.isPlaying.value,
            onWholePlayback = {
                val whole = SoundEvent(0L, session.durationMs, 0f)
                if (wholeLoaded) player.togglePause() else player.play(file, whole, WHOLE_PLAYBACK_INDEX)
            }
        )

        Row(Modifier.fillMaxWidth().height(40.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { candidatesOnly = !candidatesOnly }, contentPadding = PaddingValues(2.dp)) { Text(if (candidatesOnly) "いびき候補" else "全ての音", color = Accent, fontSize = 12.sp) }
            TextButton(onClick = { continuous = !continuous; if (!continuous) player.extendToRecordingEnd() }, contentPadding = PaddingValues(2.dp)) { Text(if (continuous) "区間再生 ON" else "区間再生 OFF", color = AccentSoft, fontSize = 12.sp) }
            TextButton(onClick = { labelTarget = currentLabelEvent; labelTargetIndex = currentLabelIndex; labelOpen = true }, enabled = currentLabelEvent != null, contentPadding = PaddingValues(2.dp)) { Text(currentLabelEvent?.label?.takeIf { it.isNotBlank() } ?: currentLabelEvent?.candidate ?: "分類", fontSize = 12.sp, maxLines = 1) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { windowMs = (windowMs * 2).coerceAtMost(120_000L) }) { Text("−", fontSize = 22.sp) }
            Text("詳細波形 · ${windowMs / 1000}秒", color = White70, fontSize = 12.sp)
            TextButton(onClick = { followPlayback = true; if (player.isPrepared.value) waveCenter = player.positionMs.longValue }) { Text("追従", color = if (followPlayback) Accent else White50, fontSize = 11.sp) }
            TextButton(onClick = { windowMs = (windowMs / 2).coerceAtLeast(5_000L) }) { Text("＋", fontSize = 22.sp) }
        }
        WaveformPanel(
            samples = waveSamples,
            onPan = { fraction -> followPlayback = false; waveCenter = (waveStart + windowMs / 2 - (fraction * windowMs).toLong()).coerceIn(0L, session.durationMs) },
            event = selectedEvent,
            playbackPositionMs = if (selectedLoaded || wholeLoaded) player.positionMs.longValue else null,
            onSeek = { time ->
                continuous = false
                selectedEventIndex = eventLookup.containing(time) ?: -1
                if (player.isPrepared.value) player.seekTo(time)
                else playFromTime(time)
            },
            volume = player.volume.floatValue,
            onVolume = player::setVolume,
            modifier = Modifier.fillMaxWidth().weight(1f)
        )

        player.error.value?.let { Text(it, color = Danger, fontSize = 11.sp) }
        PlaybackBar(
            hasEvent = selectedEvent != null || wholeLoaded,
            isSelectedLoaded = selectedLoaded || wholeLoaded,
            isPlaying = (selectedLoaded || wholeLoaded) && player.isPlaying.value,
            canPrevious = previousPlaybackIndex != null,
            canNext = nextPlaybackIndex != null,
            onPlayPause = {
                if (selectedLoaded || wholeLoaded) player.togglePause()
                else if (selectedEvent != null) playEvent(selectedEventIndex)
            },
            onStop = { continuous = false; player.stop() },
            onPrevious = {
                previousPlaybackIndex?.let(::playEvent)
            },
            onNext = {
                nextPlaybackIndex?.let(::playEvent)
            },
            onList = { eventListOpen = true }
        )
    }
    if (rankingOpen) {
        AlertDialog(onDismissRequest = { rankingOpen = false }, title = { Text("大いびき TOP5") }, text = {
            Column {
                Text("いびき候補の中だけからピーク音量順に抽出します。\n咳・物音・犬や声の候補はランキング対象外です。\nタップすると少し前から再生します。", color = White70, fontSize = 12.sp)
                val ranks = loudMoments
                if (ranks == null) Text("ランキングを集計しています…")
                else if (ranks.isEmpty()) Text("大いびき候補はありません")
                else LazyColumn(Modifier.heightIn(max = 400.dp).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ranks.size) { rank ->
                        val moment = ranks[rank]
                        Row(Modifier.fillMaxWidth().background(if (rank == 0) Accent.copy(alpha = 0.12f) else PanelRaised, RoundedCornerShape(16.dp)).clickable { rankingOpen = false; playFromTime(moment.playbackStartMs) }.padding(horizontal = 14.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${rank + 1}位", color = if (rank < 3) LoudColor else Accent, modifier = Modifier.width(42.dp), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Column(Modifier.weight(1f)) {
                                Text(formatClockSeconds(session.startedAt + moment.offsetMs), color = White90, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                                Text("ピーク ${moment.peakDb.toInt()} dB · 相対音量", color = White70, fontSize = 12.sp)
                            }
                            Text("▶", color = Accent)
                        }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { rankingOpen = false }) { Text("閉じる") } })
    }
    if (eventListOpen) {
        AlertDialog(onDismissRequest = { eventListOpen = false }, title = { Text("録音した区間") }, text = {
            if (visibleIndices.isEmpty()) Text("対象の区間がありません。全体再生で確認できます。")
            else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(visibleIndices, key = { it }) { index ->
                    val event = session.events[index]
                    Row(Modifier.fillMaxWidth().semantics { contentDescription = "録音区間 ${index + 1}" }.clickable { eventListOpen = false; playEvent(index) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("▶", color = Accent, modifier = Modifier.padding(end = 12.dp))
                        Column { Text(formatClockSeconds(session.startedAt + event.startMs), color = White90)
                            Text("${event.label.ifBlank { event.candidate }} · ${formatDuration(event.durationMs)}", color = White70, fontSize = 12.sp) }
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { eventListOpen = false }) { Text("閉じる") } })
    }
    if (morningOpen) MorningAnalysisDialog(session, onDismiss = { morningOpen = false }, onOpenTop5 = { morningOpen = false; rankingOpen = true })
    if (reviewOpen) ReviewDialog(session, file, onDismiss = { reviewOpen = false })
    val target = labelTarget
    if (labelOpen && target != null) {
        val store = SessionStore.get(LocalContext.current)
        AlertDialog(onDismissRequest = { labelOpen = false }, title = { Text("音のラベル") },
            text = { Column {
                Text(formatClockSeconds(session.startedAt + target.startMs), color = Accent, fontSize = 12.sp)
                Text("自動推定：${target.candidate}（参考）", fontSize = 12.sp)
                Text("候補は音の特徴による推定です。聞いて確認してください。", fontSize = 12.sp)
                listOf("いびき", "寝言", "咳", "犬の鳴き声", "物音", "寝返り", "環境音", "").forEach { label ->
                    TextButton(onClick = { val index = labelTargetIndex
                        labelOpen = false
                        labelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                            runCatching { store.labelEvent(session.id, index, label, target) }.onFailure { RecordingBus.reportError("ラベルを保存できませんでした。区間を選び直し、空き容量も確認してください。") }
                        } }) { Text(label.ifBlank { "ラベルを解除" }) }
                }
            } }, confirmButton = { TextButton(onClick = { labelOpen = false }) { Text("閉じる") } })
    }
}

@Composable
private fun ResultsHeader(
    session: RecordingSession,
    canGoOlder: Boolean,
    canGoNewer: Boolean,
    onOlder: () -> Unit,
    onNewer: () -> Unit,
    onMenu: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(44.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onMenu, modifier = Modifier.width(44.dp), contentPadding = PaddingValues(4.dp)) {
            Text("☰", color = Accent, fontSize = 25.sp)
        }
        TextButton(onClick = onOlder, modifier = Modifier.width(44.dp), enabled = canGoOlder, contentPadding = PaddingValues(4.dp)) {
            Text("‹", color = if (canGoOlder) White70 else White50.copy(alpha = 0.35f), fontSize = 34.sp)
        }
        Text(
            formatDate(session.startedAt),
            color = White90,
            fontSize = 17.sp,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center
        )
        TextButton(onClick = onNewer, modifier = Modifier.width(44.dp), enabled = canGoNewer, contentPadding = PaddingValues(4.dp)) {
            Text("›", color = if (canGoNewer) White70 else White50.copy(alpha = 0.35f), fontSize = 34.sp)
        }
        TextButton(onClick = onSettings, modifier = Modifier.width(44.dp), contentPadding = PaddingValues(4.dp)) {
            Text("⚙", color = Accent, fontSize = 24.sp)
        }
    }
}

@Composable
private fun NightTimelinePanel(
    session: RecordingSession,
    selectedEvent: SoundEvent?,
    playbackPositionMs: Long?,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        var bandView by remember(session.id) { mutableStateOf(false) }
        var overview by remember(session.id) { mutableStateOf<List<VolumeSample>>(emptyList()) }
        var times by remember(session.id) { mutableStateOf(List(4) { 0L }) }
        var loading by remember(session.id) { mutableStateOf(true) }
        LaunchedEffect(session.id, session.samples) {
            loading = true
            val data = withContext(Dispatchers.Default) { reduceSamples(session.samples, 280) to SessionMetrics.intensityDurations(session) }
            overview = data.first; times = data.second; loading = false
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("録音全体", color = White90, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { bandView = !bandView }, modifier = Modifier.height(30.dp), contentPadding = PaddingValues(horizontal = 8.dp)) { Text(if (bandView) "音量グラフ" else "色分け表示", fontSize = 12.sp, color = Accent) }
        }
        NightTimelineChart(
            session = session,
            reduced = overview,
            loading = loading,
            bandView = bandView,
            selectedEvent = selectedEvent,
            playbackPositionMs = playbackPositionMs,
            onSeek = onSeek,
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        TimelineAxis(session.startedAt, session.durationMs)
        Spacer(Modifier.height(2.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            NoiseLevel.entries.forEach { level ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    LegendItem(level)
                    Text(if (loading) "—" else formatDuration(times[level.ordinal]), color = White70, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun NightTimelineChart(
    session: RecordingSession,
    reduced: List<VolumeSample>,
    loading: Boolean,
    bandView: Boolean,
    selectedEvent: SoundEvent?,
    playbackPositionMs: Long?,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    if (reduced.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text(if (loading) "波形を準備しています…" else "音量データなし", color = White70, fontSize = 13.sp)
        }
        return
    }

    val floorDb = AppSettings.get(LocalContext.current).get().waveformFloorDb
    val seek by rememberUpdatedState(onSeek)
    Canvas(
        modifier = modifier.clip(RoundedCornerShape(18.dp)).semantics { contentDescription = "録音全体のグラフ。タップした時刻から再生" }.pointerInput(session.id, session.durationMs) {
            detectTapGestures { point ->
                seek((point.x / size.width.coerceAtLeast(1) * session.durationMs).toLong())
            }
        }
    ) {
        val w = size.width
        val h = size.height
        val baselineHeight = 1f

        drawRect(AppBgDeep, size = size)
        drawRect(
            color = QuietColor.copy(alpha = 0.72f),
            topLeft = Offset(0f, h - baselineHeight),
            size = Size(w, baselineHeight)
        )
        for (i in 1..3) {
            val y = h * i / 4f
            drawLine(Border.copy(alpha = 0.75f), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }

        val barWidth = (w / reduced.size.coerceAtLeast(1)).coerceAtLeast(1f)
        reduced.forEachIndexed { index, sample ->
            val amp = WaveformScale.height(sample.db, floorDb)
            if (amp <= 0f && !bandView) return@forEachIndexed
            val barHeight = if (bandView) h else amp * (h - 6f) * 0.78f
            drawRect(
                color = noiseLevel(sample.db).color,
                topLeft = Offset(w * sample.offsetMs / session.durationMs.coerceAtLeast(1L), h - barHeight),
                size = Size(max(1f, barWidth * if (bandView) 1.05f else 0.85f), barHeight)
            )
        }

        if (!bandView) selectedEvent?.let { event ->
            val center = event.startMs + event.durationMs / 2L
            val x = w * (center.toFloat() / session.durationMs.coerceAtLeast(1L).toFloat())
            val eventPeakY = h - WaveformScale.height(event.peakDb, floorDb) * (h - 6f) * 0.78f
            drawLine(Accent, Offset(x, eventPeakY), Offset(x, h), strokeWidth = 2f)
            drawCircle(AppBgDeep, radius = 9f, center = Offset(x, eventPeakY))
            drawCircle(Accent, radius = 9f, center = Offset(x, eventPeakY), style = Stroke(width = 3f))
        }
        playbackPositionMs?.let { time ->
            val x = w * time.coerceIn(0L, session.durationMs).toFloat() / session.durationMs.coerceAtLeast(1L)
            drawLine(Accent, Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
        }
    }
}

@Composable
private fun TimelineAxis(startedAt: Long, durationMs: Long) {
    val labels = if (durationMs < 600_000L) listOf(0L, durationMs / 2, durationMs) else timelineLabels(durationMs)
    Row(Modifier.fillMaxWidth().padding(horizontal = 1.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        labels.forEach { ms -> Text(if (durationMs < 600_000L) formatClockSeconds(startedAt + ms) else formatClock(startedAt + ms), color = White70, fontSize = 11.sp) }
    }
}

@Composable
private fun LegendItem(level: NoiseLevel) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 8.dp, height = 16.dp).background(level.color, RoundedCornerShape(8.dp)))
        Spacer(Modifier.width(6.dp))
        Text(level.label, color = White90, fontSize = 13.sp)
    }
}

@Composable
private fun SelectedTimeBar(
    session: RecordingSession,
    event: SoundEvent?,
    wholeLoaded: Boolean,
    playbackPositionMs: Long?,
    wholePlaying: Boolean,
    onWholePlayback: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .border(1.dp, Border, RoundedCornerShape(28.dp))
            .background(Color(0xFF191D22), RoundedCornerShape(28.dp))
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(38.dp).background(PanelRaised, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("●", color = event?.let { eventLevel(it).color } ?: White50, fontSize = 16.sp)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("再生時刻", color = White70, fontSize = 11.sp)
        Text(
            playbackPositionMs?.let { formatClockSeconds(session.startedAt + it) }
                ?: event?.let { formatClockSeconds(session.startedAt + it.startMs) } ?: "大きな音なし",
            color = White90,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        }
        TextButton(onClick = onWholePlayback, contentPadding = PaddingValues(horizontal = 5.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (wholePlaying) "Ⅱ" else "≋", color = if (wholeLoaded) IntenseColor else Accent, fontSize = 20.sp)
                Text("全体再生", color = White70, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun WaveformPanel(
    samples: List<VolumeSample>,
    event: SoundEvent?,
    playbackPositionMs: Long?,
    onSeek: (Long) -> Unit,
    onPan: (Float) -> Unit,
    volume: Float,
    onVolume: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(top = 6.dp)) {
        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
            Column(
                modifier = Modifier.width(42.dp).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("VOL", color = White70, fontSize = 9.sp, fontWeight = FontWeight.Medium)
                Text("${(volume * 100).roundToInt()}", color = White50, fontSize = 9.sp)
            }
            WaveformCanvas(
                samples = samples,
                event = event,
                playbackPositionMs = playbackPositionMs,
                onSeek = onSeek,
                onPan = onPan,
                modifier = Modifier.weight(1f).fillMaxHeight()
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(36.dp)) {
            Text("音量", color = White70, fontSize = 12.sp, modifier = Modifier.width(42.dp))
            Slider(value = volume, onValueChange = onVolume, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun WaveformCanvas(
    samples: List<VolumeSample>,
    event: SoundEvent?,
    playbackPositionMs: Long?,
    onSeek: (Long) -> Unit,
    onPan: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val floorDb = AppSettings.get(LocalContext.current).get().waveformFloorDb
    val reduced = remember(samples) { reduceSamples(samples, 600) }
    val estimatedFloor = remember(reduced) { reduced.map { it.db }.sorted().let { if (it.isEmpty()) -60f else it[it.size / 5] } }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    val envelopes = remember(reduced, floorDb, estimatedFloor, samples.firstOrNull()?.offsetMs, samples.lastOrNull()?.offsetMs, canvasSize) {
        val startTime = samples.firstOrNull()?.offsetMs ?: 0L
        val duration = ((samples.lastOrNull()?.offsetMs ?: startTime) - startTime).coerceAtLeast(1L)
        val displayFloor = maxOf(floorDb, (estimatedFloor + 6f).coerceAtMost(-20f))
        fun make(raw: Boolean): Path = Path().apply {
            reduced.forEachIndexed { index, sample ->
                val x = canvasSize.width * (sample.offsetMs - startTime).toFloat() / duration
                val height = WaveformScale.height(sample.db, if (raw) -48f else displayFloor) * canvasSize.height * .24f
                if (index == 0) moveTo(x, canvasSize.height * .5f - height) else lineTo(x, canvasSize.height * .5f - height)
            }
            reduced.asReversed().forEach { sample ->
                val x = canvasSize.width * (sample.offsetMs - startTime).toFloat() / duration
                val height = WaveformScale.height(sample.db, if (raw) -48f else displayFloor) * canvasSize.height * .24f
                lineTo(x, canvasSize.height * .5f + height)
            }
            close()
        }
        make(true) to make(false)
    }
    var dragTime by remember(samples.firstOrNull()?.offsetMs, samples.lastOrNull()?.offsetMs) { mutableStateOf<Long?>(null) }
    val seek by rememberUpdatedState(onSeek)
    val pan by rememberUpdatedState(onPan)
    val start = samples.firstOrNull()?.offsetMs ?: 0L
    val end = samples.lastOrNull()?.offsetMs ?: start
    fun timeAt(x: Float, width: Int): Long = start + ((end - start) * (x / width.coerceAtLeast(1)).coerceIn(0f, 1f)).toLong()
    Canvas(modifier = modifier.onSizeChanged { canvasSize = it }.semantics { contentDescription = "詳細波形" }.clip(RoundedCornerShape(18.dp)).background(AppBgDeep)
        .pointerInput(start, end) {
            detectTapGestures { position -> if (end > start) seek(timeAt(position.x, size.width)) }
        }
        .pointerInput(Unit) {
            detectHorizontalDragGestures(
                onDragStart = { dragTime = null },
                onHorizontalDrag = { change, amount -> change.consume(); pan(amount / size.width.coerceAtLeast(1)) },
                onDragEnd = { dragTime = null },
                onDragCancel = { dragTime = null }
            )
        }) {
        val w = size.width
        val h = size.height
        val mid = h / 2f
        for (i in 1..4) {
            val y = h * i / 5f
            drawLine(Border.copy(alpha = 0.65f), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        drawLine(Border, Offset(0f, mid), Offset(w, mid), strokeWidth = 1f)

        if (samples.isNotEmpty()) {
            drawPath(envelopes.first, Accent.copy(alpha = 0.12f))
            drawPath(envelopes.second, Accent.copy(alpha = 0.86f))
            drawLine(Accent.copy(alpha = 0.45f), Offset(0f, mid), Offset(w, mid), strokeWidth = 1f)

            if (event != null) {
                val windowStart = samples.first().offsetMs
                val windowEnd = samples.last().offsetMs.coerceAtLeast(windowStart + 1L)
                val center = event.startMs + event.durationMs / 2L
                val centerX = w * ((center - windowStart).toFloat() / (windowEnd - windowStart).toFloat()).coerceIn(0f, 1f)
                drawLine(LoudColor, Offset(centerX, 0f), Offset(centerX, h), strokeWidth = 1.5f)

            }
            val windowStart = samples.first().offsetMs
            val windowEnd = samples.last().offsetMs.coerceAtLeast(windowStart + 1L)
            (dragTime ?: playbackPositionMs)?.let { position ->
                val x = w * ((position - windowStart).toFloat() / (windowEnd - windowStart).toFloat()).coerceIn(0f, 1f)
                drawLine(Accent, Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
                drawCircle(Accent, radius = 5.dp.toPx(), center = Offset(x, mid))
            }
        }
    }
}

@Composable
private fun PlaybackBar(
    hasEvent: Boolean,
    isSelectedLoaded: Boolean,
    isPlaying: Boolean,
    canPrevious: Boolean,
    canNext: Boolean,
    onPlayPause: () -> Unit,
    onStop: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onList: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(PanelRaised, RoundedCornerShape(24.dp))
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        PlayerIconButton(symbol = "◀◀", enabled = canPrevious, onClick = onPrevious)
        PlayerIconButton(
            symbol = if (isSelectedLoaded && isPlaying) "Ⅱ" else "▶",
            enabled = hasEvent,
            onClick = onPlayPause
        )
        PlayerIconButton(symbol = "■", enabled = isSelectedLoaded, onClick = onStop)
        PlayerIconButton(symbol = "▶▶", enabled = canNext, onClick = onNext)
        PlayerIconButton(symbol = "☰", enabled = true, onClick = onList)
    }
}

@Composable
private fun PlayerIconButton(symbol: String, enabled: Boolean, onClick: () -> Unit) {
    val main = symbol == "▶" || symbol == "Ⅱ"
    val label = when (symbol) { "☰" -> "一覧"; "◀◀" -> "前へ"; "▶▶" -> "次へ"; "■" -> "停止"; "Ⅱ" -> "一時停止"; else -> "再生" }
    TextButton(onClick = onClick, enabled = enabled, modifier = Modifier.width(if (main) 64.dp else 52.dp).height(56.dp).semantics { contentDescription = when (symbol) { "☰" -> "区間一覧"; "◀◀" -> "前の区間"; "▶▶" -> "次の区間"; "■" -> "停止"; "Ⅱ" -> "一時停止"; else -> "再生" } }, colors = ButtonDefaults.textButtonColors(containerColor = if (main) Accent else Color.Transparent), shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(2.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val color = if (!enabled) White50.copy(alpha = 0.45f) else if (main) AppBgDeep else White90
            Text(symbol, color = color, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(label, color = color, fontSize = 11.sp)
        }
    }
}

@Composable
private fun TrendsScreen(sessions: List<RecordingSession>) {
    var days by rememberSaveable { mutableIntStateOf(7) }
    val now = System.currentTimeMillis()
    val cutoff = now - days * 24L * 60L * 60L * 1000L
    val recent = remember(sessions, days) { sessions.filter { it.startedAt >= cutoff }.sortedBy { it.startedAt } }
    val avgScore = if (recent.isEmpty()) 0 else recent.map { SessionMetrics.snoreScore(it) }.average().roundToInt()
    val avgPercent = if (recent.isEmpty()) 0 else recent.map { SessionMetrics.snorePercent(it) }.average().roundToInt()
    val totalBig = recent.sumOf { SessionMetrics.bigSnoreCount(it) }

    Surface(Modifier.fillMaxSize(), color = AppBg) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("傾向", color = White90, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("ねむピーノスコアといびきの推移", color = White70, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = days == 7, onClick = { days = 7 }, label = { Text("7日") }, modifier = Modifier.weight(1f))
                    FilterChip(selected = days == 30, onClick = { days = 30 }, label = { Text("30日") }, modifier = Modifier.weight(1f))
                }
            }
            if (sessions.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().height(240.dp), contentAlignment = Alignment.Center) {
                        Text("記録がたまるとここに傾向が出ます", color = White50)
                    }
                }
            } else {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("${days}日サマリー", color = White90, fontWeight = FontWeight.Bold)
                            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                MetricMini("平均スコア", "$avgScore")
                                MetricMini("平均いびき率", "$avgPercent%")
                                MetricMini("大いびき", "${totalBig}回")
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("ねむピーノスコア", color = White70, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp))
                            TrendChart(recent, Modifier.fillMaxWidth().height(170.dp))
                        }
                    }
                }
                item { SleepCalendar(sessions) }
                items(recent.asReversed(), key = { it.id }) { session ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(formatDate(session.startedAt), color = White90, fontWeight = FontWeight.SemiBold)
                                Text("いびき ${formatDuration(SessionMetrics.snoreDuration(session))} · ${SessionMetrics.snorePercent(session)}% · 大いびき ${SessionMetrics.bigSnoreCount(session)}回", color = White70, fontSize = 11.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${SessionMetrics.snoreScore(session)}", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("SCORE", color = White50, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricMini(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(label, color = White50, fontSize = 10.sp)
    }
}

@Composable
private fun SleepCalendar(sessions: List<RecordingSession>) {
    val zone = remember { ZoneId.systemDefault() }
    val today = remember { LocalDate.now(zone) }
    val first = remember(today) { today.withDayOfMonth(1) }
    val offset = first.dayOfWeek.value - 1
    val sessionByDate = remember(sessions, zone) {
        sessions.groupBy { Instant.ofEpochMilli(it.startedAt).atZone(zone).toLocalDate() }
            .mapValues { (_, values) -> values.maxByOrNull { it.startedAt }!! }
    }
    val totalCells = ((offset + first.lengthOfMonth() + 6) / 7) * 7
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text("${today.year}年${today.monthValue}月", color = White90, fontWeight = FontWeight.Bold)
            Text("記録カレンダー · 数字はねむピーノスコア", color = White50, fontSize = 10.sp)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                listOf("月","火","水","木","金","土","日").forEach { Text(it, color = White50, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
            }
            (0 until totalCells).chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth()) {
                    week.forEach { cell ->
                        val day = cell - offset + 1
                        if (day !in 1..first.lengthOfMonth()) Spacer(Modifier.weight(1f).height(48.dp))
                        else {
                            val date = first.withDayOfMonth(day)
                            val session = sessionByDate[date]
                            Column(
                                Modifier.weight(1f).height(48.dp).padding(2.dp).background(if (session != null) Accent.copy(alpha = 0.10f) else Color.Transparent, RoundedCornerShape(9.dp)),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text("$day", color = if (date == today) Accent else White70, fontSize = 10.sp)
                                Text(session?.let { SessionMetrics.snoreScore(it).toString() } ?: "·", color = if (session != null) White90 else White50, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrendChart(sessions: List<RecordingSession>, modifier: Modifier = Modifier) {
    val scaleMax = max(100, ((sessions.maxOfOrNull { SessionMetrics.snoreScore(it) } ?: 0) * 1.10f).roundToInt())
    Canvas(modifier = modifier) {
        val gap = 8f
        val count = sessions.size.coerceAtLeast(1)
        val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(3f)
        sessions.forEachIndexed { index, session ->
            val ratio = (SessionMetrics.snoreScore(session).toFloat() / scaleMax).coerceIn(0f, 1f)
            val height = max(3f, ratio * size.height)
            drawRoundRect(
                color = Accent,
                topLeft = Offset(index * (barWidth + gap), size.height - height),
                size = Size(barWidth, height),
                cornerRadius = CornerRadius(8f, 8f)
            )
        }
    }
}

@Composable
private fun MoreScreen(
    sessions: List<RecordingSession>,
    onOpen: (RecordingSession) -> Unit,
    onDelete: (RecordingSession) -> Unit
) {
    var pendingDelete by remember { mutableStateOf<RecordingSession?>(null) }
    Surface(Modifier.fillMaxSize(), color = AppBg) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text("夜の記録", color = White90, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("録音履歴と各日の結果", color = White70, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
            Spacer(Modifier.height(14.dp))
            if (sessions.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("まだ録音記録がありません", color = White50)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(sessions, key = { it.id }) { session ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onOpen(session) },
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(formatDate(session.startedAt), color = White90, fontWeight = FontWeight.Bold)
                                    Text(
                                        "${formatClock(session.startedAt)}〜${formatClock(session.endedAt)}  /  ${session.events.size}回",
                                        color = White70,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                                TextButton(onClick = { pendingDelete = session }) { Text("削除", color = Danger, fontSize = 12.sp) }
                                Text("›", color = Accent, fontSize = 27.sp)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }

    pendingDelete?.let { session ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("この録音を削除しますか？") },
            text = { Text("音声ファイルと解析結果の両方を削除します。") },
            confirmButton = {
                TextButton(onClick = { onDelete(session); pendingDelete = null }) { Text("削除", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("キャンセル") } }
        )
    }
}

@Composable
private fun SettingsScreen(onRetentionChanged: () -> Unit) {
    val context = LocalContext.current
    val settingsStore = remember { AppSettings.get(context) }
    var settings by remember { mutableStateOf(settingsStore.get()) }

    Surface(Modifier.fillMaxSize(), color = AppBg) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("設定", color = White90, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("ねむピーノの録音・検出設定", color = White70, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
            }
            item {
                SettingsCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("大きな音を自動検出", color = White90, fontWeight = FontWeight.SemiBold)
                            Text("音量を解析して区間をマークします", color = White70, fontSize = 11.sp)
                        }
                        Switch(
                            checked = settings.autoDetect,
                            onCheckedChange = {
                                settingsStore.setAutoDetect(it)
                                settings = settingsStore.get()
                            }
                        )
                    }
                }
            }
            item {
                SettingsCard {
                    Text("検出感度", color = White90, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(9.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("低め" to 0, "標準" to 1, "高め" to 2).forEach { (label, value) ->
                            FilterChip(
                                selected = settings.sensitivity == value,
                                onClick = {
                                    settingsStore.setSensitivity(value)
                                    settings = settingsStore.get()
                                },
                                label = { Text(label) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
            item {
                SettingsCard {
                    Text("静かな音の表示", color = White90, fontWeight = FontWeight.SemiBold)
                    Text("右ほど静かな部分を平らに表示", color = White70, fontSize = 11.sp)
                    Slider(value = settings.waveformFloorDb, valueRange = -48f..-20f,
                        onValueChange = { settingsStore.setWaveformFloor(it); settings = settingsStore.get() })
                    Text("${settings.waveformFloorDb.toInt()} dB以下を細く表示", color = Accent, fontSize = 12.sp)
                }
            }
            item {
                SettingsCard {
                    Text("録音データの保存期間", color = White90, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    listOf(7 to "7日", 30 to "30日", 90 to "90日", 0 to "自動削除しない").forEach { (days, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    settingsStore.setRetentionDays(days)
                                    settings = settingsStore.get()
                                    onRetentionChanged()
                                }
                                .padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, color = White90, modifier = Modifier.weight(1f))
                            Text(if (settings.retentionDays == days) "✓" else "", color = Accent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item {
                SettingsCard {
                    Text("プライバシー", color = White90, fontWeight = FontWeight.SemiBold)
                    Text(
                        "録音・音量データはアプリ内の端末ストレージだけに保存します。アカウント登録や自動送信はありません。音声共有は自分で選んだときだけ行います。",
                        color = White70,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
            item {
                Text(
                    "ねむピーノは医療機器ではありません。大きな音には、いびき以外の寝言・咳・布団や周囲の物音も含まれます。",
                    color = White50,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(15.dp)) { content() }
    }
}

private fun reduceSamples(samples: List<VolumeSample>, maxPoints: Int): List<VolumeSample> =
    SessionAnalysis.peaks(samples, maxPoints)

private fun eventLevel(event: SoundEvent): NoiseLevel = noiseLevel(event.peakDb)

private fun noiseLevel(db: Float): NoiseLevel = when {
    db >= -14f -> NoiseLevel.INTENSE
    db >= -22f -> NoiseLevel.LOUD
    db >= -30f -> NoiseLevel.LIGHT
    else -> NoiseLevel.QUIET
}

private fun timelineLabels(durationMs: Long): List<Long> {
    val duration = durationMs.coerceAtLeast(1L)
    val intervals = 5
    return (0..intervals).map { i -> duration * i / intervals }
}

private fun formatAxis(ms: Long): String = formatDuration(ms)

@Composable
private fun NavGlyph(index: Int, color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width; val h = size.height; val stroke = 2.dp.toPx()
        when (index) {
            0 -> { drawCircle(color, w * .39f, style = Stroke(stroke)); drawCircle(color, w * .17f) }
            1 -> {
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(w * .28f, h * .15f); lineTo(w * .8f, h * .5f); lineTo(w * .28f, h * .85f); close()
                }
                drawPath(path, color, style = Stroke(stroke))
            }
            2 -> (0..2).forEach { i ->
                drawLine(color, Offset(w * (.2f + i * .3f), h * .85f), Offset(w * (.2f + i * .3f), h * (.6f - i * .2f)), stroke, StrokeCap.Round)
            }
            3 -> (0..2).forEach { i -> drawLine(color, Offset(w * .15f, h * (.2f + i * .3f)), Offset(w * .85f, h * (.2f + i * .3f)), stroke, StrokeCap.Round) }
            else -> { drawCircle(color, w * .34f, style = Stroke(stroke)); drawCircle(color, w * .11f, style = Stroke(stroke)) }
        }
    }
}

@Composable
private fun ResultSummary(session: RecordingSession, onReview: () -> Unit, onMorning: () -> Unit, onLoudest: () -> Unit) {
    val snoreMs = remember(session.events, session.durationMs) { SessionMetrics.snoreDuration(session) }
    val percent = SessionMetrics.snorePercent(session)
    val score = SessionMetrics.snoreScore(session)
    val big = SessionMetrics.bigSnoreCount(session)
    val pending = SessionRefiner.PENDING in session.tags
    val failed = SessionRefiner.FAILED in session.tags
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(78.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (pending || failed) "—" else "$score", color = Accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("SCORE", color = White50, fontSize = 9.sp, letterSpacing = 1.sp)
                if (!pending && !failed) Text(SessionMetrics.scoreLabel(score), color = White70, fontSize = 9.sp, textAlign = TextAlign.Center)
            }
            Column(Modifier.weight(1f)) {
                Text("昨夜のねむピーノ", color = White90, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricCompact("録音", formatDuration(session.durationMs))
                    MetricCompact("いびき", if (pending) "解析待ち" else if (failed) "確認待ち" else formatDuration(snoreMs))
                    MetricCompact("割合", if (pending || failed) "—" else "$percent%")
                    MetricCompact("大いびき", if (pending || failed) "—" else "${big}回")
                }
            }
        }
        if (pending) Text("音声は保存済み · いびき分類を解析中", modifier = Modifier.padding(horizontal = 14.dp), color = Accent, fontSize = 10.sp)
        if (failed) {
            TextButton(onClick = { SessionRefiner.enqueue(context, session.id) }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp)) {
                Text("音声は保存済み · 解析を再試行", color = Accent, fontSize = 10.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = onMorning, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp)) {
                Text("朝の分析", color = AccentSoft, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            TextButton(onClick = onLoudest, enabled = SessionMetrics.snoreEvents(session).isNotEmpty(), contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp)) {
                Text("大いびきTOP5", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            TextButton(onClick = onReview, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp)) {
                Text(if (session.note.isBlank() && session.tags.none { it !in listOf(SessionRefiner.PENDING, SessionRefiner.FAILED) }) "メモ・共有" else "メモあり · 共有", color = AccentSoft, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun MetricCompact(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = White50, fontSize = 9.sp)
        Text(value, color = White90, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun MorningAnalysisDialog(session: RecordingSession, onDismiss: () -> Unit, onOpenTop5: () -> Unit) {
    val score = SessionMetrics.snoreScore(session)
    val counts = SessionMetrics.automaticClassCounts(session)
    val pending = SessionRefiner.PENDING in session.tags
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("昨夜のねむピーノ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(92.dp)) {
                        Text(if (pending) "—" else "$score", color = Accent, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                        Text("ねむピーノスコア", color = White50, fontSize = 10.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(if (pending) "解析中" else SessionMetrics.scoreLabel(score), color = White90, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("SnoreLabの公開仕様に寄せた、音量×時間の比較用スコアです", color = White50, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                listOf(
                    "録音時間" to formatDuration(session.durationMs),
                    "いびき時間" to formatDuration(SessionMetrics.snoreDuration(session)),
                    "いびき率" to "${SessionMetrics.snorePercent(session)}%",
                    "軽いいびき" to "${SessionMetrics.lightSnoreCount(session)}回",
                    "大いびき" to "${SessionMetrics.loudSnoreCount(session)}回",
                    "爆音いびき" to "${SessionMetrics.intenseSnoreCount(session)}回",
                    "いびき候補" to "${SessionMetrics.snoreEvents(session).size}区間"
                ).forEach { (label, value) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label, color = White70, fontSize = 12.sp)
                        Text(value, color = White90, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("自動分類", color = White90, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                val display = listOf("いびき候補", "寝言候補", "咳候補", "物音候補", "声・犬候補", "環境音候補", "不明")
                display.forEach { key ->
                    val n = counts[key] ?: 0
                    if (n > 0) Text("$key  ${n}回", color = if (key == "いびき候補") Accent else White70, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
                }
                Spacer(Modifier.height(10.dp))
                Text("スマホを置いた物音、咳、寝言、声・犬などの候補は、いびき時間・スコア・TOP5には数えません。分類は端末内の音の特徴から推定するため、似た音では誤判定することがあります。", color = White50, fontSize = 11.sp)
                TextButton(onClick = onOpenTop5, enabled = SessionMetrics.snoreEvents(session).isNotEmpty()) { Text("大いびきTOP5を聴く", color = Accent) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("閉じる") } },
        containerColor = Panel
    )
}

@Composable
private fun ReviewDialog(session: RecordingSession, file: File, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var note by remember(session.id) { mutableStateOf(session.note) }
    var tags by remember(session.id) { mutableStateOf(session.tags) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text("その夜の振り返り", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(formatDate(session.startedAt), color = White50, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Text("生活習慣・その夜の対策", color = White70, fontSize = 12.sp)
                listOf("飲酒", "疲れ", "鼻づまり", "横向き", "鼻テープ", "運動").chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { tag ->
                            FilterChip(selected = tag in tags, onClick = { tags = if (tag in tags) tags - tag else tags + tag }, label = { Text(tag, fontSize = 11.sp) })
                        }
                    }
                }
                OutlinedTextField(value = note, onValueChange = { note = it.take(2000) }, label = { Text("寝る前・朝のメモ") }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 5)
                Spacer(Modifier.height(8.dp))
                Text("いびき候補は音の特徴による推定です。音を聞いて手動ラベルで修正できます。いびきラボと同じ判定方式ではありません。", color = White50, fontSize = 11.sp)
                TextButton(enabled = !saving, onClick = {
                    saving = true
                    message = if (file.extension == "playlist") "共有用の音声を準備しています…" else null
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { runCatching {
                            require(file.isFile && file.length() > 0)
                            if (file.extension != "playlist") file else {
                                val output = File(context.cacheDir, "${session.id}-share.m4a")
                                AudioJoiner.join(AudioPlaylist.read(file).map { File(file.parentFile, it.fileName) }, output) {}
                                output
                            }
                        } }
                        result.onSuccess { audio ->
                            runCatching {
                                val uri = FileProvider.getUriForFile(context, context.packageName + ".files", audio)
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "audio/mp4"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    clipData = android.content.ClipData.newRawUri("録音", uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "録音を共有"))
                                message = null
                            }.onFailure { message = "共有できませんでした" }
                        }.onFailure { message = "共有用の音声を作成できませんでした" }
                        saving = false
                    }
                }) { Text("録音音声を共有", color = Accent) }
                message?.let { Text(it, color = Danger, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(enabled = !saving, onClick = {
                saving = true
                scope.launch {
                    val result = withContext(Dispatchers.IO) { runCatching { SessionStore.get(context).updateReview(session.id, note, tags) } }
                    saving = false
                    if (result.isSuccess) onDismiss() else message = "メモを保存できませんでした。空き容量を確認してください。"
                }
            }) { Text(if (saving) "保存中…" else "保存", color = Accent) }
        },
        dismissButton = { TextButton(enabled = !saving, onClick = onDismiss) { Text("閉じる", color = White70) } },
        containerColor = Panel
    )
}
