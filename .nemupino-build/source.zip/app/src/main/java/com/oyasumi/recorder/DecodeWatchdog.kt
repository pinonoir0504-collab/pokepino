package com.oyasumi.recorder

/** Detects an empty-output spin as well as a decoder that produces no buffers. */
class DecodeWatchdog(private val timeoutNanos: Long = 30_000_000_000L, now: Long = System.nanoTime()) {
    private var lastProgress = now
    fun check(madeProgress: Boolean, now: Long = System.nanoTime()) {
        if (madeProgress) lastProgress = now
        check(now - lastProgress <= timeoutNanos) { "Audio decoder stalled" }
    }
}
