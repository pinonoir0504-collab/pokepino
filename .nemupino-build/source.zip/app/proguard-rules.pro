# No custom ProGuard rules are required for this private-use app.
